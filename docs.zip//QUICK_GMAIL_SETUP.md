# ⚡ ШВИДКА АКТИВАЦІЯ Gmail для info@urbanheroes.com.ua

## 🎯 30 ХВИЛИН ДО ПРОФЕСІЙНОЇ GMAIL ПОШТИ

### **📧 3 ПРОСТИХ КРОКИ:**

#### **💼 КРОК 1: Google Workspace (10 хвилин)**
```bash
1. Сайт: https://workspace.google.com
2. "Get started" → "Business" → "Small business"
3. Організація: ГО "Міські герої"
4. Домен: urbanheroes.com.ua (вже маю)
5. Адмін: admin@urbanheroes.com.ua
6. Оплата: $6/міс (Business Starter)
```

#### **🔐 КРОК 2: Підтвердження домену (10 хвилин)**
```bash
1. Google дасть TXT запис: google-site-verification=код123
2. У DNS панелі домену додайте:
   Тип: TXT
   Ім'я: @
   Значення: google-site-verification=код123
3. Чекайте 5-15 хвилин → "Verify"
```

#### **📮 КРОК 3: MX записи (10 хвилин)**
```bash
У DNS панелі додайте 5 MX записів:

MX @ aspmx.l.google.com 1
MX @ alt1.aspmx.l.google.com 5
MX @ alt2.aspmx.l.google.com 5  
MX @ alt3.aspmx.l.google.com 10
MX @ alt4.aspmx.l.google.com 10

+ SPF запис:
TXT @ "v=spf1 include:_spf.google.com ~all"
```

---

## ✅ РЕЗУЛЬТАТ ЧЕРЕЗ 30 ХВИЛИН

**🎉 Urban Heroes матиме:**
- ✅ **info@urbanheroes.com.ua** з Gmail інтерфейсом
- ✅ **30GB Google Drive** простору
- ✅ **Google Docs/Sheets** замість Microsoft Office
- ✅ **Google Meet** для відеозв'язку
- ✅ **Мобільні додатки** Gmail на всіх пристроях
- ✅ **Корпоративна безпека** enterprise рівня

### **📱 Доступ до пошти:**
- **Веб**: https://gmail.com
- **Android**: Gmail (вбудований)
- **iOS**: Gmail з App Store
- **Desktop**: Gmail у браузері

### **💰 Вартість:**
- **Google Workspace**: $6/міс (~200 грн/міс)
- **Домен**: вже є
- **Налаштування**: БЕЗКОШТОВНО

---

## 👥 ДОДАТКОВІ EMAIL АДРЕСИ

### **🚀 Після основного налаштування створіть:**

```
info@urbanheroes.com.ua - основна (створюється автоматично)
support@urbanheroes.com.ua - підтримка
veterans@urbanheroes.com.ua - ветеранські програми  
youth@urbanheroes.com.ua - молодіжні проекти
press@urbanheroes.com.ua - ЗМІ
volunteer@urbanheroes.com.ua - волонтерство
events@urbanheroes.com.ua - заходи
```

### **📝 Налаштуйте псевдоніми:**
```
contact@urbanheroes.com.ua → info@urbanheroes.com.ua
hello@urbanheroes.com.ua → info@urbanheroes.com.ua
office@urbanheroes.com.ua → admin@urbanheroes.com.ua
```

---

## 🔧 ШВИДКЕ ТЕСТУВАННЯ

### **✅ Перевірте що працює:**

#### **1. DNS (5 хвилин):**
```bash
Сайт: https://dnschecker.org
Домен: urbanheroes.com.ua
Тип: MX
Результат: має показати Google сервери
```

#### **2. Email тест (5 хвилин):**
```bash
1. Зайдіть у Gmail: https://gmail.com
2. Увійдіть як admin@urbanheroes.com.ua
3. Створіть користувача info
4. Надішліть тестовий лист на свій особистий email
5. Перевірте доставку в обох напрямках
```

#### **3. Мобільний додаток (5 хвилин):**
```bash
1. Завантажте Gmail на телефон
2. Додайте аккаунт info@urbanheroes.com.ua
3. Перевірте синхронізацію
```

---

## 🚨 ЩО РОБИТИ ЯКЩО НЕ ПРАЦЮЄ

### **❌ Проблема: Домен не підтверджується**
**✅ Рішення:**
- Перевірте TXT запис у DNS
- Зачекайте до 24 годин
- Спробуйте alternate verification

### **❌ Проблема: Email не доходить**
**✅ Рішення:**
- Перевірте всі 5 MX записів
- Додайте SPF запис
- Зачекайте 48 годин для DNS поширення

### **❌ Проблема: Не можу надіслати листа**
**✅ Рішення:**
- Перевірте SMTP налаштування
- Використайте Gmail веб-інтерфейс
- Створіть App Password для сторонніх клієнтів

---

## 💡 БОНУСНІ ФІШКИ

### **🎯 Для Urban Heroes:**

#### **1. Фірмовий підпис email:**
```
--
[Ім'я прізвище]
ГО "Міські герої" - Громадська організація
📞 +38 (095) 670-52-20
📧 info@urbanheroes.com.ua
🌐 https://urbanheroes.com.ua
🇺🇦 "Кожен може стати героєм"
```

#### **2. Автовідповідач для info@:**
```
Дякуємо за звернення до ГО "Міські герої"!

Ваше повідомлення отримано і буде опрацьовано протягом 24 годин.

З повагою,
Команда Urban Heroes
```

#### **3. Google Calendar для заходів:**
- Планування ветеранських зустрічей
- Координація молодіжних проектів
- Нагадування про важливі події

---

## 🎉 ФІНАЛЬНИЙ ЧЕКЛИСТ

### **✅ Після завершення перевірте:**

- [ ] **Gmail працює**: info@urbanheroes.com.ua
- [ ] **Веб-доступ**: https://gmail.com
- [ ] **Мобільний додаток**: Gmail на телефоні
- [ ] **Тестовий лист**: відправлено та отримано
- [ ] **Контактна форма**: на сайті працює
- [ ] **Підпис email**: налаштований
- [ ] **Google Drive**: доступний
- [ ] **Google Calendar**: працює

---

**🇺🇦 SLAVA UKRAINI! GMAIL ДЛЯ URBAN HEROES АКТИВНИЙ!** 📧

**⏰ Час: 30 хвилин**  
**💰 Вартість: $6/міс**  
**🎯 Результат: Професійна корпоративна пошта з усіма Google сервісами**

**📧 Тепер Urban Heroes має найкращу email систему для служіння Україні!**