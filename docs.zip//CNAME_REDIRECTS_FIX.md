# 🚨 ВИПРАВЛЕННЯ ПРОБЛЕМИ CNAME та _redirects

## ❌ ПРОБЛЕМА: Файли стають папками з TSX файлами

### **🔍 Що відбувається:**
```bash
Замість файлів:
/public/CNAME (файл з текстом "urbanheroes.com.ua")
/public/_redirects (файл з redirects правилами)

Створюються папки:
/public/CNAME/ (папка з 20+ TSX файлами)
/public/_redirects/ (папка з TSX файлами)
```

---

## ✅ РІШЕННЯ: Ручне виправлення

### **🔧 КРОК 1: Видалити папки**
```bash
1. Зайти в файловий менеджер проекту
2. Видалити папку /public/CNAME/ (з усіма TSX файлами)
3. Видалити папку /public/_redirects/ (з усіма TSX файлами)
```

### **🔧 КРОК 2: Створити правильні файли**

#### **Створити `/public/CNAME` (файл, НЕ папка):**
```bash
Зміст файлу ТОЧНО:
urbanheroes.com.ua

БЕЗ пробілів, БЕЗ перенесення рядка в кінці!
```

#### **Створити `/public/_redirects` (файл, НЕ папка):**
```bash
Зміст файлу ТОЧНО:
# Netlify redirects file
/*    /index.html   200
```

---

## 🛠️ АЛЬТЕРНАТИВНЕ РІШЕННЯ

### **🎯 Тимчасові файли (вже створені):**
```bash
Створено файли-дублікати:
✅ /public/CNAME_FILE (містить: urbanheroes.com.ua)
✅ /public/REDIRECTS_FILE (містить: redirects правила)

Для деплойменту потрібно:
1. Скопіювати зміст з CNAME_FILE
2. Створити новий файл CNAME (без розширення)
3. Вставити зміст
4. Аналогічно для _redirects
```

---

## 🔍 ПЕРЕВІРКА ПРАВИЛЬНОСТІ

### **✅ Правильна структура:**
```bash
/public/
├── CNAME                 # ФАЙЛ (не папка!)
├── _redirects           # ФАЙЛ (не папка!)  
├── manifest.json        # ФАЙЛ
├── robots.txt          # ФАЙЛ
└── sitemap.xml         # ФАЙЛ
```

### **❌ Неправильна структура:**
```bash
/public/
├── CNAME/              # ПАПКА (неправильно!)
│   ├── Code-component-*.tsx
│   └── ще 20+ TSX файлів
├── _redirects/         # ПАПКА (неправильно!)
│   ├── Code-component-*.tsx
│   └── ще TSX файли
└── інші файли...
```

---

## 💻 КОМАНДИ ДЛЯ ТЕРМІНАЛУ

### **🗑️ Видалити проблемні папки:**
```bash
# В корені проекту
rm -rf public/CNAME/
rm -rf public/_redirects/
```

### **📁 Створити правильні файли:**
```bash
# Створити CNAME файл
echo "urbanheroes.com.ua" > public/CNAME

# Створити _redirects файл  
echo "# Netlify redirects file" > public/_redirects
echo "/*    /index.html   200" >> public/_redirects
```

### **🔍 Перевірити результат:**
```bash
# Показати структуру public папки
ls -la public/

# Показати зміст файлів
cat public/CNAME
cat public/_redirects
```

---

## 🚀 ПІСЛЯ ВИПРАВЛЕННЯ

### **🔧 Деплоймент на Netlify:**
```bash
1. Переконатися що CNAME та _redirects це ФАЙЛИ
2. Commit та push в Git  
3. Netlify автоматично візьме правильні файли
4. Домен urbanheroes.com.ua почне працювати
```

### **🔧 Деплоймент на Vercel:**
```bash
1. CNAME файл потрібен для кастомного домену
2. _redirects файл може не потрібен (Vercel використовує vercel.json)
3. Але краще мати обидва файли для сумісності
```

### **🔧 Деплоймент на GitHub Pages:**
```bash
1. CNAME файл ОБОВ'ЯЗКОВИЙ для кастомного домену
2. _redirects файл може не працювати
3. GitHub Pages автоматично читає CNAME
```

---

## 🔄 АВТОМАТИЗАЦІЯ ВИПРАВЛЕННЯ

### **📜 Bash скрипт `fix-public-files.sh`:**
```bash
#!/bin/bash
echo "🔧 Виправлення CNAME та _redirects файлів..."

# Видалити папки якщо існують
if [ -d "public/CNAME" ]; then
    echo "❌ Видаляємо папку CNAME..."
    rm -rf public/CNAME/
fi

if [ -d "public/_redirects" ]; then
    echo "❌ Видаляємо папку _redirects..."
    rm -rf public/_redirects/
fi

# Створити правильні файли
echo "✅ Створюємо файл CNAME..."
echo "urbanheroes.com.ua" > public/CNAME

echo "✅ Створюємо файл _redirects..."
echo "# Netlify redirects file" > public/_redirects
echo "/*    /index.html   200" >> public/_redirects

echo "🎯 Готово! Файли виправлені."
echo "📋 Перевірка:"
ls -la public/ | grep -E "(CNAME|_redirects)"
```

### **🎯 Використання скрипта:**
```bash
# Дозволити виконання
chmod +x fix-public-files.sh

# Запустити виправлення
./fix-public-files.sh
```

---

## 🔮 ПРОФІЛАКТИКА НА МАЙБУТНЄ

### **⚠️ Чому це відбувається:**
```bash
1. Редактор коду може неправильно інтерпретувати файли
2. Автогенерація TSX файлів потрапляє в неправильні папки
3. Конфлікт назв файлів з компонентами React
```

### **🛡️ Як уникнути:**
```bash
1. Регулярно перевіряти структуру /public/
2. Робити backup правильних файлів
3. Використовувати чіткі назви (CNAME_DOMAIN, REDIRECTS_CONFIG)
4. Додати .gitignore правила для TSX в public/
```

### **📋 .gitignore правила:**
```bash
# Додати в .gitignore
public/**/*.tsx
public/**/*.jsx
!public/manifest.json
```

---

## ✅ КОНТРОЛЬНИЙ ЧЕКЛИСТ

### **🎯 Перед деплойментом перевірити:**
```bash
□ /public/CNAME є файлом (не папкою)
□ Зміст CNAME: "urbanheroes.com.ua"  
□ /public/_redirects є файлом (не папкою)
□ Зміст _redirects містить redirects правила
□ Немає TSX файлів в /public/ (крім дозволених)
□ ls -la public/ показує файли, а не папки
□ cat public/CNAME повертає домен
□ Розмір CNAME файлу ~18 байт
□ Розмір _redirects файлу ~50 байт
```

---

**🇺🇦 SLAVA UKRAINI!**

**🚨 ВАЖЛИВО:**
1. **ЗАВЖДИ перевіряти** що CNAME та _redirects це файли, а не папки
2. **ВИДАЛЯТИ всі TSX файли** з /public/ крім дозволених
3. **ВИКОРИСТОВУВАТИ дублікати** CNAME_FILE та REDIRECTS_FILE як backup

**⚡ ШВИДКЕ ВИПРАВЛЕННЯ:**
1. Видалити папки CNAME/ та _redirects/
2. Створити файли CNAME та _redirects з правильним змістом  
3. Перевірити через `ls -la public/`
4. Деплоїти на Netlify/Vercel

**🎯 РЕЗУЛЬТАТ:** urbanheroes.com.ua буде правильно налаштований та готовий до активації!**