# ⚡ ШВИДКИЙ СТАРТ - Urban Heroes Ukraine

## 🚀 Публікація за 10 хвилин

### **1️⃣ Завантаження на GitHub (2 хв)**
```bash
# У папці проекту
git init
git add .
git commit -m "🇺🇦 Urban Heroes Ukraine - Initial release"
git remote add origin https://github.com/[your-username]/urban-heroes-ukraine.git
git push -u origin main
```

### **2️⃣ Деплой через Vercel (3 хв)**
1. Відкрийте: **vercel.com** → Login with GitHub
2. **New Project** → Import `urban-heroes-ukraine`
3. Налаштування (автоматично):
   - Framework: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. **Deploy** → Зачекати 1-2 хвилини

### **3️⃣ Підключення домену (5 хв)**
1. Vercel Dashboard → **Domains** → Add `urbanheroes.com.ua`
2. Скопіювати DNS записи від Vercel
3. У панелі реєстратора домену додати:
   ```
   A Record: @ → 76.76.19.61
   CNAME: www → cname.vercel-dns.com
   ```
4. Зачекати 10-60 хвилин для DNS розповсюдження

---

## ✅ ПЕРЕВІРКА ПІСЛЯ ПУБЛІКАЦІЇ

### **🌐 Тестування сайту:**
- [ ] Відкривається: https://urbanheroes.com.ua
- [ ] Переадресація www працює
- [ ] SSL сертифікат активний (🔒 у браузері)
- [ ] Мобільна версія коректна

### **📱 PWA перевірка:**
- [ ] Натисніть + в адресному рядку для встановлення
- [ ] Manifest.json завантажується: /manifest.json
- [ ] Іконки відображаються

### **🔍 SEO перевірка:**
- [ ] Sitemap: urbanheroes.com.ua/sitemap.xml
- [ ] Robots: urbanheroes.com.ua/robots.txt
- [ ] Meta теги присутні (перегляд коду сторінки)

---

## 📧 НАЛАШТУВАННЯ EMAIL (додатково)

### **Швидке підключення Mail.ru:**
1. **connect.mail.ru/domain** → Підключити `urbanheroes.com.ua`
2. Додати MX записи в DNS:
   ```
   MX: @ → emx.mail.ru (10)
   MX: @ → emx2.mail.ru (20)
   TXT: @ → v=spf1 redirect=_spf.mail.ru
   ```
3. Створити: **info@urbanheroes.com.ua**

---

## 🆘 ЯКЩО ЩОСЬ НЕ ПРАЦЮЄ

### **❌ Сайт не відкривається:**
```bash
# Перевірити DNS
nslookup urbanheroes.com.ua
# Має показати IP адресу Vercel
```

### **❌ Помилка при build:**
```bash
# Встановити залежності
npm install

# Перевірити build локально
npm run build
```

### **❌ Домен не підключається:**
- Зачекати 24-48 годин
- Перевірити правильність DNS записів
- Зв'язатися з підтримкою реєстратора

---

## 🎯 ГОТОВО!

🎉 **Ваш сайт Urban Heroes опубліковано!**

- **🌐 URL:** https://urbanheroes.com.ua
- **⚡ Швидкість:** Оптимізовано для швидкого завантаження
- **📱 PWA:** Встановлюється як додаток
- **🔍 SEO:** Готово для пошукових систем
- **🇺🇦 Патріотизм:** Україна має новий цифровий ресурс!

### **📞 Підтримка:**
- Email: info@urbanheroes.com.ua (після налаштування)
- Tech: vercel.com/support
- Community: GitHub Issues

**Слава Україні! Героям слава! 🇺🇦🦸‍♂️**