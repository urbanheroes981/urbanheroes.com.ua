# 📧 Активація пошти info@urbanheroes.com.ua

## 🎯 МЕТА: Налаштувати професійну пошту info@urbanheroes.com.ua

### **📋 ПОТРІБНО ДЛЯ АКТИВАЦІЇ:**
1. ✅ **Домен**: urbanheroes.com.ua (купити/активувати)
2. ✅ **DNS доступ**: панель управління доменом
3. ✅ **Email провайдер**: вибрати сервіс для пошти
4. ✅ **MX записи**: налаштувати в DNS

---

## 🌟 РЕКОМЕНДОВАНІ СЕРВІСИ (БЕЗКОШТОВНІ)

### **1. 🆓 Yandex Connect for Business**

#### **✅ Переваги:**
- **💰 Безкоштовно** до 1000 користувачів
- **📱 Повний функціонал** (Gmail-подібний інтерфейс)
- **🔒 Безпека** - антиспам, антивірус
- **📮 Необмежена кількість** листів
- **🌍 Українська локалізація**

#### **📝 Покрокова активація:**

**Крок 1: Реєстрація**
```bash
1. Йдіть на: https://connect.yandex.com
2. Натисніть "Start using for free"
3. Введіть домен: urbanheroes.com.ua
4. Створіть обліковий запис Yandex
```

**Крок 2: Підтвердження домену**
```bash
1. Yandex дасть вам TXT запис для DNS
2. У панелі вашого домену (nic.ua, ukraine.com.ua) додайте:
   Тип: TXT
   Ім'я: @
   Значення: [код від Yandex]
```

**Крок 3: Налаштування MX записів**
```bash
У DNS налаштуваннях домену додайте:

Тип: MX
Ім'я: @
Значення: mx.yandex.net
Пріоритет: 10
```

**Крок 4: Створення поштової скриньки**
```bash
1. В адмін панелі Yandex Connect
2. Додайте користувача: info
3. Встановіть пароль
4. ✅ Готово! info@urbanheroes.com.ua активна
```

### **2. 🆓 Zoho Mail Free**

#### **✅ Переваги:**
- **💰 Безкоштовно** до 5 користувачів
- **📦 5GB** на кожну скриньку
- **📱 Мобільні додатки**
- **🔒 Безпека** та шифрування

#### **📝 Активація:**
```bash
1. Сайт: https://www.zoho.com/mail
2. Sign up for free
3. Add domain: urbanheroes.com.ua
4. Verify domain (TXT запис)
5. Add MX records:
   - mx.zoho.com (пріоритет 10)
   - mx2.zoho.com (пріоритет 20)
```

### **3. 🆓 ProtonMail Custom Domain**

#### **✅ Переваги:**
- **🔒 Максимальна безпека** (end-to-end шифрування)
- **🇨🇭 Швейцарські сервери** (поза юрисдикцією)
- **🛡 Антиспам** вбудований
- **📱 Додатки** для всіх платформ

#### **📝 Активація:**
```bash
1. Сайт: https://proton.me
2. Upgrade to Plus plan ($4/міс)
3. Add custom domain
4. Configure MX records:
   - mail.protonmail.ch (пріоритет 10)
   - mailsec.protonmail.ch (пріоритет 20)
```

---

## 💰 ПЛАТНІ ОПЦІЇ (ПРОФЕСІЙНІ)

### **1. 💼 Google Workspace**

#### **💰 Вартість:** $6/місяць на користувача

#### **✅ Переваги:**
- **📧 Gmail інтерфейс** з custom доменом
- **☁️ Google Drive** 30GB
- **📝 Google Docs, Sheets** 
- **📞 Google Meet** 
- **📊 Google Analytics** інтеграція

#### **📝 Активація:**
```bash
1. Сайт: https://workspace.google.com
2. Start free trial
3. Add domain: urbanheroes.com.ua
4. Verify domain (HTML файл або TXT запис)
5. Configure MX records:
   - aspmx.l.google.com (пріоритет 1)
   - alt1.aspmx.l.google.com (пріоритет 5)
   - alt2.aspmx.l.google.com (пріоритет 5)
```

### **2. 💼 Microsoft 365**

#### **💰 Вартість:** $5-12/місяць

#### **✅ Переваги:**
- **📧 Outlook** з custom доменом
- **☁️ OneDrive** 1TB
- **📝 Word, Excel, PowerPoint** онлайн
- **👥 Microsoft Teams**

---

## ⚡ ШВИДКА АКТИВАЦІЯ (20 хвилин)

### **🎯 Найшвидший спосіб - Yandex Connect:**

**1. Домен (якщо ще немає):**
```bash
• Купіть urbanheroes.com.ua на nic.ua (~250 грн/рік)
• Або активуйте наявний домен
```

**2. Yandex Connect (10 хвилин):**
```bash
• https://connect.yandex.com
• Додайте домен urbanheroes.com.ua
• Підтвердьте через TXT запис
```

**3. DNS налаштування (10 хвилин):**
```bash
У панелі домену додайте:

TXT запис (для підтвердження):
Ім'я: @
Значення: [код від Yandex]

MX запис (для пошти):
Ім'я: @
Значення: mx.yandex.net
Пріоритет: 10
```

**4. Створення info@urbanheroes.com.ua:**
```bash
• В Yandex Connect → Add user
• Username: info
• Password: [встановіть надійний пароль]
• ✅ Готово!
```

---

## 🔧 ТЕХНІЧНІ ДЕТАЛІ DNS

### **📋 Повний список DNS записів для пошти:**

#### **Для Yandex Connect:**
```dns
; Підтвердження домену
TXT @ "yandex-verification=код_від_yandex"

; Поштові сервери
MX @ mx.yandex.net. 10

; SPF запис (проти спаму)
TXT @ "v=spf1 include:_spf.yandex.net ~all"

; DKIM (цифровий підпис)
TXT mail._domainkey "v=DKIM1; k=rsa; t=s; p=публічний_ключ"

; DMARC (політика доставки)
TXT _dmarc "v=DMARC1; p=quarantine; rua=mailto:info@urbanheroes.com.ua"
```

#### **Для Google Workspace:**
```dns
; Поштові сервери Google
MX @ aspmx.l.google.com. 1
MX @ alt1.aspmx.l.google.com. 5
MX @ alt2.aspmx.l.google.com. 5
MX @ alt3.aspmx.l.google.com. 10
MX @ alt4.aspmx.l.google.com. 10

; SPF для Google
TXT @ "v=spf1 include:_spf.google.com ~all"
```

---

## 📱 НАЛАШТУВАННЯ КЛІЄНТІВ

### **📧 Після активації info@urbanheroes.com.ua:**

#### **📱 Мобільні додатки:**
- **Android**: Gmail, Yandex Mail, Outlook
- **iOS**: Mail, Gmail, Yandex Mail  
- **Настільні**: Thunderbird, Outlook, Apple Mail

#### **⚙️ Налаштування IMAP/SMTP:**

**Для Yandex:**
```config
IMAP сервер: imap.yandex.com
IMAP порт: 993 (SSL)
SMTP сервер: smtp.yandex.com  
SMTP порт: 465 (SSL)
```

**Для Google:**
```config
IMAP сервер: imap.gmail.com
IMAP порт: 993 (SSL)
SMTP сервер: smtp.gmail.com
SMTP порт: 465 (SSL)
```

---

## 🔍 ПЕРЕВІРКА АКТИВАЦІЇ

### **✅ Як перевірити, що пошта працює:**

#### **1. DNS перевірка:**
```bash
• Сайт: https://dnschecker.org
• Введіть: urbanheroes.com.ua
• Тип: MX
• ✅ Повинен показати ваші MX записи
```

#### **2. Email перевірка:**
```bash
• Сайт: https://mxtoolbox.com
• Email test: info@urbanheroes.com.ua
• ✅ Перевірить SPF, DKIM, DMARC
```

#### **3. Тестова пошта:**
```bash
• Надішліть листа на info@urbanheroes.com.ua
• З іншої поштової скриньки
• Перевірте доставку та відповідь
```

---

## ⚠️ МОЖЛИВІ ПРОБЛЕМИ

### **❌ Пошта не доходить**
**✅ Рішення:**
- Перевірте MX записи в DNS
- Зачекайте 24 години для поширення DNS
- Перевірте папку "Спам"

### **❌ Помилка автентифікації**
**✅ Рішення:**
- Перевірте SPF запис
- Налаштуйте DKIM
- Додайте DMARC політику

### **❌ DNS не оновлюється**
**✅ Рішення:**
- Очистіть DNS кеш: `ipconfig /flushdns`
- Використайте DNS 8.8.8.8 тимчасово
- Зачекайте до 48 годин

---

## 📊 РЕКОМЕНДАЦІЇ ДЛЯ URBAN HEROES

### **🎯 Оптимальний вибір:**

#### **🆓 Безкоштовний початок:**
- **Yandex Connect** - найкращий безкоштовний варіант
- Повний функціонал
- Українська підтримка
- Легке налаштування

#### **💼 Професійний варіант:**
- **Google Workspace** - якщо потрібна інтеграція з Google
- **Microsoft 365** - якщо використовуєте Windows

### **📧 Додаткові поштові скриньки:**
```
admin@urbanheroes.com.ua - адміністрація
support@urbanheroes.com.ua - підтримка
veterans@urbanheroes.com.ua - ветеранські програми
youth@urbanheroes.com.ua - молодіжні проекти
press@urbanheroes.com.ua - прес-служба
volunteer@urbanheroes.com.ua - волонтери
```

---

## 🎉 РЕЗУЛЬТАТ

### **✅ Після активації:**

1. **📧 Активна пошта**: info@urbanheroes.com.ua
2. **📱 Мобільний доступ**: через додатки
3. **🌐 Веб-інтерфейс**: browser доступ
4. **🔒 Безпека**: SPF, DKIM, DMARC
5. **📊 Статистика**: відстеження листів
6. **🛡 Антиспам**: автоматичний захист

### **💡 Тепер можна:**
- ✅ Отримувати листи від клієнтів
- ✅ Відправляти офіційні повідомлення
- ✅ Налаштувати автовідповідачі
- ✅ Інтегрувати з сайтом (Contact форма)
- ✅ Створити підписи для ГО "Міські герої"

---

**🇺🇦 Слава Україні! Професійна пошта Urban Heroes готова служити українському народу!** 📧

**⏰ Час активації:** 20-30 хвилин  
**💰 Вартість:** від 0 грн (безкоштовно) до 200 грн/міс  
**📞 Підтримка:** 24/7 через обраний email провайдер