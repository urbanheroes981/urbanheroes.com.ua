# 🌐 Покрокова інструкція налаштування домену urbanheroes.com.ua

## 🎯 КОРОТКИЙ ОГЛЯД

Цей гайд допоможе налаштувати домен **urbanheroes.com.ua** для проекту "Міські герої". Проект готовий до публікації і потребує лише налаштування DNS та деплойменту.

---

## 📋 ПЕРЕД ПОЧАТКОМ

### ✅ Що вам потрібно:
- ✅ Зареєстрований домен **urbanheroes.com.ua**
- ✅ Доступ до панелі управління доменом
- ✅ GitHub акаунт
- ✅ Готовий код проекту

### 📁 Готові файли в проекті:
- ✅ `/public/CNAME` - налаштований для urbanheroes.com.ua
- ✅ `/vercel.json` - конфігурація Vercel з доменом
- ✅ `/public/sitemap.xml` - карта сайту для SEO
- ✅ `/public/robots.txt` - налаштування для пошукових систем
- ✅ `/public/manifest.json` - PWA налаштування

---

## 🚀 ВАРІАНТ 1: VERCEL (РЕКОМЕНДОВАНИЙ)

### **Крок 1: Публікація на GitHub**
```bash
# Якщо ще не створили репозиторій
git init
git add .
git commit -m "Initial commit: Urban Heroes Ukraine website"
git remote add origin https://github.com/[ваш-username]/urban-heroes-ukraine.git
git push -u origin main
```

### **Крок 2: Деплой через Vercel**
1. 📖 Перейдіть на **vercel.com**
2. 🔐 Увійдіть через GitHub
3. ➕ Натисніть **"New Project"**
4. 📂 Виберіть репозиторій **urban-heroes-ukraine**
5. ⚙️ Налаштування (автоматично визначаться):
   ```
   Framework Preset: Vite
   Build Command: npm run build  
   Output Directory: dist
   Install Command: npm install
   ```
6. 🚀 Натисніть **"Deploy"**

### **Крок 3: Підключення домену в Vercel**
1. 🎛️ У Vercel Dashboard → **Settings** → **Domains**
2. ➕ **Add Domain**: `urbanheroes.com.ua`
3. ➕ **Add Domain**: `www.urbanheroes.com.ua`
4. 📋 Vercel покаже DNS записи для налаштування

---

## 📡 НАЛАШТУВАННЯ DNS

### **🌍 У панелі вашого реєстратора доменів:**

#### **Для большинства провайдерів (.ua домени):**
```
Тип: A
Ім'я: @
Значення: 76.76.19.61

Тип: A  
Ім'я: www
Значення: 76.76.19.61

Тип: CNAME
Ім'я: www
Значення: cname.vercel-dns.com
```

#### **Альтернативно (якщо підтримуються CNAME для @):**
```
Тип: CNAME
Ім'я: @
Значення: cname.vercel-dns.com

Тип: CNAME
Ім'я: www  
Значення: cname.vercel-dns.com
```

### **⏰ Час поширення:**
- 🕐 DNS зміни: **15 хвилин - 24 години**
- 🔒 SSL сертифікат: **1-2 години після DNS**

---

## 🎨 ВАРІАНТ 2: NETLIFY

### **Крок 1: Деплой через Netlify**
1. 📖 Перейдіть на **netlify.com**
2. 🔐 Увійдіть через GitHub
3. ➕ **"New site from Git"** → **GitHub** → виберіть репозиторій
4. ⚙️ Налаштування:
   ```
   Build Command: npm run build
   Publish Directory: dist
   ```
5. 🚀 **"Deploy site"**

### **Крок 2: Підключення домену**
1. 🎛️ **Site Settings** → **Domain Management**
2. ➕ **Add Custom Domain**: `urbanheroes.com.ua`

### **Крок 3: DNS для Netlify**
```
Тип: A
Ім'я: @
Значення: 75.2.60.5

Тип: CNAME
Ім'я: www
Значення: [ваш-сайт].netlify.app
```

---

## 📊 ВАРІАНТ 3: GITHUB PAGES

### **Налаштування GitHub Pages**
1. 📂 Repository → **Settings** → **Pages**
2. 🔧 Source: **GitHub Actions**
3. 📝 Створіть `.github/workflows/deploy.yml`:

```yaml
name: Deploy Urban Heroes to GitHub Pages
on:
  push:
    branches: [ main ]
    
permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
        
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18'
          cache: 'npm'
          
      - name: Install dependencies
        run: npm install
        
      - name: Build project
        run: npm run build
        
      - name: Setup Pages
        uses: actions/configure-pages@v4
        
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./dist
          
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

### **DNS для GitHub Pages:**
```
Тип: CNAME
Ім'я: @
Значення: [ваш-username].github.io

Тип: CNAME
Ім'я: www
Значення: [ваш-username].github.io
```

---

## 📧 НАЛАШТУВАННЯ EMAIL

### **📬 Email адреси проекту:**
- **info@urbanheroes.com.ua** - загальні запити
- **volunteer@urbanheroes.com.ua** - волонтерство  
- **support@urbanheroes.com.ua** - підтримка

### **🔧 Підключення email форм:**

#### **Для Vercel (рекомендовано):**
```javascript
// Використання Formspree або EmailJS
// В Contact.tsx додати:
<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
  <input type="email" name="email" placeholder="info@urbanheroes.com.ua" />
  <textarea name="message"></textarea>
  <button type="submit">Надіслати</button>
</form>
```

#### **Для Netlify:**
```html
<!-- Форма автоматично обробляється Netlify -->
<form name="contact" method="POST" data-netlify="true" data-netlify-honeypot="bot-field">
  <input type="hidden" name="form-name" value="contact" />
  <!-- поля форми -->
</form>
```

---

## 🔍 SEO ТА АНАЛІТИКА

### **📊 Google Search Console:**
1. 🌐 Перейдіть на `search.google.com/search-console`
2. ➕ **Add Property**: `urbanheroes.com.ua`
3. ✅ Підтвердіть через DNS або HTML файл
4. 🗺️ Додайте sitemap: `https://urbanheroes.com.ua/sitemap.xml`

### **📈 Google Analytics:**
```html
<!-- Додати в index.html -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### **📊 Yandex Metrica (для України):**
```html
<script type="text/javascript">
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/watch.js", "ym");

   ym(COUNTER_ID, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true
   });
</script>
```

---

## 🔒 БЕЗПЕКА ТА SSL

### **🛡️ SSL Сертифікати:**
- ✅ **Vercel/Netlify**: автоматично Let's Encrypt
- ✅ **GitHub Pages**: автоматично після підключення домену
- ⏱️ **Час активації**: 1-24 години

### **🔐 Безпека Headers (вже налаштовані в vercel.json):**
```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" }
      ]
    }
  ]
}
```

---

## 🧪 ТЕСТУВАННЯ ПІСЛЯ ПУБЛІКАЦІЇ

### **✅ Чек-лист перевірки:**
- [ ] 🌐 Сайт відкривається на `https://urbanheroes.com.ua`
- [ ] 🌍 Редирект з `www.urbanheroes.com.ua` працює
- [ ] 🔒 SSL сертифікат активний (зелений замок)
- [ ] 📱 Мобільна версія працює коректно
- [ ] 📧 Контактна форма надсилає email
- [ ] 🗺️ Sitemap доступний: `/sitemap.xml`
- [ ] 🤖 Robots.txt доступний: `/robots.txt`
- [ ] 📱 PWA встановлюється на телефон
- [ ] 🌍 Обидві мови (UA/EN) працюють
- [ ] 📊 Google Analytics збирає дані

### **🛠️ Інструменти для тестування:**
- **📊 PageSpeed Insights**: `pagespeed.web.dev`
- **🔍 GTmetrix**: `gtmetrix.com`
- **📱 Mobile-Friendly Test**: `search.google.com/test/mobile-friendly`
- **🔒 SSL Labs**: `ssllabs.com/ssltest`

---

## 🆘 ВИРІШЕННЯ ПРОБЛЕМ

### **🌐 Сайт не відкривається:**
```bash
# Перевірка DNS
nslookup urbanheroes.com.ua
dig urbanheroes.com.ua

# Очистка DNS кешу
ipconfig /flushdns  # Windows
sudo dscacheutil -flushcache  # macOS
```

### **🔒 SSL не працює:**
- ⏰ Зачекайте 24 години після зміни DNS
- 🔄 Примусове оновлення SSL в панелі хостингу
- 🧹 Очистіть кеш браузера (Ctrl+Shift+R)

### **📧 Email форми не працюють:**
- ✅ Перевірте правильність налаштування Formspree/EmailJS
- 📧 Переконайтеся, що email info@urbanheroes.com.ua існує
- 🔍 Перевірте Network tab в DevTools на помилки

---

## 📞 ПІДТРИМКА

### **🎯 Технічна підтримка:**
- **Vercel**: `vercel.com/support`
- **Netlify**: `docs.netlify.com`
- **GitHub**: `docs.github.com/pages`

### **📋 Корисні команди:**
```bash
# Локальна розробка
npm run dev

# Білд проекту
npm run build

# Перевірка білду
npm run preview

# Деплой (якщо налаштовано)
npm run deploy
```

---

## 🏆 УСПІШНЕ ЗАВЕРШЕННЯ

Після завершення налаштування ваш сайт "Міські герої" буде повністю доступний:

- 🌐 **Головний сайт**: https://urbanheroes.com.ua
- 📧 **Email**: info@urbanheroes.com.ua
- 📱 **PWA**: встановлення як додаток
- 🔍 **SEO**: індексація в Google/Yandex
- 🔒 **Безпека**: SSL та security headers
- 🌍 **Мови**: українська та англійська

🎉 **Слава Україні! Ваш проект готовий служити українському народу!** 🇺🇦

---

**💡 Примітка**: Якщо у вас виникли проблеми з налаштуванням, зверніться до документації вашого DNS провайдера або створіть issue в репозиторії проекту.