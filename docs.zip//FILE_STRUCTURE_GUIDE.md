# 📁 Структура файлів urbanheroes.com.ua

## 🎯 ДЕ ЗНАХОДЯТЬСЯ КЛЮЧОВІ ФАЙЛИ

### **🌐 Файли для домену та DNS:**

#### **📋 `/public/CNAME`** (ВАЖЛИВО!)
```bash
Зміст: urbanheroes.com.ua
Призначення: Каже GitHub Pages/Netlify який домен використовувати
Статус: ✅ ВИПРАВЛЕНО (тепер файл, а не папка)
```

#### **📋 `/public/_redirects`** (ВАЖЛИВО!)
```bash
Зміст: /*    /index.html   200
Призначення: Netlify redirects для SPA роутингу
Статус: ✅ ВИПРАВЛЕНО (тепер файл, а не папка)
```

#### **📋 `/vercel.json`** (для Vercel деплоймента)
```bash
Зміст: Конфігурація Vercel
Призначення: Налаштування деплойменту на Vercel
```

---

## 🚨 ПРОБЛЕМА З ПАПКАМИ ЗАМІСТЬ ФАЙЛІВ

### **❌ Що відбувається:**
```bash
Файли CNAME та _redirects постійно стають папками з TSX файлами:

/public/CNAME/ (папка)
├── Code-component-2118-744.tsx
├── Code-component-2118-671.tsx
└── інші TSX файли...

/public/_redirects/ (папка)  
├── Code-component-2118-746.tsx
├── Code-component-2118-673.tsx
└── інші TSX файли...
```

### **✅ Як має бути:**
```bash
/public/CNAME (файл)
Зміст: urbanheroes.com.ua

/public/_redirects (файл)
Зміст: /*    /index.html   200
```

### **🔧 Чому це відбувається:**
```bash
1. Ймовірно редактор створює папки замість файлів
2. TSX файли генеруються автоматично
3. Потрібно вручну видаляти папки та створювати файли
```

---

## 📊 ПОВНА СТРУКТУРА ПРОЕКТУ

### **🏠 Кореневі файли:**
```bash
├── App.tsx              # Головний компонент з роутингом
├── Guidelines.md        # Гайдлайни проекту  
├── package.json         # Залежності Node.js
├── vercel.json         # Конфігурація Vercel
├── vite.config.ts      # Конфігурація Vite
└── tsconfig.json       # Конфігурація TypeScript
```

### **🎨 Компоненти (`/components/`):**
```bash
├── Navigation.tsx       # Головне меню
├── Hero.tsx            # Головна секція
├── About.tsx           # Про нас
├── Features.tsx        # Функції платформи
├── DNSDiagnostics.tsx  # 🆕 DNS діагностика
├── VeteranProject.tsx  # Проект для ветеранів
├── YouthProject.tsx    # Проект для молоді
├── Footer.tsx          # Футер сайту
└── ui/                 # ShadCN UI компоненти
```

### **🌍 Інтернаціоналізація (`/i18n/`):**
```bash
├── LanguageContext.tsx  # Контекст мови
└── translations.ts      # Переклади UA/EN
```

### **🌐 Публічні файли (`/public/`):**
```bash
├── CNAME               # ✅ Домен для GitHub/Netlify
├── _redirects          # ✅ Redirects для SPA
├── manifest.json       # PWA манифест
├── robots.txt          # SEO роботи
└── sitemap.xml         # SEO карта сайту
```

### **📚 Документація (`/docs/`):**
```bash
├── EMERGENCY_DNS_STATUS.md     # 🚨 Екстрена допомога з DNS
├── DNS_DIAGNOSTICS_USAGE.md   # 🛠️ Як користуватись діагностикою
├── DEPLOYMENT_GUIDE.md        # 🚀 Гайд деплойменту
├── QUICK_STATUS_CHECK.md      # ⚡ Швидка перевірка статусу
└── 20+ інших корисних гайдів...
```

### **🎨 Стилі (`/styles/`):**
```bash
└── globals.css         # Tailwind V4 + українські класи
```

---

## 🔧 DNS ДІАГНОСТИКА - ДЕ ЗНАХОДИТЬСЯ

### **📍 Локація компонента:**
```bash
Файл: /components/DNSDiagnostics.tsx
Розмір: ~300 рядків React коду
Статус: ✅ Активний та працює
```

### **🔗 Як отримати доступ:**
```bash
URL параметр: ?page=dns

Приклади:
• http://localhost:5173/?page=dns
• https://xxx.vercel.app/?page=dns  
• https://urbanheroes.com.ua/?page=dns (після активації)
```

### **⚡ Функції DNS діагностики:**
```bash
✅ Автоматична перевірка DNS статусу
✅ Копіювання DNS записів одним кліком
✅ Прямі посилання на провайдерів
✅ Візуальний таймлайн очікуваних термінів
✅ Повноекранний режим (без навігації)
✅ Мобільна адаптивність
```

---

## 📋 КОНФІГУРАЦІЙНІ ФАЙЛИ

### **🎯 Для деплойменту:**

#### **`/vercel.json`:**
```json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

#### **`/package.json`** (основні залежності):
```json
{
  "dependencies": {
    "react": "^18.x",
    "typescript": "^5.x",
    "tailwindcss": "^4.x",
    "vite": "^5.x"
  }
}
```

#### **`/vite.config.ts`:**
```typescript
export default defineConfig({
  plugins: [react()],
  base: '/'
})
```

---

## 🚀 ШВИДКІ ПОСИЛАННЯ НА КЛЮЧОВІ ФАЙЛИ

### **🔧 Технічні файли:**
```bash
• App.tsx - головний роутинг та логіка
• /components/DNSDiagnostics.tsx - DNS діагностика  
• /styles/globals.css - всі стилі та українські класи
• /i18n/translations.ts - переклади UA/EN
```

### **📚 Документація:**
```bash
• /docs/EMERGENCY_DNS_STATUS.md - екстрена допомога
• /docs/DNS_DIAGNOSTICS_USAGE.md - інструкція діагностики
• /docs/DEPLOYMENT_GUIDE.md - повний гайд деплойменту
```

### **🌐 Деплоймент:**
```bash
• /public/CNAME - домен файл (urbanheroes.com.ua)
• /public/_redirects - Netlify redirects
• /vercel.json - Vercel конфігурація
```

---

## 💡 ЛАЙФХАКИ ДЛЯ РОЗРОБКИ

### **🔍 Швидкий пошук файлів:**
```bash
Ctrl+P (VS Code) - швидкий пошук файлів
Шукати за назвою: DNSDiagnostics, App.tsx, globals.css
```

### **📁 Важливі папки для редагування:**
```bash
/components/ - всі React компоненти
/docs/ - документація та гайди  
/public/ - статичні файли та конфігурація
/styles/ - CSS стилі
```

### **🚫 Папки які НЕ ТРЕБА чіпати:**
```bash
/components/ui/ - ShadCN компоненти (автогенерація)
/components/figma/ - Figma інтеграція
/node_modules/ - пакети (автоматично)
```

---

## ✅ СТАТУС КЛЮЧОВИХ ФАЙЛІВ

### **🟢 Готові та працюють:**
```bash
✅ App.tsx - роутинг з URL параметрами
✅ DNSDiagnostics.tsx - повна DNS діагностика
✅ globals.css - стилі з українськими класами
✅ всі React компоненти
✅ документація (25+ файлів)
```

### **🟡 Потребують перевірки:**
```bash
⚠️ /public/CNAME - периодично стає папкою
⚠️ /public/_redirects - периодично стає папкою  
⚠️ DNS налаштування urbanheroes.com.ua
```

### **🔴 Проблемні файли:**
```bash
❌ Зайві TSX файли в /public/CNAME/ та /public/_redirects/
❌ Потрібно видалити та залишити тільки файли
```

---

**🇺🇦 SLAVA UKRAINI!**

**📍 КЛЮЧОВА ІНФОРМАЦІЯ:**
- **DNS діагностика**: `?page=dns` в URL  
- **Головний файл**: `/App.tsx`
- **Домен файл**: `/public/CNAME` (urbanheroes.com.ua)
- **Документація**: `/docs/` папка (25+ гайдів)

**💡 ПІДКАЗКА:** Якщо файли CNAME чи _redirects знову стануть папками - одразу видаліть папки та створіть файли з правильним змістом!**