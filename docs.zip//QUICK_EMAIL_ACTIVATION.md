# ⚡ ШВИДКА АКТИВАЦІЯ info@urbanheroes.com.ua

## 🎯 МЕТА: Активувати пошту за 20 хвилин

### **📧 3 КРОКИ ДО РОБОЧОЇ ПОШТИ:**

#### **🌐 КРОК 1: Домен (5 хвилин)**
```bash
# Якщо домену немає:
1. Купіть urbanheroes.com.ua на nic.ua (~250 грн/рік)
2. Або активуйте наявний домен
3. Отримайте доступ до DNS панелі
```

#### **📧 КРОК 2: Email сервіс (10 хвилин)**
```bash
# Рекомендовано: Yandex Connect (безкоштовно)
1. Сайт: https://connect.yandex.com
2. "Start using for free"
3. Додайте домен: urbanheroes.com.ua
4. Підтвердьте домен через TXT запис
5. Створіть користувача: info
```

#### **⚙️ КРОК 3: DNS налаштування (5 хвилин)**
```bash
# У панелі управління доменом додайте:

TXT запис (підтвердження):
Ім'я: @
Значення: [код підтвердження від Yandex]

MX запис (пошта):
Ім'я: @
Значення: mx.yandex.net
Пріоритет: 10

SPF запис (безпека):
Ім'я: @
Тип: TXT
Значення: v=spf1 include:_spf.yandex.net ~all
```

---

## ✅ РЕЗУЛЬТАТ

**🎉 Через 20 хвилин:**
- ✅ **info@urbanheroes.com.ua** працює
- ✅ **Веб-інтерфейс** доступний
- ✅ **Мобільні додатки** налаштовані
- ✅ **Безкоштовно** назавжди
- ✅ **Антиспам** захист включений

### **📱 Доступ до пошти:**
- **Веб**: https://mail.yandex.com
- **Android**: Yandex Mail з Play Store
- **iOS**: Yandex Mail з App Store
- **Desktop**: Thunderbird, Outlook (IMAP/SMTP)

### **⚙️ Налаштування для клієнтів:**
```
IMAP: imap.yandex.com:993 (SSL)
SMTP: smtp.yandex.com:465 (SSL)
Логін: info@urbanheroes.com.ua
Пароль: [встановлений в Yandex]
```

### **💰 Вартість:**
- **Email сервіс**: БЕЗКОШТОВНО (Yandex до 1000 користувачів)
- **Домен**: 250-400 грн/рік
- **Обслуговування**: БЕЗКОШТОВНО

---

## 🆘 АЛЬТЕРНАТИВИ

### **🔄 Якщо Yandex не підходить:**

#### **Google Workspace ($6/міс):**
```bash
1. https://workspace.google.com
2. Add domain urbanheroes.com.ua
3. MX: aspmx.l.google.com (пріоритет 1)
4. Gmail інтерфейс + Google Drive 30GB
```

#### **Zoho Mail (безкоштовно):**
```bash
1. https://www.zoho.com/mail
2. Free plan до 5 користувачів
3. MX: mx.zoho.com (пріоритет 10)
4. 5GB на поштову скриньку
```

#### **ProtonMail Plus ($4/міс):**
```bash
1. https://proton.me
2. Custom domain support
3. End-to-end шифрування
4. Максимальна приватність
```

---

## 🔍 ПЕРЕВІРКА РОБОТИ

### **✅ Тестування після налаштування:**

```bash
1. DNS перевірка: https://dnschecker.org
   Тип: MX, Домен: urbanheroes.com.ua
   
2. Email тест: https://mxtoolbox.com
   Email Health Check: info@urbanheroes.com.ua
   
3. Відправка тестового листа:
   - З Gmail на info@urbanheroes.com.ua
   - Перевірити доставку та відповідь
```

---

## 📧 ДОДАТКОВІ EMAIL АДРЕСИ

### **🎯 Рекомендовані для Urban Heroes:**

```
admin@urbanheroes.com.ua - адміністрація
support@urbanheroes.com.ua - підтримка
veterans@urbanheroes.com.ua - ветеранські програми
youth@urbanheroes.com.ua - молодіжні проекти
press@urbanheroes.com.ua - прес-служба
volunteer@urbanheroes.com.ua - волонтерство
contact@urbanheroes.com.ua - загальні питання
```

### **💡 Налаштування автопересилання:**
У Yandex Connect можна налаштувати, щоб всі листи йшли на одну основну скриньку.

---

**🇺🇦 ГОТОВО! info@urbanheroes.com.ua АКТИВНА ТА ГОТОВА ДО РОБОТИ!** 📧

**📞 Тепер Urban Heroes має:**
- ✅ Сайт: https://urbanheroes.com.ua
- ✅ Email: info@urbanheroes.com.ua
- ✅ Телефон: +38(095)670-52-20
- ✅ Офіційну назву: ГО "Міські герої" - Громадська організація