# ⚡ Швидке налаштування домену urbanheroes.com.ua

## 🚀 ШВИДКИЙ СТАРТ (15 хвилин)

### **📋 Передумови:**
- ✅ Домен urbanheroes.com.ua зареєстрований
- ✅ Доступ до DNS панелі
- ✅ GitHub акаунт

---

## 🎯 НАЙШВИДШИЙ СПОСІБ - VERCEL

### **Крок 1: GitHub (2 хвилини)**
```bash
git init
git add .
git commit -m "Urban Heroes Ukraine - готовий до публікації"
git remote add origin https://github.com/[username]/urban-heroes-ukraine.git
git push -u origin main
```

### **Крок 2: Vercel деплой (3 хвилини)**
1. 🌐 Йдіть на **vercel.com** → увійдіть через GitHub
2. ➕ **New Project** → виберіть ваш репозиторій
3. 🚀 **Deploy** (налаштування автоматичні)

### **Крок 3: Підключення домену (5 хвилин)**
1. 🎛️ **Vercel Dashboard** → **Settings** → **Domains**
2. ➕ Додати: `urbanheroes.com.ua` та `www.urbanheroes.com.ua`

### **Крок 4: DNS налаштування (5 хвилин)**
У панелі вашого реєстратора доменів:

```
A запис:
Ім'я: @
Значення: 76.76.19.61

A запис:
Ім'я: www
Значення: 76.76.19.61
```

**АБО (якщо підтримуються CNAME для @):**
```
CNAME запис:
Ім'я: @
Значення: cname.vercel-dns.com

CNAME запис:
Ім'я: www
Значення: cname.vercel-dns.com
```

---

## ⏰ ОЧІКУВАННЯ

- **🌐 DNS поширення**: 15 хвилин - 24 години
- **🔒 SSL активація**: 1-2 години після DNS
- **📊 Індексація Google**: 1-7 днів

---

## ✅ ПЕРЕВІРКА РОБОТИ

Через 15-30 хвилин перевірте:

1. **🌐 Основний сайт**: https://urbanheroes.com.ua
2. **🌍 З www**: https://www.urbanheroes.com.ua  
3. **🔒 SSL**: зелений замок в браузері
4. **📱 Мобільна версія**: коректне відображення

---

## 📧 ШВИДКЕ НАЛАШТУВАННЯ EMAIL

### **Formspree (рекомендовано):**
1. 📧 Реєстрація на **formspree.io**
2. ➕ Створити форму для **info@urbanheroes.com.ua**
3. 📋 Отримати Form ID
4. 🔧 Оновити Contact.tsx з новим action URL

---

## 🆘 ЯКЩО ЩОСЬ НЕ ПРАЦЮЄ

### **🌐 Сайт не відкривається:**
- ⏰ Зачекайте 24 години
- 🧹 Очистіть кеш браузера (Ctrl+F5)
- 🔍 Перевірте: `nslookup urbanheroes.com.ua`

### **🔒 SSL помилка:**
- ⏰ Зачекайте 2 години після DNS
- 🔄 У Vercel: **Domains** → **Refresh SSL**

### **📧 Форми не працюють:**
- ✅ Налаштуйте Formspree ID
- 📧 Перевірте email info@urbanheroes.com.ua

---

## 📞 ШВИДКА ПІДТРИМКА

**🎯 Vercel підтримка**: vercel.com/support
**📚 Повний гайд**: [DOMAIN_SETUP_GUIDE.md](./DOMAIN_SETUP_GUIDE.md)

---

## 🏆 ГОТОВО!

Після налаштування ваш сайт буде доступний:
- 🌐 **https://urbanheroes.com.ua**
- 📧 **info@urbanheroes.com.ua** 
- 🔒 **SSL захищений**
- 📱 **PWA готовий**

🎉 **Слава Україні! Проект Urban Heroes онлайн!** 🇺🇦