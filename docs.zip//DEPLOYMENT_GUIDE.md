# 🚀 Інструкція з публікації Urban Heroes Ukraine

## 🎯 ШВИДКИЙ СТАРТ - Публікація за 20 хвилин

### **📋 Передумови:**
- ✅ GitHub акаунт
- ✅ Домен urbanheroes.com.ua (зареєстрований)
- ✅ Готовий код проекту

---

## 🌐 ВАРІАНТ 1: Vercel (РЕКОМЕНДОВАНИЙ)

### **🔧 Крок 1: Підготовка коду**
1. Завантажте проект на GitHub:
```bash
git init
git add .
git commit -m "Initial commit - Urban Heroes Ukraine"
git remote add origin https://github.com/[your-username]/urban-heroes-ukraine.git
git push -u origin main
```

### **🚀 Крок 2: Деплой через Vercel**
1. Перейдіть на: **vercel.com**
2. Увійдіть через GitHub
3. Натисніть "New Project"
4. Виберіть репозиторій `urban-heroes-ukraine`
5. Налаштування:
   ```
   Framework Preset: Vite
   Build Command: npm run build
   Output Directory: dist
   Install Command: npm install
   ```
6. Натисніть "Deploy"

### **🌍 Крок 3: Підключення домену urbanheroes.com.ua**
1. У Vercel Dashboard → Project Settings → Domains
2. Додайте домени:
   - `urbanheroes.com.ua`
   - `www.urbanheroes.com.ua`
3. Vercel надасть DNS записи для налаштування

### **📡 Крок 4: DNS налаштування**
У панелі вашого реєстратора доменів додайте:

```
A записи:
@ → 76.76.19.61
www → 76.76.19.61

CNAME запис:
www → cname.vercel-dns.com
```

**Альтернативно (для Cloudflare/інших DNS):**
```
CNAME записи:
@ → cname.vercel-dns.com
www → cname.vercel-dns.com
```

---

## 🎨 ВАРІАНТ 2: Netlify

### **🔧 Крок 1: Деплой через Netlify**
1. Перейдіть на: **netlify.com**
2. Увійдіть через GitHub
3. "New site from Git" → GitHub → виберіть репозиторій
4. Налаштування:
   ```
   Build Command: npm run build
   Publish Directory: dist
   ```
5. Натисніть "Deploy site"

### **🌍 Крок 2: Підключення домену**
1. Site Settings → Domain Management
2. Add Custom Domain: `urbanheroes.com.ua`
3. Netlify надась DNS записи

### **📡 Крок 3: DNS налаштування для Netlify**
```
A записи:
@ → 75.2.60.5
www → 75.2.60.5

CNAME запис (якщо підтримується):
@ → [your-site-name].netlify.app
www → [your-site-name].netlify.app
```

---

## 📊 ВАРІАНТ 3: GitHub Pages

### **🔧 Налаштування GitHub Pages**
1. Repository → Settings → Pages
2. Source: GitHub Actions
3. Створіть файл `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages
on:
  push:
    branches: [ main ]
jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-node@v3
      with:
        node-version: '18'
    - run: npm install
    - run: npm run build
    - uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
        cname: urbanheroes.com.ua
```

### **📡 DNS для GitHub Pages**
```
CNAME запис:
@ → [username].github.io
www → [username].github.io
```

---

## 🔐 SSL СЕРТИФІКАТИ

### **🌟 Автоматичні SSL (Vercel/Netlify):**
- ✅ Автоматично генеруються Let's Encrypt сертифікати
- ✅ Автоматичне оновлення
- ✅ Не потребує налаштування

### **🔧 GitHub Pages SSL:**
- ✅ Автоматично після підключення custom domain
- ⏱️ Може займати до 24 годин

---

## 📧 ІНТЕГРАЦІЯ З EMAIL

### **🔗 Підключення email форм:**
1. Contact форма використовує Netlify Forms (якщо Netlify)
2. Для Vercel додайте Formspree або EmailJS
3. Налаштуйте email-сповіщення на info@urbanheroes.com.ua

### **📬 Налаштування форм:**
```html
<!-- Для Netlify -->
<form name="contact" method="POST" data-netlify="true">
  <input type="hidden" name="form-name" value="contact" />
  <!-- form fields -->
</form>

<!-- Для Vercel з Formspree -->
<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
  <!-- form fields -->
</form>
```

---

## 🎯 ОПТИМІЗАЦІЯ ТА SEO

### **⚡ Після публікації:**

#### **1. Перевірте SEO:**
- Google Search Console: `https://search.google.com/search-console`
- Додайте sitemap: `https://urbanheroes.com.ua/sitemap.xml`

#### **2. Налаштуйте аналітику:**
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>

<!-- Yandex Metrica (для України) -->
<script src="https://mc.yandex.ru/metrika/watch.js"></script>
```

#### **3. Соціальні мережі:**
- Фейсбук: додайте Open Graph meta tags
- Телеграм: створіть канал @urbanheroes_ua
- Інстаграм: @urbanheroes.com.ua

#### **4. Монітороінг:**
- UptimeRobot: моніторинг доступності сайту
- PageSpeed Insights: швидкість завантаження

---

## 🆘 ВИРІШЕННЯ ПРОБЛЕМ

### **🌐 Сайт не відкривається:**
1. Перевірте DNS: `nslookup urbanheroes.com.ua`
2. Зачекайте 24-48 годин після зміни DNS
3. Очистіть кеш браузера (Ctrl+F5)

### **🔒 SSL помилки:**
1. Vercel/Netlify: зачекайте 1-2 години
2. Перевірте, чи правильно налаштовані CNAME записи
3. Примусове оновлення SSL в панелі хостингу

### **📱 PWA не працює:**
1. Перевірте manifest.json доступність
2. Переконайтеся, що сайт працює через HTTPS
3. Очистіть кеш Service Worker

### **📊 Аналітика не працює:**
1. Перевірте Google Analytics ID
2. Переконайтеся в правильності domain налаштувань
3. Додайте сайт в Google Search Console

---

## 📞 ПІДТРИМКА ТА КОНТАКТИ

### **🎯 Технічна підтримка:**
- **Vercel:** vercel.com/support
- **Netlify:** docs.netlify.com
- **GitHub:** support.github.com

### **📧 Після публікації:**
- Тестуйте всі форми та email
- Перевірте роботу на мобільних пристроях
- Протестуйте PWA функціонал
- Налаштуйте резервне копіювання

---

## 🏆 УСПІШНА ПУБЛІКАЦІЯ

Після завершення всіх кроків ваш сайт Urban Heroes буде доступний за адресою:
- **🌐 Основний:** https://urbanheroes.com.ua
- **📧 Email:** info@urbanheroes.com.ua
- **📱 PWA:** додаток можна встановити на телефон
- **🌍 SEO:** індексація в Google/Yandex
- **🔒 SSL:** захищене з'єднання

🎉 **Слава Україні! Ваш проект Urban Heroes готовий служити українському народу!** 🇺🇦