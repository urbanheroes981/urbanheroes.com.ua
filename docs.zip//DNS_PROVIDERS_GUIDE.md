# 📡 Налаштування DNS для urbanheroes.com.ua - Інструкції для провайдерів

## 🇺🇦 УКРАЇНСЬКІ DNS ПРОВАЙДЕРИ

### **🌐 Hostinger Ukraine**
1. **Панель управління**: hpanel.hostinger.com
2. **DNS Zone Editor** → додати записи:
```
Type: A
Name: @
Content: 76.76.19.61
TTL: 14400

Type: A  
Name: www
Content: 76.76.19.61
TTL: 14400

Type: CNAME
Name: www
Content: cname.vercel-dns.com
TTL: 14400
```

### **🌍 Ukraine.com.ua**
1. **Панель**: ukraine.com.ua → DNS управління
2. **Додати записи**:
```
A-запис:
Субдомен: @
IP: 76.76.19.61

A-запис:
Субдомен: www
IP: 76.76.19.61
```

### **💙 OVH Ukraine**
1. **Панель**: ovh.com → Домени → DNS зона
2. **Додати запис**:
```
Тип: A
Піддомен: пусто
Мета: 76.76.19.61

Тип: A
Піддомен: www
Мета: 76.76.19.61
```

---

## 🌍 МІЖНАРОДНІ ПРОВАЙДЕРИ

### **☁️ Cloudflare**
1. **Dashboard**: dash.cloudflare.com
2. **DNS** → **Records**:
```
Type: A
Name: @
IPv4 address: 76.76.19.61
Proxy status: 🟠 DNS only

Type: A
Name: www  
IPv4 address: 76.76.19.61
Proxy status: 🟠 DNS only
```

**❗ ВАЖЛИВО**: Вимкніть Cloudflare Proxy (оранжева хмарка) на початку!

### **🔵 Namecheap**
1. **Dashboard**: namecheap.com → Domain List → Manage
2. **Advanced DNS**:
```
Type: A Record
Host: @
Value: 76.76.19.61
TTL: Automatic

Type: A Record
Host: www
Value: 76.76.19.61  
TTL: Automatic
```

### **🟢 GoDaddy**
1. **Dashboard**: godaddy.com → My Domains → DNS
2. **DNS Records**:
```
Type: A
Name: @
Value: 76.76.19.61
TTL: 1 Hour

Type: A
Name: www
Value: 76.76.19.61
TTL: 1 Hour
```

---

## 🏢 КОРПОРАТИВНІ РІШЕННЯ

### **📊 Route 53 (AWS)**
1. **Console**: console.aws.amazon.com/route53
2. **Hosted Zones** → Ваша зона:
```json
{
  "Type": "A",
  "Name": "urbanheroes.com.ua",
  "ResourceRecords": [{"Value": "76.76.19.61"}],
  "TTL": 300
}

{
  "Type": "A", 
  "Name": "www.urbanheroes.com.ua",
  "ResourceRecords": [{"Value": "76.76.19.61"}],
  "TTL": 300
}
```

### **🔷 Azure DNS**
1. **Portal**: portal.azure.com → DNS zones
2. **Record sets**:
```
Name: @
Type: A
TTL: 1
IP Address: 76.76.19.61

Name: www
Type: A
TTL: 1
IP Address: 76.76.19.61
```

---

## 🔄 АЛЬТЕРНАТИВНИЙ МЕТОД (CNAME)

Якщо ваш провайдер підтримує CNAME для root домену:

```
Type: CNAME
Name: @
Target: cname.vercel-dns.com
TTL: 300

Type: CNAME
Name: www
Target: cname.vercel-dns.com  
TTL: 300
```

**✅ Підтримують CNAME для @**: Cloudflare, AWS Route 53, Azure DNS
**❌ НЕ підтримують**: большинство .ua реєстраторів

---

## 📧 НАЛАШТУВАННЯ EMAIL DNS

Для роботи email адрес додайте MX записи:

### **📬 Google Workspace (рекомендовано):**
```
Type: MX
Name: @
Priority: 1
Value: aspmx.l.google.com

Type: MX
Name: @  
Priority: 5
Value: alt1.aspmx.l.google.com

Type: MX
Name: @
Priority: 10  
Value: alt2.aspmx.l.google.com
```

### **📧 Простий email forwarding:**
```
Type: MX
Name: @
Priority: 10
Value: mail.urbanheroes.com.ua

Type: A
Name: mail
Value: [IP вашого email сервера]
```

---

## 🔍 ПЕРЕВІРКА НАЛАШТУВАНЬ

### **🛠️ Команди для перевірки:**
```bash
# Перевірка A записів
dig A urbanheroes.com.ua
nslookup urbanheroes.com.ua

# Перевірка з www
dig A www.urbanheroes.com.ua

# Перевірка MX записів
dig MX urbanheroes.com.ua

# Повна інформація
dig ANY urbanheroes.com.ua
```

### **🌐 Онлайн інструменти:**
- **DNS Checker**: dnschecker.org
- **What's My DNS**: whatsmydns.net  
- **MX Toolbox**: mxtoolbox.com
- **DNS Propagation**: dnspropagation.net

---

## ⏰ ЧАС ПОШИРЕННЯ

### **🕐 Типовий час:**
- **Локальний DNS**: 15-30 хвилин
- **Провайдери**: 1-4 години  
- **Глобальне поширення**: 24-48 годин
- **TTL залежить**: від встановленого значення

### **⚡ Прискорення поширення:**
```bash
# Очистка локального DNS кешу
# Windows:
ipconfig /flushdns

# macOS:
sudo dscacheutil -flushcache

# Linux:
sudo systemctl restart systemd-resolved
```

---

## 🆘 ПОШИРЕНІ ПРОБЛЕМИ

### **❌ "DNS_PROBE_FINISHED_NXDOMAIN"**
- 🔍 Перевірте правильність записів
- ⏰ Зачекайте поширення DNS
- 🧹 Очистіть DNS кеш

### **❌ "This site can't be reached"**
- 📡 Перевірте A записи командою `dig`
- 🔄 Перевірте TTL налаштування
- 📞 Зверніться до DNS провайдера

### **❌ "SSL Certificate error"**
- ⏰ Зачекайте 24 години після DNS
- 🔒 Перевірте в Vercel панелі статус SSL
- 🔄 Примусово оновіть SSL сертифікат

### **❌ "www не працює"**
- ✅ Додайте окремий A запис для www
- 🔄 Перевірте CNAME запис
- 📋 Переконайтеся в налаштуванні редиректів

---

## 📋 ЧЕКЛІСТ НАЛАШТУВАННЯ

### **✅ DNS Записи:**
- [ ] A запис для @ → 76.76.19.61
- [ ] A запис для www → 76.76.19.61  
- [ ] TTL встановлений (300-3600 секунд)
- [ ] Записи збережені та активовані

### **✅ Vercel налаштування:**
- [ ] Домен доданий в Vercel
- [ ] SSL статус: активний
- [ ] Custom domains налаштовані
- [ ] Redirects працюють

### **✅ Тестування:**
- [ ] `dig urbanheroes.com.ua` повертає 76.76.19.61
- [ ] `dig www.urbanheroes.com.ua` повертає 76.76.19.61
- [ ] Сайт відкривається з https://
- [ ] Редирект з www працює

---

## 📞 СЛУЖБА ПІДТРИМКИ

### **🎯 За провайдерами:**
- **Hostinger**: support.hostinger.com
- **Cloudflare**: support.cloudflare.com  
- **Namecheap**: support.namecheap.com
- **GoDaddy**: support.godaddy.com

### **📧 Типові питання для підтримки:**
```
Тема: Налаштування A записів для urbanheroes.com.ua

Потрібно додати наступні DNS записи:

A запис:
Ім'я: @
Значення: 76.76.19.61

A запис:  
Ім'я: www
Значення: 76.76.19.61

TTL: 300-3600 секунд

Домен: urbanheroes.com.ua
Мета: підключення до Vercel хостингу
```

---

## 🏆 УСПІШНЕ ЗАВЕРШЕННЯ

Після правильного налаштування DNS:

- ✅ **urbanheroes.com.ua** відкривається
- ✅ **www.urbanheroes.com.ua** редиректить
- ✅ SSL сертифікат активний
- ✅ Email форми працюють
- ✅ Сайт готовий до використання

🎉 **Слава Україні! Ваш проект Urban Heroes тепер онлайн!** 🇺🇦