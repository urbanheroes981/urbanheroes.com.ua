export const translations = {
  uk: {
    // Navigation
    nav: {
      home: "Головна",
      about: "Про нас", 
      services: "Послуги",
      veteranProject: "Ветеранський проект",
      youthProject: "Молодіжний проект",
      howItWorks: "Як це працює",
      newsEvents: "Новини та події",
      join: "Долучитися",
      support: "Підтримати",
      contact: "Контакти"
    },
    
    // Hero Section
    hero: {
      slogan: "Кожен може стати героєм",
      description: "Організація \"Міські герої\" об'єднує ветеранів та молодь України для підготовки захисників, відродження традицій та побудови сильної патріотичної спільноти.",
      becomeHero: "Стати героєм зараз",
      youthPrograms: "Молодіжні програми",
      emergencyTech: "Технології екстреного реагування",
      stats: {
        veterans: "Ветеранів і молоді",
        programs: "Програм підготовки", 
        support: "Підтримка спільноти"
      }
    },

    // About Section
    about: {
      title: "Місія організації \"Міські герої\"",
      description: "Ми об'єднуємо ветеранів та молодь України, створюємо платформи для підготовки до служби, відродження традицій та побудови сильної патріотичної спільноти.",
      goals: "Наші цілі та завдання",
      veteranCommunities: "Спільноти ветеранів і молоді",
      veteranCommunitiesDesc: "Створюємо спільноти ветеранів та платформи для взаємодії з молоддю, яка готується до служби",
      militaryTraining: "Військова підготовка",
      militaryTrainingDesc: "Проводимо військові вишколи, тактичну медицину, стрілецьку та фізичну підготовку",
      patrioticEducation: "Патріотичне виховання",
      patrioticEducationDesc: "Виховуємо патріотичну молодь на базі воєнного досвіду, національної історії та сучасної культури",
      ourActivities: "Наша діяльність",
      veteranSupport: "Підтримка ветеранів",
      cultureAndSports: "Культура і спорт",
      achievements: "Наші досягнення",
      veteransSupported: "Ветеранів підтримано",
      youngPatriots: "Молодих патріотів",
      trainingPrograms: "Навчальних програм",
      communitySupport: "Підтримка громади",
      supportVeterans: "Підтримка ветеранів",
      protectRights: "Захист прав ветеранів",
      returnToCivilLife: "Повернення до цивільного життя",
      createVeteranBusiness: "Створення ветеранського бізнесу",
      healthyLiving: "Здоровий спосіб життя",
      ukrainianCombatArts: "Українські бойові мистецтва",
      familyHolidays: "Родинні свята та традиції",
      supportedVeterans: "Ветеранів підтримано",
      patrioticYouth: "Молодих патріотів"
    },

    // Features Section
    features: {
      title: "Наші програми та послуги",
      description: "Ми створюємо комплексні програми для підтримки ветеранів, підготовки молоді до служби та відродження українських траицій через сучасні підходи та технології.",
      readyToBeHero: "Готові стати героєм України?",
      readyDescription: "Приєднуйтесь до нашої спільноти героїв України. Разом ми будуємо сильну, незалежну та процвітаючу державу через підтримку ветеранів та виховання патріотичної молоді.",
      veteranProject: "Ветеранський проект",
      youthPrograms: "Молодіжні програми"
    },

    // Contact Section
    contact: {
      title: "Зв'яжіться з нами",
      description: "Маєте питання щодо діяльності організації \"Міські герої\"? Хочете долучитися до наших програм або підтримати ветеранів і молодь України? Ми завжди готові до спілкування!",
      sendMessage: "Надішліть нам повідомлення",
      formDescription: "Заповніть форму нижче, і ми зв'яжемося з вами протягом 24 годин.",
      firstName: "Ім'я",
      lastName: "Прізвище",
      email: "Електронна пошта",
      phone: "Телефон",
      subject: "Тема",
      message: "Повідомлення",
      sendButton: "Надіслати повідомлення",
      ourOffice: "Наш офіс",
      workingHours: "Години роботи",
      followUs: "Слідкуйте за нами",
      whyWeUnited: "Чому ми об'єдналися в громадську організацію \"Міські герої\"",
      missionStatement: "Ми переконані, що сила України полягає в єдності її захисників та громадян. Наша організація виникла з потреби об'єднати досвід ветеранів АТО/ООС з енергією та патріотизмом молодого покоління...",
      readyToJoin: "Готові стати частиною нашої місії?",
      joinDescription: "Долучайтеся до нас у створенні сильної та незалежної України через підтримку ветеранів, виховання патріотичної молоді та відродження українських традицій.",
      volunteering: "Волонтерство",
      volunteeringDesc: "Станьте волонтером та допомагайте ветеранам і молоді України",
      support: "Підтримка",
      supportDesc: "Фінансово підтримайте наші програми та проекти",
      partnership: "Партнерство",
      partnershipDesc: "Співпрацюйте з нами для реалізації спільних ініціатив",
      startCooperation: "Розпочати співпрацю",
      mondayFriday: "Понеділок - П'ятниця",
      saturday: "Субота", 
      sunday: "Неділя",
      closed: "Закрито"
    },

    // Footer
    footer: {
      quickLinks: "Швидкі посилання",
      platform: "Платформа",
      contacts: "Контакти",
      company: "ГО \"Міські герої\"",
      department: "Громадська організація",
      copyright: "Міські герої. Всі права захищені.",
      privacyPolicy: "Політика конфіденційності",
      termsOfUse: "Умови використання",
      scientificArticle: "Наукова стаття"
    },

    // Common
    common: {
      readMore: "Читати далі",
      learnMore: "Дізнатися більше",
      getStarted: "Розпочати",
      backToHome: "Повернутися на головну",
      loading: "Завантаження...",
      error: "Помилка",
      success: "Успішно",
      required: "Обов'язкове поле"
    },

    // Volunteer Support
    volunteerSupport: {
      title: "Запит на волонтерську підтримку",
      description: "Потрібна допомога з проектом чи ініціативою? Наші волонтери готові підтримати ветеранів, молодь та громадські організації у реалізації важливих проектів.",
      formTitle: "Форма запиту підтримки",
      supportType: "Тип підтримки",
      priority: "Пріоритет",
      location: "Місцезнаходження",
      availability: "Коли потрібна підтримка",
      skills: "Потрібні навички/допомога",
      description: "Опис проекту/потреби",
      contact: "Контактна інформація",
      files: "Додаткові матеріали",
      submit: "Надіслати запит на підтримку",
      submitting: "Надсилання запиту...",
      submitted: "Запит на підтримку прийнято!",
      successMessage: "Ваш запит на волонтерську підтримку надійшов до координаторів організації \"Міські герої\". Ми зв'яжемося з вами найближчим часом для координації дій.",
      submitAnother: "Подати ще один запит",
      successStories: "Історії успіху",
      coordinators: "Контакти координаторів",
      tips: "Поради для запиту",
      volunteerStats: "Активних волонтерів",
      successRate: "Проектів реалізовано успішно"
    }
  },

  en: {
    // Navigation
    nav: {
      home: "Home",
      about: "About Us",
      services: "Services", 
      veteranProject: "Veteran Project",
      youthProject: "Youth Project",
      howItWorks: "How It Works",
      newsEvents: "News & Events",
      join: "Join Us",
      support: "Support",
      contact: "Contact"
    },
    
    // Hero Section
    hero: {
      slogan: "Everyone Can Be a Hero",
      description: "Urban Heroes organization unites veterans and youth of Ukraine to train defenders, revive traditions, and build a strong patriotic community.",
      becomeHero: "Become a Hero Now",
      youthPrograms: "Youth Programs",
      emergencyTech: "Emergency Response Technologies",
      stats: {
        veterans: "Veterans & Youth",
        programs: "Training Programs",
        support: "Community Support"
      }
    },

    // About Section
    about: {
      title: "Mission of \"Urban Heroes\" Organization",
      description: "We unite veterans and youth of Ukraine, create platforms for service preparation, tradition revival, and building a strong patriotic community.",
      goals: "Our Goals and Objectives",
      veteranCommunities: "Veteran & Youth Communities",
      veteranCommunitiesDesc: "We create veteran communities and platforms for interaction with youth preparing for service",
      militaryTraining: "Military Training",
      militaryTrainingDesc: "We conduct military training, tactical medicine, shooting and physical preparation",
      patrioticEducation: "Patriotic Education", 
      patrioticEducationDesc: "We educate patriotic youth based on military experience, national history, and modern culture",
      ourActivities: "Our Activities",
      veteranSupport: "Veteran Support",
      cultureAndSports: "Culture & Sports",
      achievements: "Our Achievements",
      veteransSupported: "Veterans Supported",
      youngPatriots: "Young Patriots",
      trainingPrograms: "Training Programs",
      communitySupport: "Community Support",
      supportVeterans: "Support Veterans",
      protectRights: "Protect Rights of Veterans",
      returnToCivilLife: "Return to Civil Life",
      createVeteranBusiness: "Create Veteran Business",
      healthyLiving: "Healthy Living",
      ukrainianCombatArts: "Ukrainian Combat Arts",
      familyHolidays: "Family Holidays and Traditions",
      supportedVeterans: "Supported Veterans",
      patrioticYouth: "Patriotic Youth"
    },

    // Features Section
    features: {
      title: "Our Programs and Services",
      description: "We create comprehensive programs to support veterans, prepare youth for service, and revive Ukrainian traditions through modern approaches and technologies.",
      readyToBeHero: "Ready to Become a Hero of Ukraine?",
      readyDescription: "Join our community of Ukrainian heroes. Together we build a strong, independent and prosperous state through veteran support and patriotic youth education.",
      veteranProject: "Veteran Project",
      youthPrograms: "Youth Programs"
    },

    // Contact Section
    contact: {
      title: "Contact Us",
      description: "Have questions about Urban Heroes organization activities? Want to join our programs or support veterans and youth of Ukraine? We're always ready to communicate!",
      sendMessage: "Send Us a Message",
      formDescription: "Fill out the form below and we'll contact you within 24 hours.",
      firstName: "First Name",
      lastName: "Last Name", 
      email: "Email",
      phone: "Phone",
      subject: "Subject",
      message: "Message",
      sendButton: "Send Message",
      ourOffice: "Our Office",
      workingHours: "Working Hours",
      followUs: "Follow Us",
      whyWeUnited: "Why We United as \"Urban Heroes\" Public Organization",
      missionStatement: "We believe that Ukraine's strength lies in the unity of its defenders and citizens. Our organization arose from the need to combine the experience of ATO/OOS veterans with the energy and patriotism of the younger generation...",
      readyToJoin: "Ready to Become Part of Our Mission?",
      joinDescription: "Join us in creating a strong and independent Ukraine through veteran support, patriotic youth education, and Ukrainian tradition revival.",
      volunteering: "Volunteering",
      volunteeringDesc: "Become a volunteer and help veterans and youth of Ukraine",
      support: "Support",
      supportDesc: "Financially support our programs and projects",
      partnership: "Partnership",
      partnershipDesc: "Collaborate with us to implement joint initiatives",
      startCooperation: "Start Cooperation",
      mondayFriday: "Monday - Friday",
      saturday: "Saturday", 
      sunday: "Sunday",
      closed: "Closed"
    },

    // Footer
    footer: {
      quickLinks: "Quick Links",
      platform: "Platform",
      contacts: "Contacts",
      company: "Urban Heroes NGO",
      department: "Public Organization",
      copyright: "Urban Heroes. All rights reserved.",
      privacyPolicy: "Privacy Policy",
      termsOfUse: "Terms of Use",
      scientificArticle: "Scientific Article"
    },

    // Common
    common: {
      readMore: "Read More",
      learnMore: "Learn More", 
      getStarted: "Get Started",
      backToHome: "Back to Home",
      loading: "Loading...",
      error: "Error",
      success: "Success",
      required: "Required field"
    },

    // Volunteer Support
    volunteerSupport: {
      title: "Request for Volunteer Support",
      description: "Need help with a project or initiative? Our volunteers are ready to support veterans, youth, and community organizations in implementing important projects.",
      formTitle: "Support Request Form",
      supportType: "Type of Support",
      priority: "Priority",
      location: "Location",
      availability: "When support is needed",
      skills: "Required skills/assistance",
      description: "Project description/need",
      contact: "Contact information",
      files: "Additional materials",
      submit: "Submit support request",
      submitting: "Submitting request...",
      submitted: "Support request accepted!",
      successMessage: "Your request for volunteer support has been sent to the coordinators of the \"Urban Heroes\" organization. We will contact you shortly to coordinate the actions.",
      submitAnother: "Submit another request",
      successStories: "Success Stories",
      coordinators: "Coordinator Contacts",
      tips: "Tips for requesting",
      volunteerStats: "Active Volunteers",
      successRate: "Projects successfully implemented"
    }
  }
};

export type Language = 'uk' | 'en';
export type TranslationKey = keyof typeof translations.uk;