import { Card, CardContent } from './ui/card';
import { 
  Users, 
  Shield, 
  GraduationCap, 
  Heart, 
  ArrowDown, 
  ArrowRight,
  Target,
  Star,
  Handshake
} from 'lucide-react';

export function HowItWorks() {
  const steps = [
    {
      id: 1,
      title: "Об'єднання ветеранів",
      subtitle: "Створення спільнот",
      description: "Формуємо активні спільноти ветеранів АТО/ООС та створюємо платформи для їх взаємодії з молоддю, яка готується до служби Україні.",
      icon: Shield,
      features: ["Ветеранські спільноти", "Ментерство молоді", "Платформи взаємодії"],
      color: "from-blue-600 to-yellow-500"
    },
    {
      id: 2,
      title: "Військова підготовка",
      subtitle: "Професійне навчання",
      description: "Проводимо комплексні військові вишколи: тактичну медицину, стрілецьку підготовку, фізичну підготовку та сучасні військові техніки.",
      icon: Target,
      features: ["Тактична медицина", "Стрілецька підготвка", "Фізичний вишкіл"],
      color: "from-blue-500 to-indigo-600"
    },
    {
      id: 3,
      title: "Патріотичне виховання",
      subtitle: "Формування цінностей",
      description: "Виховуємо свідому патріотичну молодь через вивчення воєнного досвіду, національної історії та сучасної української культури.",
      icon: GraduationCap,
      features: ["Воєнний досвід", "Національна історія", "Українська культура"],
      color: "from-indigo-500 to-purple-600"
    },
    {
      id: 4,
      title: "Соціальна підтримка",
      subtitle: "Повернення до життя",
      description: "Захищаємо права ветеранів, забезпечуємо їхню реінтеграцію у цивільне життя та підтримуємо створення ветеранського бізнесу.",
      icon: Heart,
      features: ["Захист прав", "Реінтеграція", "Ветеранський бізнес"],
      color: "from-purple-500 to-pink-600"
    }
  ];

  return (
    <section className="py-20 relative">
      {/* Ukrainian flag wheat field background */}
      <div className="absolute inset-0 ukrainian-flag-wheat-bg" />
      {/* Patriotic overlay for better readability */}
      <div className="absolute inset-0 ukrainian-flag-wheat-overlay" />
      
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Як ми працюємо
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Наша комплексна система роботи з ветеранами та молоддю забезпечує ефективну підготовку захисників України, 
              їх підтримку та успішну інтеграцію у громадське життя.
            </p>
          </div>

          {/* Process Flow - Desktop */}
          <div className="hidden lg:block">
            <div className="relative">
              {/* Connection Lines */}
              <div className="absolute top-24 left-1/4 right-1/4 h-0.5 bg-gradient-to-r from-blue-200 via-indigo-200 via-purple-200 to-pink-200"></div>
              
              <div className="grid grid-cols-4 gap-8">
                {steps.map((step, index) => {
                  const IconComponent = step.icon;
                  return (
                    <div key={step.id} className="relative">
                      {/* Step Card */}
                      <Card className="hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                        <CardContent className="p-6 text-center">
                          {/* Icon */}
                          <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                            <IconComponent className="w-8 h-8 text-white" />
                          </div>
                          
                          {/* Step Number */}
                          <div className="text-sm font-semibold text-gray-500 mb-2">Етап {step.id}</div>
                          
                          {/* Title */}
                          <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                          <div className="text-sm text-gray-600 mb-4">{step.subtitle}</div>
                          
                          {/* Description */}
                          <p className="text-gray-600 text-sm leading-relaxed mb-4">{step.description}</p>
                          
                          {/* Features */}
                          <div className="space-y-2">
                            {step.features.map((feature, idx) => (
                              <div key={idx} className="flex items-center text-xs text-gray-500">
                                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></div>
                                {feature}
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                      
                      {/* Arrow */}
                      {index < steps.length - 1 && (
                        <div className="absolute top-24 -right-4 transform translate-x-1/2">
                          <div className="w-8 h-8 bg-white rounded-full border-2 border-gray-200 flex items-center justify-center">
                            <ArrowRight className="w-4 h-4 text-gray-400" />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Process Flow - Mobile */}
          <div className="lg:hidden space-y-8">
            {steps.map((step, index) => {
              const IconComponent = step.icon;
              return (
                <div key={step.id} className="relative">
                  <Card className="hover:shadow-xl transition-shadow duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        {/* Icon */}
                        <div className={`w-12 h-12 bg-gradient-to-br ${step.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                          <IconComponent className="w-6 h-6 text-white" />
                        </div>
                        
                        <div className="flex-1">
                          {/* Step Number */}
                          <div className="text-sm font-semibold text-gray-500 mb-1">Етап {step.id}</div>
                          
                          {/* Title */}
                          <h3 className="text-lg font-bold text-gray-900 mb-1">{step.title}</h3>
                          <div className="text-sm text-gray-600 mb-3">{step.subtitle}</div>
                          
                          {/* Description */}
                          <p className="text-gray-600 text-sm leading-relaxed mb-4">{step.description}</p>
                          
                          {/* Features */}
                          <div className="grid grid-cols-1 gap-2">
                            {step.features.map((feature, idx) => (
                              <div key={idx} className="flex items-center text-xs text-gray-500">
                                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></div>
                                {feature}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Arrow */}
                  {index < steps.length - 1 && (
                    <div className="flex justify-center py-4">
                      <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                        <ArrowDown className="w-4 h-4 text-gray-400" />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Key Benefits */}
          <div className="mt-20">
            <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">Наші ключові принципи</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">Професійність</h4>
                <p className="text-gray-600">Найвищі стандарти військової підготовки та професійного розвитку для захисників України</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">Підтримка</h4>
                <p className="text-gray-600">Комплексна психологічна, соціальна та економічна підтримка ветеранів та їх родин</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Star className="w-8 h-8 text-white" />
                </div>
                <h4 className="text-xl font-bold text-gray-900 mb-2">Патріотизм</h4>
                <p className="text-gray-600">Виховання національно свідомої молоді на основі українських традицій та сучасних цінностей</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}