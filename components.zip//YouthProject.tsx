import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  Lightbulb, 
  Users, 
  Rocket, 
  Code, 
  Palette,
  Music,
  Star,
  BookOpen,
  Zap
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import urbanHeroesLogo from 'figma:asset/423625f3a2b4c69d6e08cc5e69ed67681896dd69.png';
import ukrainianSunsetFieldImage from 'figma:asset/a4255f299c9b37d54112ddfeac28a4ba0a6a0894.png';

interface YouthProjectProps {
  onPageChange?: (page: string) => void;
}

export function YouthProject({ onPageChange }: YouthProjectProps) {
  const programs = [
    {
      icon: Code,
      title: "IT Герої",
      description: "Навчання програмуванню, створенню сайтів та мобільних додатків для майбутніх ІТ-спеціалістів.",
      color: "from-blue-500 to-indigo-600",
      participants: "250+ учасників"
    },
    {
      icon: Lightbulb,
      title: "Молоді підприємці",
      description: "Програма розвитку підприємницьких навичок та підтримки стартапів серед молоді.",
      color: "from-yellow-500 to-orange-600",
      participants: "180+ учасників"
    },
    {
      icon: Palette,
      title: "Творчі майстерні",
      description: "Художні, дизайнерські та креативні проекти для розвитку творчих здібностей молоді.",
      color: "from-pink-500 to-purple-600",
      participants: "320+ учасників"
    },
    {
      icon: Users,
      title: "Волонтерський рух",
      description: "Організація соціальних проектів та благодійних ініціатив серед молодих героїв міста.",
      color: "from-green-500 to-teal-600",
      participants: "500+ волонтерів"
    },
    {
      icon: Music,
      title: "Музичні герої",
      description: "Музичні гуртки, концерти та фестивалі для розвитку музичних талантів молоді.",
      color: "from-purple-500 to-indigo-600",
      participants: "150+ музикантів"
    },
    {
      icon: BookOpen,
      title: "Школа лідерства",
      description: "Розвиток лідерських якостей та навичок управління проектами серед активної молоді.",
      color: "from-red-500 to-pink-600",
      participants: "200+ лідерів"
    }
  ];

  return (
    <section className="py-20 relative">
      {/* Ukrainian sunset field background */}
      <div className="absolute inset-0 z-0">
        <img
          src={ukrainianSunsetFieldImage}
          alt="Ukrainian flag in sunset wheat field"
          className="w-full h-full object-cover"
        />
        
        {/* Sunset overlay for better readability */}
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm" />
        
        {/* Warm sunset gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-orange-400/15 via-transparent to-blue-500/10" />
      </div>
      
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <div className="flex items-center justify-center mb-6">
              <img 
                src={urbanHeroesLogo} 
                alt="Urban Heroes Logo" 
                className="h-16 w-auto object-contain drop-shadow-lg"
              />
            </div>
            <div className="flex items-center justify-center space-x-3 mb-6">
              <Rocket className="w-10 h-10 text-blue-500" />
              <Star className="w-8 h-8 text-yellow-500" />
              <Zap className="w-10 h-10 text-purple-500" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Проект "Молоді герої майбутнього"
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Програма розвитку та підтримки талановитої молоді України. Ми надаємо можливості для 
              навчання, творчості та реалізації амбітних проектів молодих героїв нашого міста.
            </p>
          </div>

          {/* Programs Grid */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Наші програми розвитку
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {programs.map((program, index) => {
                const IconComponent = program.icon;
                return (
                  <Card 
                    key={index} 
                    className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 shadow-lg"
                  >
                    <CardHeader className="text-center pb-4">
                      <div className={`w-16 h-16 bg-gradient-to-br ${program.color} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <IconComponent className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-xl text-gray-900">{program.title}</CardTitle>
                      <div className="text-sm text-blue-600 font-medium">{program.participants}</div>
                    </CardHeader>
                    <CardContent className="text-center">
                      <p className="text-gray-600 leading-relaxed">{program.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-12 text-white text-center mb-20">
            <h2 className="text-3xl font-bold mb-8">Наші досягнення у цифрах</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <div className="text-4xl font-bold mb-2">1500+</div>
                <div className="text-purple-100">Активних учасників</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">50+</div>
                <div className="text-purple-100">Реалізованих проектів</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">25</div>
                <div className="text-purple-100">Наград та перемог</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">98%</div>
                <div className="text-purple-100">Задоволених учасників</div>
              </div>
            </div>
          </div>

          {/* Join Us Section */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              Приєднуйся до нас!
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Маєш ідеї для покращення міста? Хочеш розвивати свої таланти? 
              Станьте частиною спільноти молодих героїв!
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => onPageChange?.('contact')}
                className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Rocket className="w-5 h-5" />
                <span>Подати заявку</span>
              </button>
              <button 
                onClick={() => onPageChange?.('about')}
                className="border-2 border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Users className="w-5 h-5" />
                <span>Дізнатися більше</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}