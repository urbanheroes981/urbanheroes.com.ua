import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { 
  Mail, 
  MapPin, 
  Phone, 
  Users, 
  Clock,
  Globe,
  Facebook,
  Instagram,
  ExternalLink,
  Heart,
  Shield
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export function Contact() {
  const { t } = useLanguage();

  const officeHours = [
    { day: t('contact.mondayFriday') || 'Понеділок - П\'ятниця', time: '09:00 - 18:00' },
    { day: t('contact.saturday') || 'Субота', time: '10:00 - 15:00' },
    { day: t('contact.sunday') || 'Неділя', time: t('contact.closed') || 'Закрито' }
  ];

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, url: 'https://facebook.com/urbanheroes', color: 'text-blue-600' },
    { name: 'Instagram', icon: Instagram, url: 'https://instagram.com/urbanheroes', color: 'text-pink-600' },
    { name: 'Telegram', icon: Globe, url: 'https://t.me/urbanheroes', color: 'text-blue-500' },
  ];

  return (
    <div className="min-h-screen relative">
      {/* Light overlay for better readability with Ukrainian flag background */}
      <div className="absolute inset-0 bg-white/90 backdrop-blur-sm" />
      
      <div className="relative z-10">
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Header */}
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                {t('contact.title')}
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                {t('contact.description')}
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
              {/* Contact Form */}
              <Card className="shadow-xl">
                <CardHeader>
                  <CardTitle className="text-2xl text-gray-900">{t('contact.sendMessage')}</CardTitle>
                  <p className="text-gray-600">
                    {t('contact.formDescription')}
                  </p>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">{t('contact.firstName')} *</Label>
                        <Input id="firstName" placeholder={t('contact.firstName')} className="mt-1" required />
                      </div>
                      <div>
                        <Label htmlFor="lastName">{t('contact.lastName')} *</Label>
                        <Input id="lastName" placeholder={t('contact.lastName')} className="mt-1" required />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="email">{t('contact.email')} *</Label>
                      <Input id="email" type="email" placeholder="your.email@example.com" className="mt-1" required />
                    </div>
                    
                    <div>
                      <Label htmlFor="phone">{t('contact.phone')}</Label>
                      <Input id="phone" type="tel" placeholder="+38 (099) 123-45-67" className="mt-1" />
                    </div>
                    
                    <div>
                      <Label htmlFor="subject">{t('contact.subject')} *</Label>
                      <Input id="subject" placeholder={t('contact.subject')} className="mt-1" required />
                    </div>
                    
                    <div>
                      <Label htmlFor="message">{t('contact.message')} *</Label>
                      <Textarea 
                        id="message" 
                        placeholder={t('contact.message')}
                        className="mt-1 min-h-[120px]"
                        required 
                      />
                    </div>
                    
                    <Button type="submit" className="w-full bg-gradient-to-r from-blue-600 to-yellow-500 text-white">
                      <Mail className="w-4 h-4 mr-2" />
                      {t('contact.sendButton')}
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <div className="space-y-8">
                {/* Office Info */}
                <Card className="shadow-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <MapPin className="w-5 h-5 mr-2 text-blue-600" />
                      Наш офіс
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-2">Громадська організація "Міські герої"</h3>
                      <p className="text-gray-600">вул. Хрещатик, 25, офіс 301</p>
                      <p className="text-gray-600">Київ, 01001, Україна</p>
                    </div>
                    
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>+38(095)6705220</span>
                    </div>
                    
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>info@urbanheroes.com.ua</span>
                    </div>
                    
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Globe className="w-4 h-4" />
                      <a href="https://www.urbanheroes.com.ua" className="text-blue-600 hover:text-blue-700">
                        www.urbanheroes.com.ua
                        <ExternalLink className="w-3 h-3 ml-1 inline" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Working Hours */}
                <Card className="shadow-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Clock className="w-5 h-5 mr-2 text-blue-600" />
                      Години роботи
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {officeHours.map((schedule, index) => (
                      <div key={index} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                        <span className="text-gray-700">{schedule.day}</span>
                        <span className="font-medium text-gray-900">{schedule.time}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Social Media */}
                <Card className="shadow-xl">
                  <CardHeader>
                    <CardTitle>Слідкуйте за нами</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {socialLinks.map((social, index) => {
                      const IconComponent = social.icon;
                      return (
                        <a 
                          key={index}
                          href={social.url} 
                          className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <IconComponent className={`w-5 h-5 mr-3 ${social.color}`} />
                          <div>
                            <div className="font-medium text-gray-900">{social.name}</div>
                            <div className="text-sm text-gray-600">Останні новини та оновлення</div>
                          </div>
                          <ExternalLink className="w-4 h-4 ml-auto text-gray-400" />
                        </a>
                      );
                    })}
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Mission Statement */}
            <div className="mb-20">
              <Card className="shadow-xl">
                <CardContent className="p-12 text-center">
                  <div className="flex items-center justify-center space-x-4 mb-6">
                    <Shield className="w-12 h-12 text-blue-600" />
                    <Heart className="w-10 h-10 text-yellow-500" />
                    <Users className="w-12 h-12 text-blue-600" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-6">
                    Чому ми об'єдналися в громадську організацію "Міські герої"
                  </h3>
                  <p className="text-xl text-gray-600 leading-relaxed max-w-4xl mx-auto">
                    Ми переконані, що сила України полягає в єдності її захисників та громадян. 
                    Наша організація виникла з потреби об'єднати досвід ветеранів АТО/ООС з енергією 
                    та патріотизмом молодого покоління. Разом ми створюємо міцний фундамент для 
                    відродження української культури, підготовки нових захисників та підтримки тих, 
                    хто вже пройшов шлях служіння Україні. Кожен може стати героєм - 
                    це не просто слоган, а наша життєва філософія.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* CTA Section */}
            <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-center text-white">
              <h3 className="text-3xl font-bold mb-4">Готові стати частиною нашої місії?</h3>
              <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
                Долучайтеся до нас у створенні сильної та незалежної України через підтримку ветеранів, 
                виховання патріотичної молоді та відродження українських традицій.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <div>
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <Users className="w-6 h-6" />
                  </div>
                  <h4 className="font-semibold mb-2">Волонтерство</h4>
                  <p className="text-sm text-blue-100">Станьте волонтером та допомагайте ветеранам і молоді України</p>
                </div>
                
                <div>
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <Heart className="w-6 h-6" />
                  </div>
                  <h4 className="font-semibold mb-2">Підтримка</h4>
                  <p className="text-sm text-blue-100">Фінансово підтримайте наші програми та проекти</p>
                </div>
                
                <div>
                  <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-3">
                    <Shield className="w-6 h-6" />
                  </div>
                  <h4 className="font-semibold mb-2">Партнерство</h4>
                  <p className="text-sm text-blue-100">Співпрацюйте з нами для реалізації спільних ініціатив</p>
                </div>
              </div>
              
              <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
                <Mail className="w-5 h-5 mr-2" />
                Розпочати співпрацю
              </Button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}