import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  Heart, 
  Users, 
  GraduationCap,
  HandHeart,
  Shield,
  Target,
  ArrowRight,
  Check,
  Star,
  Phone,
  Mail,
  MessageCircle,
  FileText,
  UserPlus
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import heroLogo from 'figma:asset/db70ba7fd23873889e37f7b0bf8a96eb8f12323a.png';

interface JoinUsProps {
  onPageChange?: (page: string) => void;
}

export function JoinUs({ onPageChange }: JoinUsProps) {
  const volunteerOptions = [
    {
      icon: Shield,
      title: "Інструктор військової підготовки",
      description: "Проводьте заняття з тактичної медицини, стрілецької та фізичної підготовки для молоді.",
      commitment: "6-8 годин на тиждень",
      requirements: ["Військовий досвід", "Педагогічні навички", "Фізична підготовка"],
      color: "from-blue-600 to-yellow-500",
      spots: "5 вакансій"
    },
    {
      icon: GraduationCap,
      title: "Ментор для ветеранів",
      description: "Допомагайте ветеранам АТО/ООС адаптуватися до цивільного життя та створювати бізнес.",
      commitment: "4-6 годин на тиждень", 
      requirements: ["Бізнес-досвід", "Психологічна стійкість", "Комунікативні навички"],
      color: "from-blue-500 to-indigo-600",
      spots: "10 вакансій"
    },
    {
      icon: Heart,
      title: "Координатор молодіжних програм",
      description: "Організовуйте патріотичні заходи, табори та культурні події для молоді.",
      commitment: "5-7 годин на тиждень",
      requirements: ["Досвід роботи з молоддю", "Організаторські здібності", "Патріотизм"],
      color: "from-red-500 to-pink-600",
      spots: "8 вакансій"
    },
    {
      icon: Target,
      title: "Психологічна підтримка",
      description: "Надавайте психологічну допомогу ветеранам та членам їх родин.",
      commitment: "4-5 годин на тиждень",
      requirements: ["Психологічна освіта", "Емпатія", "Досвід роботи з травмами"],
      color: "from-purple-500 to-pink-600",
      spots: "12 вакансій"
    }
  ];

  const benefits = [
    {
      icon: Heart,
      title: "Патріотичний внесок",
      description: "Допомагайте будувати сильну Україну"
    },
    {
      icon: Users,
      title: "Ветеранська спільнота",
      description: "Знайомство з героями та однодумцями"
    },
    {
      icon: Star,
      title: "Професійний розвиток",
      description: "Отримання цінного досвіду та навичок"
    },
    {
      icon: Check,
      title: "Офіційні сертифікати",
      description: "Сертифікати та рекомендаційні листи"
    }
  ];

  return (
    <div className="min-h-screen relative">
      {/* Ukrainian flag wheat field background */}
      <div className="absolute inset-0 ukrainian-flag-wheat-bg" />
      {/* Patriotic overlay for better readability */}
      <div className="absolute inset-0 ukrainian-flag-wheat-overlay" />
      
      <div className="relative z-10">
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Header */}
            <div className="text-center mb-16">
              <div className="flex items-center justify-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-xl flex items-center justify-center p-2">
                  <img src={heroLogo} alt="Міські герої" className="w-12 h-12 object-contain filter brightness-0 invert" />
                </div>
              </div>
              <div className="flex items-center justify-center space-x-3 mb-6">
                <Heart className="w-10 h-10 text-red-500" />
                <HandHeart className="w-8 h-8 text-blue-500" />
                <Users className="w-10 h-10 text-yellow-500" />
              </div>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                Долучитися до організації
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Станьте частиною руху "Міські герої"! Допомагайте ветеранам, навчайте молодь та відроджуйте українські традиції. 
                Кожен внесок має значення для створення сильної та незалежної України.
              </p>
            </div>

            {/* Why Join Section */}
            <div className="mb-20">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Чому варто долучитися
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {benefits.map((benefit, index) => {
                  const IconComponent = benefit.icon;
                  return (
                    <div key={index} className="text-center p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="font-bold text-gray-900 mb-2">{benefit.title}</h3>
                      <p className="text-gray-600 text-sm">{benefit.description}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Volunteer Opportunities */}
            <div className="mb-20">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Волонтерські можливості
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {volunteerOptions.map((option, index) => {
                  const IconComponent = option.icon;
                  return (
                    <Card 
                      key={index} 
                      className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 shadow-lg"
                    >
                      <CardHeader>
                        <div className="flex items-center justify-between mb-4">
                          <div className={`w-12 h-12 bg-gradient-to-br ${option.color} rounded-lg flex items-center justify-center`}>
                            <IconComponent className="w-6 h-6 text-white" />
                          </div>
                          <span className="text-sm font-medium text-green-600 bg-green-100 px-2 py-1 rounded">
                            {option.spots}
                          </span>
                        </div>
                        <CardTitle className="text-xl">{option.title}</CardTitle>
                        <div className="text-sm text-blue-600 font-medium">{option.commitment}</div>
                      </CardHeader>
                      
                      <CardContent>
                        <p className="text-gray-600 leading-relaxed mb-4">{option.description}</p>
                        
                        <div className="mb-6">
                          <h4 className="font-medium text-gray-900 mb-2">Вимоги:</h4>
                          <div className="space-y-1">
                            {option.requirements.map((req, reqIndex) => (
                              <div key={reqIndex} className="flex items-center text-sm text-gray-600">
                                <Check className="w-4 h-4 text-green-500 mr-2" />
                                {req}
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        <Button className={`w-full bg-gradient-to-r ${option.color} text-white hover:shadow-md transition-all duration-200`}>
                          Подати заявку
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Application Form */}
            <div className="mb-20">
              <div className="max-w-4xl mx-auto">
                <Card className="shadow-xl">
                  <CardHeader className="text-center">
                    <CardTitle className="text-3xl text-gray-900 mb-4">Форма подачі заявки</CardTitle>
                    <p className="text-gray-600">
                      Заповніть форму нижче, і наша команда зв'яжеться з вами протягом 2-3 робочих днів
                    </p>
                  </CardHeader>
                  <CardContent className="p-8">
                    <form className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="firstName">Ім'я *</Label>
                          <Input id="firstName" type="text" placeholder="Ваше ім'я" required />
                        </div>
                        <div>
                          <Label htmlFor="lastName">Прізвище *</Label>
                          <Input id="lastName" type="text" placeholder="Ваше прізвище" required />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="email">Email *</Label>
                          <Input id="email" type="email" placeholder="your.email@example.com" required />
                        </div>
                        <div>
                          <Label htmlFor="phone">Телефон *</Label>
                          <Input id="phone" type="tel" placeholder="+38 (099) 123-45-67" required />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="age">Вік</Label>
                          <Input id="age" type="number" placeholder="Ваш вік" min="16" max="80" />
                        </div>
                        <div>
                          <Label htmlFor="city">Місто</Label>
                          <Input id="city" type="text" placeholder="Ваше місто" />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="position">Позиція, яка вас цікавить *</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Оберіть позицію" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="instructor">Інструктор військової підготовки</SelectItem>
                            <SelectItem value="mentor">Ментор для ветеранів</SelectItem>
                            <SelectItem value="coordinator">Координатор молодіжних програм</SelectItem>
                            <SelectItem value="psychologist">Психологічна підтримка</SelectItem>
                            <SelectItem value="other">Інша позиція</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="experience">Досвід роботи та кваліфікація *</Label>
                        <Textarea 
                          id="experience" 
                          placeholder="Розкажіть про ваш досвід, освіту та навички, які можуть бути корисними для організації..."
                          className="min-h-24"
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="motivation">Чому ви хочете долучитися до нашої організації? *</Label>
                        <Textarea 
                          id="motivation" 
                          placeholder="Розкажіть про вашу мотивацію та те, що ви хочете привнести в нашу спільноту..."
                          className="min-h-24"
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="availability">Коли ви доступні для волонтерської роботи?</Label>
                        <Textarea 
                          id="availability" 
                          placeholder="Вкажіть дні тижня та години, коли ви можете приділяти час волонтерству..."
                          className="min-h-20"
                        />
                      </div>

                      <Button className="w-full bg-gradient-to-r from-blue-600 to-yellow-500 text-white py-3 text-lg">
                        <UserPlus className="w-5 h-5 mr-2" />
                        Подати заявку
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Statistics */}
            <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white text-center mb-20">
              <h2 className="text-3xl font-bold mb-8">Наша спільнота в цифрах</h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                  <div className="text-4xl font-bold mb-2">350+</div>
                  <div className="text-blue-100">Активних волонтерів</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">1,250+</div>
                  <div className="text-blue-100">Ветеранів підтримано</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">1,500+</div>
                  <div className="text-blue-100">Молодих патріотів</div>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">50+</div>
                  <div className="text-blue-100">Програм та проектів</div>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-8">
                Маєте питання? Зв'яжіться з нами!
              </h2>
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                Наша команда завжди готова відповісти на ваші запитання та допомогти знайти найкращий спосіб долучитися.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <Button 
                  onClick={() => onPageChange?.('contact')}
                  className="bg-gradient-to-r from-blue-600 to-yellow-500 text-white px-8 py-3"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  Написати нам
                </Button>
                <Button 
                  variant="outline"
                  className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-3"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Зателефонувати
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <Mail className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <div className="font-medium">Email</div>
                  <div className="text-gray-600">volunteer@urbanheroes.com.ua</div>
                </div>
                <div className="text-center">
                  <Phone className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <div className="font-medium">Телефон</div>
                  <div className="text-gray-600">+38 (044) 345-67-89</div>
                </div>
                <div className="text-center">
                  <MessageCircle className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <div className="font-medium">Telegram</div>
                  <div className="text-gray-600">@UrbanHeroes_volunteer</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}