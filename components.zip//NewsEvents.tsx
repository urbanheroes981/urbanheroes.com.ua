import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Calendar, Clock, Eye, Users, ArrowRight, CalendarDays } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface NewsEventsProps {
  onPageChange: (page: string) => void;
}

export function NewsEvents({ onPageChange }: NewsEventsProps) {
  const newsArticles = [
    {
      id: 1,
      title: "Успішне завершення курсу тактичної медицини для ветеранів",
      excerpt: "20 ветеранів АТО/ООС успішно завершили інтенсивний курс з тактичної медицини та отримали сертифікати інструкторів.",
      image: "https://images.unsplash.com/photo-1756188409678-eee65dcb7be9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBtaWxpdGFyeSUyMG1lZGljJTIwdW5pZm9ybSUyMHRhY3RpY2FsJTIwbWVkaWNpbmV8ZW58MXx8fHwxNzU4MTk3OTYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      date: "15 грудня 2025",
      category: "Освіта",
      views: 245,
      featured: true
    },
    {
      id: 2,
      title: "Молодіжний патріотичний табір 'Герої майбутнього' відкриває реєстрацію",
      excerpt: "Запрошуємо молодь віком 16-25 років до участі у зимовому патріотичному таборі з програмою військової підготовки.",
      image: "https://images.unsplash.com/photo-1517164850305-99a3e65bb47e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3V0aCUyMGNhbXAlMjBVa3JhaW5lJTIwcGF0cmlvdGljfGVufDF8fHx8MTc1ODEyMzE5M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      date: "12 грудня 2025",
      category: "Молодь",
      views: 182,
      featured: false
    },
    {
      id: 3,
      title: "Відкриття нового центру психологічної реабілітації ветеранів",
      excerpt: "У Києві відкрився сучасний центр психологічної підтримки ветеранів з інноваційними методами терапії та груповими заняттями.",
      image: "https://images.unsplash.com/photo-1566492031773-4f4e44671d66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmFuJTIwcmVoYWJpbGl0YXRpb24lMjBjZW50ZXJ8ZW58MXx8fHwxNzU4MTIzMTk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      date: "8 грудня 2025",
      category: "Реабілітація",
      views: 156,
      featured: false
    }
  ];

  const upcomingEvents = [
    {
      id: 1,
      title: "Військово-патріотичний семінар 'Сучасні виклики безпеки'",
      date: "22 грудня 2025",
      time: "10:00",
      location: "Київ, вул. Хрещатик, 25",
      participants: 45,
      category: "Семінар"
    },
    {
      id: 2,
      title: "Новорічне свято для дітей ветеранів",
      date: "28 грудня 2025",
      time: "15:00",
      location: "Культурний центр 'Україна'",
      participants: 120,
      category: "Захід"
    },
    {
      id: 3,
      title: "Тренінг з фінансової грамотності для ветеранського бізнесу",
      date: "15 січня 2026",
      time: "14:00",
      location: "Онлайн",
      participants: 80,
      category: "Тренінг"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-yellow-50 to-blue-100 relative">
      {/* Patriotic background overlay */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("https://images.unsplash.com/photo-1647472270676-fc9bc37a06ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBmbGFnJTIwYmFja2dyb3VuZCUyMHRleHR1cmV8ZW58MXx8fHwxNzU4MTIzMTMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />
      
      <div className="relative z-10">
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Header */}
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                Новини та події
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Слідкуйте за останніми новинами організації "Міські герої", анонсами заходів та важливими подіями 
                у житті ветеранської спільноти та патріотичної молоді України.
              </p>
            </div>

            {/* News Section */}
            <div className="mb-20">
              <div className="flex items-center justify-between mb-12">
                <h2 className="text-3xl font-bold text-gray-900">Останні новини</h2>
                <Button 
                  variant="outline"
                  onClick={() => onPageChange('news')}
                  className="border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white"
                >
                  Всі новини
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Featured Article */}
                <div className="lg:col-span-2">
                  {newsArticles.filter(article => article.featured).map(article => (
                    <Card key={article.id} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
                      <div className="grid grid-cols-1 lg:grid-cols-2">
                        <div className="relative h-64 lg:h-auto">
                          <ImageWithFallback
                            src={article.image}
                            alt={article.title}
                            className="w-full h-full object-cover"
                          />
                          <Badge className="absolute top-4 left-4 bg-blue-600 text-white">
                            Головна новина
                          </Badge>
                        </div>
                        <div className="p-8 flex flex-col justify-center">
                          <div className="flex items-center space-x-4 mb-4">
                            <Badge variant="secondary">{article.category}</Badge>
                            <div className="flex items-center text-gray-500 text-sm">
                              <Calendar className="w-4 h-4 mr-1" />
                              {article.date}
                            </div>
                            <div className="flex items-center text-gray-500 text-sm">
                              <Eye className="w-4 h-4 mr-1" />
                              {article.views}
                            </div>
                          </div>
                          <h3 className="text-2xl font-bold text-gray-900 mb-4">{article.title}</h3>
                          <p className="text-gray-600 mb-6">{article.excerpt}</p>
                          <Button className="bg-gradient-to-r from-blue-600 to-yellow-500 text-white self-start">
                            Читати далі
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>

                {/* Other Articles */}
                {newsArticles.filter(article => !article.featured).map(article => (
                  <Card key={article.id} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
                    <div className="relative h-48">
                      <ImageWithFallback
                        src={article.image}
                        alt={article.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-4 mb-4">
                        <Badge variant="secondary">{article.category}</Badge>
                        <div className="flex items-center text-gray-500 text-sm">
                          <Calendar className="w-4 h-4 mr-1" />
                          {article.date}
                        </div>
                        <div className="flex items-center text-gray-500 text-sm">
                          <Eye className="w-4 h-4 mr-1" />
                          {article.views}
                        </div>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-3">{article.title}</h3>
                      <p className="text-gray-600 mb-4">{article.excerpt}</p>
                      <Button variant="outline" className="w-full">
                        Читати далі
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Events Section */}
            <div>
              <div className="flex items-center justify-between mb-12">
                <h2 className="text-3xl font-bold text-gray-900">Найближчі події</h2>
                <Button 
                  variant="outline"
                  onClick={() => onPageChange('activities')}
                  className="border-yellow-600 text-yellow-600 hover:bg-yellow-600 hover:text-white"
                >
                  Календар подій
                  <CalendarDays className="ml-2 w-4 h-4" />
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {upcomingEvents.map(event => (
                  <Card key={event.id} className="hover:shadow-xl transition-shadow duration-300">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge 
                          variant="outline" 
                          className="border-blue-600 text-blue-600"
                        >
                          {event.category}
                        </Badge>
                        <div className="flex items-center text-gray-500 text-sm">
                          <Users className="w-4 h-4 mr-1" />
                          {event.participants}
                        </div>
                      </div>
                      <CardTitle className="text-lg">{event.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center text-gray-600">
                          <Calendar className="w-5 h-5 mr-3 text-blue-600" />
                          {event.date}
                        </div>
                        <div className="flex items-center text-gray-600">
                          <Clock className="w-5 h-5 mr-3 text-yellow-600" />
                          {event.time}
                        </div>
                        <div className="flex items-start text-gray-600">
                          <div className="w-5 h-5 mr-3 mt-0.5 bg-blue-600 rounded-full flex-shrink-0"></div>
                          {event.location}
                        </div>
                      </div>
                      <Button className="w-full mt-6 bg-gradient-to-r from-blue-600 to-yellow-500 text-white">
                        Зареєструватися
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* CTA Section */}
            <div className="mt-20 text-center">
              <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white">
                <h3 className="text-3xl font-bold mb-4">Залишайтеся в курсі подій</h3>
                <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
                  Підпишіться на наші новини та отримуйте сповіщення про важливі події та заходи організації "Міські герої".
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    onClick={() => onPageChange('join')}
                    className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3"
                  >
                    Долучитися до спільноти
                  </Button>
                  <Button 
                    onClick={() => onPageChange('support')}
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3"
                  >
                    Підтримати організацію
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}