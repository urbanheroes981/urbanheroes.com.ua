import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { 
  MapPin, 
  Filter, 
  Download, 
  Bell, 
  Search,
  Calendar,
  MoreVertical,
  AlertTriangle,
  Clock,
  Users,
  TrendingUp,
  Eye,
  CheckCircle,
  X
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function AuthorityDashboard() {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [timeFilter, setTimeFilter] = useState('24h');
  const [notifications, setNotifications] = useState(true);

  const reports = [
    {
      id: 'HR-2024-001847',
      type: 'High Waves',
      severity: 'high',
      location: 'Kiev, UA',
      coordinates: '25.7617° N, 80.1918° W',
      time: '2 minutes ago',
      reporter: 'Sarah M.',
      reputation: 4.8,
      verified: true,
      reports: 12,
      description: 'Waves reaching 8-10 feet with strong undertow. Multiple swimmers in distress.',
      photos: 3
    },
    {
      id: 'HR-2024-001846',
      type: 'Coastal Flooding',
      severity: 'medium',
      location: 'Virginia Beach, VA',
      coordinates: '36.8529° N, 75.9780° W',
      time: '15 minutes ago',
      reporter: 'Mike R.',
      reputation: 4.2,
      verified: true,
      reports: 7,
      description: 'Water level risen 2 feet above normal high tide mark. Parking areas flooded.',
      photos: 2
    },
    {
      id: 'HR-2024-001845',
      type: 'Strong Currents',
      severity: 'low',
      location: 'Santa Monica, CA',
      coordinates: '34.0195° N, 118.4912° W',
      time: '32 minutes ago',
      reporter: 'Alex K.',
      reputation: 3.9,
      verified: false,
      reports: 4,
      description: 'Noticed unusually strong rip currents near pier. Lifeguards aware.',
      photos: 1
    }
  ];

  const stats = [
    { label: 'Active Alerts', value: '24', change: '+3', icon: AlertTriangle, color: 'text-red-500' },
    { label: 'Verified Reports', value: '89', change: '+12', icon: CheckCircle, color: 'text-green-500' },
    { label: 'Active Reporters', value: '147', change: '+8', icon: Users, color: 'text-blue-500' },
    { label: 'Response Time', value: '28s', change: '-5s', icon: Clock, color: 'text-purple-500' }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Authority Dashboard
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl">
              Real-time ocean hazard monitoring and emergency response management system
            </p>
          </div>
          
          <div className="flex items-center space-x-3 mt-6 md:mt-0">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Live Notifications</span>
              <Switch checked={notifications} onCheckedChange={setNotifications} />
            </div>
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-10 h-10 ${stat.color.replace('text-', 'bg-').replace('-500', '-100')} rounded-lg flex items-center justify-center`}>
                      <IconComponent className={`w-5 h-5 ${stat.color}`} />
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {stat.change}
                    </Badge>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Interactive Map */}
            <Card className="shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center">
                  <MapPin className="w-5 h-5 mr-2 text-cyan-500" />
                  Live Hazard Map
                </CardTitle>
                <Button variant="outline" size="sm">
                  <Eye className="w-4 h-4 mr-2" />
                  Fullscreen
                </Button>
              </CardHeader>
              <CardContent>
                <div className="relative h-80 bg-gradient-to-br from-blue-900 to-cyan-900 rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1625617205488-b1fd2e7a53e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2VhbiUyMGNvYXN0bGluZSUyMGFlcmlhbCUyMHZpZXd8ZW58MXx8fHwxNzU3NjEzNDgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="Aerial coastline view"
                    className="w-full h-full object-cover opacity-40"
                  />
                  
                  {/* Hazard Markers */}
                  <div className="absolute inset-0">
                    {/* High severity markers */}
                    <div className="absolute top-1/4 left-1/3 flex items-center justify-center">
                      <div className="w-6 h-6 bg-red-500 rounded-full border-2 border-white animate-pulse cursor-pointer"></div>
                      <div className="ml-2 bg-black/70 text-white text-xs px-2 py-1 rounded">Miami Beach</div>
                    </div>
                    
                    {/* Medium severity markers */}
                    <div className="absolute top-1/2 left-1/4 flex items-center justify-center">
                      <div className="w-5 h-5 bg-orange-500 rounded-full border-2 border-white cursor-pointer"></div>
                      <div className="ml-2 bg-black/70 text-white text-xs px-2 py-1 rounded">Virginia Beach</div>
                    </div>
                    
                    {/* Low severity markers */}
                    <div className="absolute top-3/4 right-1/3 flex items-center justify-center">
                      <div className="w-4 h-4 bg-yellow-500 rounded-full border-2 border-white cursor-pointer"></div>
                      <div className="ml-2 bg-black/70 text-white text-xs px-2 py-1 rounded">Santa Monica</div>
                    </div>
                  </div>
                  
                  {/* Map Controls */}
                  <div className="absolute top-4 right-4 space-y-2">
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0">+</Button>
                    <Button size="sm" variant="secondary" className="w-8 h-8 p-0">-</Button>
                  </div>
                  
                  {/* Legend */}
                  <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3">
                    <div className="text-xs font-semibold text-gray-800 mb-2">Severity Levels</div>
                    <div className="space-y-1">
                      <div className="flex items-center text-xs">
                        <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                        <span>High Risk</span>
                      </div>
                      <div className="flex items-center text-xs">
                        <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
                        <span>Medium Risk</span>
                      </div>
                      <div className="flex items-center text-xs">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                        <span>Low Risk</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reports Table */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Recent Reports</span>
                  <div className="flex space-x-2">
                    <Input placeholder="Search reports..." className="w-64" />
                    <Button variant="outline" size="sm">
                      <Search className="w-4 h-4" />
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reports.map((report, index) => (
                    <div key={report.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-start space-x-3">
                          <div className={`w-3 h-3 rounded-full mt-2 ${
                            report.severity === 'high' ? 'bg-red-500' :
                            report.severity === 'medium' ? 'bg-orange-500' : 'bg-yellow-500'
                          }`}></div>
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <h4 className="font-semibold text-gray-900">{report.type}</h4>
                              <Badge variant="outline" className="text-xs">{report.id}</Badge>
                              {report.verified && (
                                <CheckCircle className="w-4 h-4 text-green-500" />
                              )}
                            </div>
                            <p className="text-sm text-gray-600 mb-2">{report.description}</p>
                            <div className="flex items-center space-x-4 text-xs text-gray-500">
                              <span>{report.location}</span>
                              <span>{report.coordinates}</span>
                              <span>{report.time}</span>
                              <span>{report.reports} reports</span>
                              {report.photos > 0 && <span>{report.photos} photos</span>}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={
                            report.severity === 'high' ? 'bg-red-100 text-red-800' :
                            report.severity === 'medium' ? 'bg-orange-100 text-orange-800' : 'bg-yellow-100 text-yellow-800'
                          }>
                            {report.severity}
                          </Badge>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <span>Reporter: {report.reporter}</span>
                          <span>•</span>
                          <span>Rep: {report.reputation}/5.0</span>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">View Details</Button>
                          <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700 text-white">
                            <Bell className="w-3 h-3 mr-1" />
                            Alert
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Filter className="w-5 h-5 mr-2" />
                  Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Hazard Type</label>
                  <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="waves">High Waves</SelectItem>
                      <SelectItem value="flooding">Coastal Flooding</SelectItem>
                      <SelectItem value="storm">Storms</SelectItem>
                      <SelectItem value="currents">Strong Currents</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Time Period</label>
                  <Select value={timeFilter} onValueChange={setTimeFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1h">Last Hour</SelectItem>
                      <SelectItem value="24h">Last 24 Hours</SelectItem>
                      <SelectItem value="7d">Last 7 Days</SelectItem>
                      <SelectItem value="30d">Last 30 Days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Verification Status</label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input type="checkbox" className="rounded border-gray-300 mr-2" defaultChecked />
                      <span className="text-sm">Verified</span>
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="rounded border-gray-300 mr-2" defaultChecked />
                      <span className="text-sm">Pending</span>
                    </label>
                  </div>
                </div>
                
                <Button className="w-full">Apply Filters</Button>
              </CardContent>
            </Card>

            {/* Live Notifications */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <Bell className="w-5 h-5 mr-2" />
                    Live Alerts
                  </span>
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-red-800">High Waves</span>
                      <span className="text-xs text-red-600">Just now</span>
                    </div>
                    <p className="text-xs text-red-700">Miami Beach, FL - 12 reports</p>
                  </div>
                  
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-orange-800">Flooding</span>
                      <span className="text-xs text-orange-600">2 min ago</span>
                    </div>
                    <p className="text-xs text-orange-700">Virginia Beach, VA - 7 reports</p>
                  </div>
                  
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-yellow-800">Strong Currents</span>
                      <span className="text-xs text-yellow-600">5 min ago</span>
                    </div>
                    <p className="text-xs text-yellow-700">Santa Monica, CA - 4 reports</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Issue Public Alert
                </Button>
                <Button variant="outline" className="w-full">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Generate Report
                </Button>
                <Button variant="outline" className="w-full">
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule Briefing
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}