import React from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface UkrainianBackgroundProps {
  children: React.ReactNode;
  className?: string;
  overlay?: 'light' | 'medium' | 'dark' | 'patriotic' | 'minimal';
  variant?: 'default' | 'hero' | 'minimal';
}

export function UkrainianBackground({ 
  children, 
  className = "", 
  overlay = 'patriotic',
  variant = 'default'
}: UkrainianBackgroundProps) {
  
  // Single Ukrainian flag background for all variants
  const ukrainianFlagImage = "https://images.unsplash.com/photo-1688348625704-0445d183e8ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBmbGFncyUyMGJsdWUlMjBza3klMjBwYXRyaW90aWMlMjBiYWNrZ3JvdW5kfGVufDF8fHx8MTc1ODI5MDE0NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

  const getOverlayClasses = () => {
    switch (overlay) {
      case 'light':
        return 'bg-white/85';
      case 'medium':
        return 'bg-white/70';
      case 'dark':
        return 'bg-gray-900/70';
      case 'minimal':
        return 'bg-white/90';
      case 'patriotic':
        return 'bg-gradient-to-br from-blue-600/25 via-white/15 to-yellow-400/20';
      default:
        return 'bg-white/75';
    }
  };

  const getVariantClasses = () => {
    switch (variant) {
      case 'hero':
        return 'min-h-screen';
      case 'minimal':
        return 'min-h-[50vh]';
      default:
        return 'min-h-[80vh]';
    }
  };

  return (
    <div className={`relative ${getVariantClasses()} ${className}`}>
      {/* Ukrainian Flag Background */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src={ukrainianFlagImage}
          alt="Ukrainian flag against beautiful blue sky"
          className="w-full h-full object-cover"
        />
        
        {/* Primary patriotic overlay */}
        <div className={`absolute inset-0 ${getOverlayClasses()}`} />
        
        {/* Additional Ukrainian-themed gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-blue-500/10 via-transparent to-yellow-300/8" />
        <div className="absolute inset-0 bg-gradient-to-br from-transparent via-blue-400/5 to-yellow-500/8" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}

// Specialized variants for different page types
export function UkrainianHeroBackground({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <UkrainianBackground 
      variant="hero" 
      overlay="patriotic" 
      className={className}
    >
      {children}
    </UkrainianBackground>
  );
}

export function UkrainianPageBackground({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <UkrainianBackground 
      variant="default" 
      overlay="light" 
      className={className}
    >
      {children}
    </UkrainianBackground>
  );
}

export function UkrainianSectionBackground({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <UkrainianBackground 
      variant="minimal" 
      overlay="minimal" 
      className={className}
    >
      {children}
    </UkrainianBackground>
  );
}