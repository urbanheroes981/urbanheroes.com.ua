import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  Shield, 
  Heart, 
  Users, 
  Award, 
  CheckCircle, 
  Phone,
  Calendar,
  MapPin,
  Star,
  Briefcase,
  Home,
  GraduationCap
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { LogoIcon } from './Logo';
import ukrainianSunsetFieldImage from 'figma:asset/a4255f299c9b37d54112ddfeac28a4ba0a6a0894.png';

interface VeteranProjectProps {
  onPageChange?: (page: string) => void;
}

export function VeteranProject({ onPageChange }: VeteranProjectProps) {
  const services = [
    {
      icon: Heart,
      title: "Психологічна підтримка",
      description: "Професійна допомога та консультації для подолання психологічних наслідків війни.",
      color: "from-red-500 to-pink-600"
    },
    {
      icon: Briefcase,
      title: "Працевлаштування",
      description: "Сприяння у пошуку роботи та перекваліфікації з урахуванням військового досвіду.",
      color: "from-blue-500 to-indigo-600"
    },
    {
      icon: Home,
      title: "Житлові програми",
      description: "Допомога у вирішенні житлових питань та отриманні пільгових умов.",
      color: "from-green-500 to-teal-600"
    },
    {
      icon: GraduationCap,
      title: "Освітні програми",
      description: "Безкоштовне навчання та підвищення кваліфікації для ветеранів та їх сімей.",
      color: "from-purple-500 to-indigo-600"
    }
  ];



  return (
    <section className="py-20 relative">
      {/* Ukrainian sunset field background */}
      <div className="absolute inset-0 z-0">
        <img
          src={ukrainianSunsetFieldImage}
          alt="Ukrainian flag in sunset wheat field"
          className="w-full h-full object-cover"
        />
        
        {/* Sunset overlay for better readability */}
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm" />
        
        {/* Warm sunset gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-orange-400/15 via-transparent to-blue-500/10" />
      </div>
      
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <div className="flex items-center justify-center mb-6">
              <LogoIcon size={64} />
            </div>
            <div className="flex items-center justify-center space-x-3 mb-6">
              <Shield className="w-10 h-10 text-yellow-500" />
              <Star className="w-8 h-8 text-blue-500" />
              <Heart className="w-10 h-10 text-red-500" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Проект "Герої повертаються"
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Комплексна програма підтримки ветеранів та їх сімей. Ми допомагаємо нашим захисникам 
              адаптуватися до мирного життя та знайти своє місце у суспільстві.
            </p>
          </div>

          {/* Services Grid */}
          <div className="mb-20">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Наші послуги для ветеранів
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {services.map((service, index) => {
                const IconComponent = service.icon;
                return (
                  <Card 
                    key={index} 
                    className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 shadow-lg"
                  >
                    <CardHeader className="text-center pb-4">
                      <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                        <IconComponent className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-xl text-gray-900">{service.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="text-center">
                      <p className="text-gray-600 leading-relaxed">{service.description}</p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>



          {/* Statistics */}
          <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white text-center mb-20">
            <h2 className="text-3xl font-bold mb-8">Результати нашої роботи</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <div className="text-4xl font-bold mb-2">1250+</div>
                <div className="text-blue-100">Ветеранів отримали допомогу</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">850</div>
                <div className="text-blue-100">Успішно працевлаштовані</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">500</div>
                <div className="text-blue-100">Отримали житло</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">95%</div>
                <div className="text-blue-100">Рівень задоволення</div>
              </div>
            </div>
          </div>

          {/* Contact Section */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">Потрібна допомога?</h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Зв'яжіться з нами для отримання підтримки або якщо ви хочете допомогти нашим героям.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <button 
                onClick={() => onPageChange?.('contact')}
                className="bg-gradient-to-r from-blue-500 to-yellow-500 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Phone className="w-5 h-5" />
                <span>Зв'язатися з нами</span>
              </button>
              <button 
                onClick={() => onPageChange?.('join')}
                className="border-2 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <Heart className="w-5 h-5" />
                <span>Долучитися до організації</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <Phone className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <div className="font-medium">Гаряча лінія</div>
                <div className="text-gray-600">0-800-30-20-22</div>
              </div>
              <div className="text-center">
                <Calendar className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <div className="font-medium">Графік роботи</div>
                <div className="text-gray-600">24/7 підтримка</div>
              </div>
              <div className="text-center">
                <MapPin className="w-8 h-8 text-blue-500 mx-auto mb-2" />
                <div className="font-medium">Центр підтримки</div>
                <div className="text-gray-600">вул. Хрещатик, 25, Київ</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}