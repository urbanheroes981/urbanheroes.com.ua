import { 
  Mail, 
  Phone, 
  MapPin, 
  Github, 
  Linkedin, 
  ExternalLink,
  GraduationCap
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { LogoIcon } from './Logo';

interface FooterProps {
  onPageChange: (page: string) => void;
}

export function Footer({ onPageChange }: FooterProps) {
  const { t } = useLanguage();

  const quickLinks = [
    { id: 'home', label: t('nav.home') },
    { id: 'about', label: t('nav.about') },
    { id: 'features', label: t('nav.services') },
    { id: 'how-it-works', label: t('nav.howItWorks') }
  ];

  const platformLinks = [
    { id: 'veteran-project', label: t('nav.veteranProject') },
    { id: 'youth-project', label: t('nav.youthProject') },
    { id: 'news-events', label: t('nav.newsEvents') },
    { id: 'join', label: t('nav.join') },
    { id: 'support', label: t('nav.support') },
    { id: 'contact', label: t('nav.contact') }
  ];

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900/95 backdrop-blur-sm text-white relative">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/40 via-gray-900/60 to-yellow-900/40" />
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="lg:col-span-1">
              <div className="flex items-center space-x-3 mb-6">
                <LogoIcon size={40} variant="white" />
                <span className="text-2xl font-bold">Міські герої</span>
              </div>
              
              <p className="text-gray-300 mb-6 leading-relaxed">
                Кожен може стати героєм свого міста. Наша платформа допомагає громадянам швидко повідомляти про проблеми та координує роботу екстрених служб для створення безпечного та комфортного міського середовища.
              </p>
              
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  <Github className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  <Linkedin className="w-5 h-5" />
                </a>
                <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors">
                  <GraduationCap className="w-5 h-5" />
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="text-lg font-semibold mb-6">{t('footer.quickLinks')}</h3>
              <ul className="space-y-3">
                {quickLinks.map((link) => (
                  <li key={link.id}>
                    <button
                      onClick={() => onPageChange(link.id)}
                      className="text-gray-300 hover:text-cyan-400 transition-colors text-left"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Platform */}
            <div>
              <h3 className="text-lg font-semibold mb-6">{t('footer.platform')}</h3>
              <ul className="space-y-3">
                {platformLinks.map((link) => (
                  <li key={link.id}>
                    <button
                      onClick={() => onPageChange(link.id)}
                      className="text-gray-300 hover:text-cyan-400 transition-colors text-left"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact Info */}
            <div>
              <h3 className="text-lg font-semibold mb-6">{t('footer.contacts')}</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <GraduationCap className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                  <div className="text-gray-300">
                    <div className="font-medium">{t('footer.company')}</div>
                    <div className="text-sm">{t('footer.department')}</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-cyan-400 mt-0.5 flex-shrink-0" />
                  <div className="text-gray-300 text-sm">
                    вул. Хрещатик, 25<br />
                    Київ, 01001
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                  <a 
                    href="mailto:info@urbanheroes.com.ua"
                    className="text-gray-300 hover:text-cyan-400 transition-colors text-sm"
                  >
                    info@urbanheroes.com.ua
                  </a>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-cyan-400 flex-shrink-0" />
                  <a 
                    href="tel:+380956705220"
                    className="text-gray-300 hover:text-cyan-400 transition-colors text-sm"
                  >
                    +38 (095) 670-52-20
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Section */}
          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="text-gray-400 text-sm mb-4 md:mb-0">
                © {currentYear} {t('footer.copyright')}
              </div>
              
              <div className="flex items-center space-x-6 text-sm text-gray-400">
                <a href="#" className="hover:text-cyan-400 transition-colors">{t('footer.privacyPolicy')}</a>
                <a href="#" className="hover:text-cyan-400 transition-colors">{t('footer.termsOfUse')}</a>
                <a href="#" className="hover:text-cyan-400 transition-colors flex items-center">
                  {t('footer.scientificArticle')}
                  <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}