import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  Shield, 
  Star, 
  Users, 
  Rocket,
  Heart,
  Award,
  ArrowRight,
  Calendar,
  MapPin,
  Target,
  TrendingUp,
  CheckCircle,
  Clock,
  GraduationCap,
  Briefcase
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import heroLogo from 'figma:asset/db70ba7fd23873889e37f7b0bf8a96eb8f12323a.png';

interface ProjectsProps {
  onPageChange?: (page: string) => void;
}

export function Projects({ onPageChange }: ProjectsProps) {
  const mainProjects = [
    {
      id: 'veterans',
      title: "Герої повертаються",
      subtitle: "Ветеранський проект",
      description: "Комплексна програма підтримки ветеранів та їх адаптації до мирного життя",
      image: "https://images.unsplash.com/photo-1640238490075-c239ad4cb081?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwbWFpbnRlbmFuY2UlMjB3b3JrZXJzJTIwZW1lcmdlbmN5fGVufDF8fHx8MTc1ODAzNTk0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Shield,
      color: "from-blue-500 to-yellow-500",
      stats: {
        participants: "1,250+ ветеранів",
        success: "850 працевлаштовані",
        satisfaction: "95% задоволених"
      },
      features: [
        "Психологічна підтримка та реабілітація",
        "Програми працевлаштування",
        "Житлові програми",
        "Освітні ініціативи"
      ],
      page: 'veteran-project'
    },
    {
      id: 'youth',
      title: "Молоді герої майбутнього",
      subtitle: "Молодіжний проект",
      description: "Програма розвитку та підтримки талановитої молоді України",
      image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHx5b3VuZyUyMHBlb3BsZSUyMGNvZGluZyUyMHByb2dyYW1taW5nJTIwVWtyYWluZXxlbnwxfHx8fDE3NTgwMzYzMDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Rocket,
      color: "from-purple-500 to-blue-500",
      stats: {
        participants: "1,500+ учасників",
        success: "50+ проектів реалізовано",
        satisfaction: "98% задоволених"
      },
      features: [
        "IT освіта та програмування",
        "Підприємницькі програми",
        "Творчі майстерні",
        "Волонтерський рух"
      ],
      page: 'youth-project'
    }
  ];

  const additionalProjects = [
    {
      title: "Цифрове місто",
      description: "Розвиток цифрової інфраструктури для покращення якості міських послуг",
      icon: Target,
      status: "Активний",
      progress: 75,
      color: "from-green-500 to-teal-600"
    },
    {
      title: "Безпечні дороги",
      description: "Система моніторингу та швидкого ремонту дорожньої інфраструктури",
      icon: Shield,
      status: "Активний",
      progress: 90,
      color: "from-red-500 to-orange-600"
    },
    {
      title: "Зелене майбутнє",
      description: "Екологічні ініціативи для створення сталого міського середовища",
      icon: Heart,
      status: "Планується",
      progress: 25,
      color: "from-green-500 to-emerald-600"
    },
    {
      title: "Освіта для всіх",
      description: "Програми цифрової освіти для різних вікових груп населення",
      icon: GraduationCap,
      status: "Активний",
      progress: 60,
      color: "from-indigo-500 to-purple-600"
    }
  ];

  const projectStats = [
    {
      value: "6",
      label: "Активних проектів",
      icon: Target,
      color: "text-blue-600"
    },
    {
      value: "3,500+",
      label: "Бенефіціарів",
      icon: Users,
      color: "text-green-600"
    },
    {
      value: "2.5млн грн",
      label: "Залучених коштів",
      icon: TrendingUp,
      color: "text-purple-600"
    },
    {
      value: "100+",
      label: "Партнерів",
      icon: Award,
      color: "text-yellow-600"
    }
  ];

  const timeline = [
    {
      year: "2023",
      title: "Заснування організації",
      description: "Запуск платформи 'Міські герої' та перших пілотних проектів",
      status: "completed"
    },
    {
      year: "2024",
      title: "Розширення діяльності",
      description: "Запуск проектів 'Герої повертаються' та 'Молоді герої майбутнього'",
      status: "completed"
    },
    {
      year: "2025",
      title: "Масштабування",
      description: "Розширення на інші міста України та запуск нових напрямків",
      status: "active"
    },
    {
      year: "2026",
      title: "Міжнародна співпраця",
      description: "Обмін досвідом з європейськими організаціями та залучення грантів ЄС",
      status: "planned"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-blue-600 rounded-xl flex items-center justify-center p-2">
              <img src={heroLogo} alt="Міські герої" className="w-12 h-12 object-contain filter brightness-0 invert" />
            </div>
          </div>
          <div className="flex items-center justify-center space-x-3 mb-6">
            <Target className="w-10 h-10 text-blue-500" />
            <Star className="w-8 h-8 text-yellow-500" />
            <Heart className="w-10 h-10 text-red-500" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Наші проекти
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Ми реалізуємо різноманітні проекти для покращення якості життя у місті. 
            Від підтримки ветеранів до розвитку молодіжного потенціалу - кожен проект спрямований на створення кращого майбутнього.
          </p>
        </div>

        {/* Main Projects */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Флагманські проекти
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {mainProjects.map((project) => {
              const IconComponent = project.icon;
              return (
                <Card 
                  key={project.id} 
                  className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
                >
                  <div className="relative">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-64 object-cover"
                    />
                    <div className={`absolute top-4 left-4 bg-gradient-to-r ${project.color} p-3 rounded-lg`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="absolute top-4 right-4 bg-white/90 px-3 py-1 rounded-full text-sm font-medium text-gray-700">
                      {project.subtitle}
                    </div>
                  </div>
                  
                  <CardHeader>
                    <CardTitle className="text-2xl">{project.title}</CardTitle>
                    <p className="text-gray-600 leading-relaxed">{project.description}</p>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="mb-6">
                      <h4 className="font-medium text-gray-900 mb-3">Ключові послуги:</h4>
                      <div className="space-y-2">
                        {project.features.map((feature, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-600">
                            <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                            {feature}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                      <div>
                        <div className="text-lg font-bold text-gray-900">{project.stats.participants}</div>
                        <div className="text-xs text-gray-500">Учасників</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-gray-900">{project.stats.success}</div>
                        <div className="text-xs text-gray-500">Успішні історії</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-gray-900">{project.stats.satisfaction}</div>
                        <div className="text-xs text-gray-500">Задоволеність</div>
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => onPageChange?.(project.page)}
                      className={`w-full bg-gradient-to-r ${project.color} text-white py-3 rounded-lg hover:shadow-md transition-all duration-200 flex items-center justify-center space-x-2`}
                    >
                      <span>Дізнатися більше</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Additional Projects */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Додаткові ініціативи
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {additionalProjects.map((project, index) => {
              const IconComponent = project.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow duration-300">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${project.color} rounded-lg flex items-center justify-center`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      project.status === 'Активний' ? 'bg-green-100 text-green-800' :
                      project.status === 'Планується' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {project.status}
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{project.title}</h3>
                  <p className="text-gray-600 leading-relaxed mb-4">{project.description}</p>
                  
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-1">
                      <span>Прогрес</span>
                      <span>{project.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`bg-gradient-to-r ${project.color} h-2 rounded-full transition-all duration-300`}
                        style={{ width: `${project.progress}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <button className="text-blue-600 hover:text-blue-800 transition-colors text-sm font-medium flex items-center">
                    Детальніше
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </button>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Project Statistics */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Наші досягнення
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {projectStats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <div key={index} className="text-center p-6 bg-white rounded-xl shadow-lg">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${stat.color.replace('text-', 'bg-').replace('600', '100')}`}>
                    <IconComponent className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Timeline */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Етапи розвитку
          </h2>
          <div className="relative">
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-300"></div>
            <div className="space-y-8">
              {timeline.map((item, index) => (
                <div key={index} className="relative flex items-start">
                  <div className={`flex-shrink-0 w-16 h-16 rounded-full flex items-center justify-center border-4 border-white ${
                    item.status === 'completed' ? 'bg-green-500' :
                    item.status === 'active' ? 'bg-blue-500' :
                    'bg-gray-300'
                  }`}>
                    <span className="text-white font-bold text-sm">{item.year}</span>
                  </div>
                  <div className="ml-6 flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white text-center">
          <h2 className="text-3xl font-bold mb-8">Маєте ідею для проекту?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Ми завжди відкриті до нових ідей та ініціатив. Долучайтеся до нас і разом створюймо позитивні зміни!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => onPageChange?.('join')}
              className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <Heart className="w-5 h-5" />
              <span>Долучитися до проектів</span>
            </button>
            <button 
              onClick={() => onPageChange?.('contact')}
              className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <Users className="w-5 h-5" />
              <span>Запропонувати ідею</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}