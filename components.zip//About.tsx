import { Card, CardContent } from './ui/card';
import { Shield, Users, Heart, Target, BookOpen, Sword } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useLanguage } from '../i18n/LanguageContext';
import { LogoIcon } from './Logo';
import ukrainianFieldImage from 'figma:asset/3400ac982fc3a19c34bfffc50f16001e9fdbdb01.png';

export function About() {
  const { t } = useLanguage();

  return (
    <section className="py-20 relative">
      {/* Ukrainian flag with wheat field background */}
      <div className="absolute inset-0 z-0">
        <img
          src={ukrainianFieldImage}
          alt="Ukrainian flag with wheat field against blue sky"
          className="w-full h-full object-cover"
        />
        
        {/* Patriotic overlay for better readability */}
        <div className="absolute inset-0 bg-white/75 backdrop-blur-sm" />
        
        {/* Ukrainian colors gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-blue-500/20 via-transparent to-yellow-400/15" />
      </div>
      
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <div className="flex items-center justify-center mb-6">
              <LogoIcon size={64} />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              {t('about.title')}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              {t('about.description')}
            </p>
          </div>

          {/* Mission Goals */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-8">{t('about.goals')}</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <Shield className="w-8 h-8 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">{t('about.veteranCommunities')}</h4>
                    <p className="text-gray-700">
                      {t('about.veteranCommunitiesDesc')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <Target className="w-8 h-8 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">{t('about.militaryTraining')}</h4>
                    <p className="text-gray-700">
                      {t('about.militaryTrainingDesc')}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <BookOpen className="w-8 h-8 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">{t('about.patrioticEducation')}</h4>
                    <p className="text-gray-700">
                      {t('about.patrioticEducationDesc')}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1648733750625-bb6014fc99e1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBmbGFnJTIwdHJpZGVudCUyMHBhdHJpb3RpYyUyMHN5bWJvbHN8ZW58MXx8fHwxNzU4MTIxOTc3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Ukrainian patriotic symbols and flag"
                className="w-full h-48 object-cover rounded-xl shadow-lg"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1655456946098-a50949bd9e59?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBtaWxpdGFyeSUyMHZldGVyYW5zJTIwdHJhaW5pbmd8ZW58MXx8fHwxNzU4MTIxOTgwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Ukrainian military veterans training"
                className="w-full h-48 object-cover rounded-xl shadow-lg"
              />
            </div>
          </div>

          {/* Additional Mission Points */}
          <div className="bg-white/85 backdrop-blur-md rounded-2xl shadow-xl p-8 md:p-12 mb-20 border border-white/60">
            <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
              {t('about.ourActivities')}
            </h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Support Programs */}
              <Card className="border-blue-300 bg-blue-50/90 backdrop-blur-sm shadow-lg">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-blue-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Heart className="w-8 h-8 text-blue-700" />
                    </div>
                    <h4 className="text-2xl font-bold text-blue-900">{t('about.supportVeterans')}</h4>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span className="text-blue-800">{t('about.protectRights')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span className="text-blue-800">{t('about.returnToCivilLife')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span className="text-blue-800">{t('about.createVeteranBusiness')}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Culture & Sports */}
              <Card className="border-yellow-300 bg-yellow-50/90 backdrop-blur-sm shadow-lg">
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Sword className="w-8 h-8 text-yellow-700" />
                    </div>
                    <h4 className="text-2xl font-bold text-yellow-900">{t('about.cultureAndSports')}</h4>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-yellow-600 rounded-full"></div>
                      <span className="text-yellow-800">{t('about.healthyLiving')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-yellow-600 rounded-full"></div>
                      <span className="text-yellow-800">{t('about.ukrainianCombatArts')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-yellow-600 rounded-full"></div>
                      <span className="text-yellow-800">{t('about.familyHolidays')}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Impact Stats */}
          <div className="text-center">
            <h3 className="text-3xl font-bold text-gray-900 mb-12">{t('about.achievements')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Shield className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900">1250+</div>
                <div className="text-gray-600">{t('about.supportedVeterans')}</div>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900">1500+</div>
                <div className="text-gray-600">{t('about.patrioticYouth')}</div>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900">50+</div>
                <div className="text-gray-600">{t('about.trainingPrograms')}</div>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                  <Heart className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900">24/7</div>
                <div className="text-gray-600">{t('about.communitySupport')}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}