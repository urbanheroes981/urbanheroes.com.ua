interface UkrainianFlagWheatBackgroundProps {
  children: React.ReactNode;
}

export function UkrainianFlagWheatBackground({ children }: UkrainianFlagWheatBackgroundProps) {
  return (
    <div className="min-h-screen relative">
      {/* Ukrainian flag with wheat field background */}
      <div className="absolute inset-0 ukrainian-flag-wheat-bg" />
      
      {/* Patriotic overlay for enhanced readability and Ukrainian feeling */}
      <div className="absolute inset-0 ukrainian-flag-wheat-overlay" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}