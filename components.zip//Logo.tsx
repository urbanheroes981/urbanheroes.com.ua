import React from 'react';
import urbanHeroesLogo from 'figma:asset/423625f3a2b4c69d6e08cc5e69ed67681896dd69.png';

interface LogoProps {
  className?: string;
  showText?: boolean;
  variant?: 'default' | 'white' | 'blue';
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export function Logo({ className = "", showText = true, variant = 'default', size = 'md' }: LogoProps) {
  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return {
          container: 'h-8',
          image: 'h-8',
          text: 'text-sm',
          subtext: 'text-xs'
        };
      case 'lg':
        return {
          container: 'h-16',
          image: 'h-16',
          text: 'text-2xl',
          subtext: 'text-sm'
        };
      case 'xl':
        return {
          container: 'h-20',
          image: 'h-20',
          text: 'text-3xl',
          subtext: 'text-base'
        };
      default: // md
        return {
          container: 'h-12',
          image: 'h-12',
          text: 'text-xl',
          subtext: 'text-xs'
        };
    }
  };

  const getTextColors = () => {
    switch (variant) {
      case 'white':
        return 'text-white';
      case 'blue':
        return 'text-blue-600';
      default:
        return 'text-gray-900';
    }
  };

  const sizeClasses = getSizeClasses();
  const textColors = getTextColors();

  return (
    <div className={`flex items-center space-x-3 ${sizeClasses.container} ${className}`}>
      {/* Urban Heroes Logo */}
      <img
        src={urbanHeroesLogo}
        alt="Urban Heroes Logo"
        className={`${sizeClasses.image} w-auto object-contain drop-shadow-lg`}
      />

      {/* Logo Text */}
      {showText && (
        <div className="flex flex-col">
          <div className={`${sizeClasses.text} font-bold leading-tight ${textColors}`}>
            Міські герої
          </div>
          <div className={`${sizeClasses.subtext} opacity-75 leading-tight ${textColors}`}>
            Urban Heroes
          </div>
        </div>
      )}
    </div>
  );
}

// Compact version for small spaces
export function LogoCompact({ className = "", variant = 'default', size = 'sm' }: Omit<LogoProps, 'showText'>) {
  return <Logo className={className} showText={false} variant={variant} size={size} />;
}

// Icon only version
export function LogoIcon({ className = "", size = 32, variant = 'default' }: { 
  className?: string; 
  size?: number;
  variant?: 'default' | 'white' | 'blue';
}) {
  return (
    <img
      src={urbanHeroesLogo}
      alt="Urban Heroes"
      width={size}
      height={size}
      className={`object-contain drop-shadow-lg ${className}`}
    />
  );
}