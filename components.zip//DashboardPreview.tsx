import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  MapPin, 
  AlertTriangle, 
  TrendingUp, 
  Users, 
  Clock,
  Filter,
  Download,
  RefreshCw,
  Waves,
  Wind,
  Thermometer
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function DashboardPreview() {
  const recentAlerts = [
    { id: 1, type: 'High Waves', location: 'Miami Beach, FL', time: '2 min ago', severity: 'high', reports: 12 },
    { id: 2, type: 'Coastal Flooding', location: 'Virginia Beach, VA', time: '15 min ago', severity: 'medium', reports: 7 },
    { id: 3, type: 'Strong Currents', location: 'Santa Monica, CA', time: '32 min ago', severity: 'low', reports: 4 },
    { id: 4, type: 'Storm Surge', location: 'Galveston, TX', time: '1 hr ago', severity: 'high', reports: 18 }
  ];

  const hotspots = [
    { location: 'Atlantic Coast', reports: 45, risk: 'High' },
    { location: 'Pacific Northwest', reports: 23, risk: 'Medium' },
    { location: 'Gulf Coast', reports: 67, risk: 'High' },
    { location: 'Great Lakes', reports: 12, risk: 'Low' }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Real-time Emergency Dashboard
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Comprehensive monitoring and analytics platform for emergency authorities 
            to track, verify, and respond to ocean hazards in real-time.
          </p>
        </div>

        {/* Dashboard Interface */}
        <div className="bg-gray-900 rounded-2xl p-6 md:p-8 shadow-2xl">
          {/* Dashboard Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 pb-6 border-b border-gray-700">
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">Ocean Hazard Command Center</h3>
              <p className="text-gray-400">Real-time monitoring • Last updated: 30 seconds ago</p>
            </div>
            <div className="flex space-x-3 mt-4 md:mt-0">
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Map Area */}
            <div className="lg:col-span-2">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-4">
                  <CardTitle className="text-white flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-cyan-400" />
                    Interactive Hazard Map
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Mock Map */}
                  <div className="relative h-80 bg-gradient-to-br from-blue-900 to-cyan-900 rounded-lg overflow-hidden">
                    <ImageWithFallback
                      src="https://images.unsplash.com/photo-1625617205488-b1fd2e7a53e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2VhbiUyMGNvYXN0bGluZSUyMGFlcmlhbCUyMHZpZXd8ZW58MXx8fHwxNzU3NjEzNDgyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                      alt="Aerial view of coastline"
                      className="w-full h-full object-cover opacity-30"
                    />
                    
                    {/* Hotspot Markers */}
                    <div className="absolute inset-0">
                      <div className="absolute top-1/4 left-1/3 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse"></div>
                      <div className="absolute top-1/2 left-1/4 w-3 h-3 bg-yellow-500 rounded-full border-2 border-white"></div>
                      <div className="absolute top-3/4 right-1/3 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse"></div>
                      <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-orange-500 rounded-full border-2 border-white"></div>
                    </div>
                    
                    {/* Map Legend */}
                    <div className="absolute bottom-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg p-3">
                      <div className="text-white text-xs space-y-1">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                          <span>High Risk</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
                          <span>Medium Risk</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                          <span>Low Risk</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Live Statistics */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-4">
                  <CardTitle className="text-white text-lg">Live Statistics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <AlertTriangle className="w-4 h-4 text-red-400 mr-2" />
                      <span className="text-gray-300 text-sm">Active Alerts</span>
                    </div>
                    <span className="text-white font-bold">24</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Users className="w-4 h-4 text-cyan-400 mr-2" />
                      <span className="text-gray-300 text-sm">Active Reporters</span>
                    </div>
                    <span className="text-white font-bold">147</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <TrendingUp className="w-4 h-4 text-green-400 mr-2" />
                      <span className="text-gray-300 text-sm">Reports Today</span>
                    </div>
                    <span className="text-white font-bold">89</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 text-blue-400 mr-2" />
                      <span className="text-gray-300 text-sm">Avg Response</span>
                    </div>
                    <span className="text-white font-bold">28s</span>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Alerts */}
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-4">
                  <CardTitle className="text-white text-lg">Recent Alerts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-64 overflow-y-auto">
                    {recentAlerts.map((alert) => (
                      <div key={alert.id} className="bg-gray-700 rounded-lg p-3">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center">
                            <div className="w-2 h-2 bg-cyan-400 rounded-full mr-2"></div>
                            <span className="text-white text-sm font-medium">{alert.type}</span>
                          </div>
                          <Badge 
                            variant={alert.severity === 'high' ? 'destructive' : alert.severity === 'medium' ? 'secondary' : 'outline'}
                            className="text-xs"
                          >
                            {alert.severity}
                          </Badge>
                        </div>
                        <p className="text-gray-300 text-xs mb-1">{alert.location}</p>
                        <div className="flex justify-between items-center text-xs text-gray-400">
                          <span>{alert.time}</span>
                          <span>{alert.reports} reports</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Bottom Analytics */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-cyan-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Waves className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white">156</div>
                <div className="text-gray-400 text-sm">Wave Reports</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Wind className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white">89</div>
                <div className="text-gray-400 text-sm">Storm Alerts</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Thermometer className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white">34</div>
                <div className="text-gray-400 text-sm">Temperature Alerts</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <AlertTriangle className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white">12</div>
                <div className="text-gray-400 text-sm">Emergency Calls</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Features List */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <MapPin className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Interactive Mapping</h3>
            <p className="text-gray-600">Real-time hazard visualization with precise GPS coordinates and severity indicators</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Filter className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Advanced Filtering</h3>
            <p className="text-gray-600">Filter by hazard type, severity, time period, and geographic regions</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Predictive Analytics</h3>
            <p className="text-gray-600">Machine learning insights for pattern recognition and trend forecasting</p>
          </div>
        </div>
      </div>
    </section>
  );
}