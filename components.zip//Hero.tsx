import { Button } from './ui/button';
import { ArrowRight, Shield, Users } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { LogoIcon } from './Logo';
import { UkrainianHeroBackground } from './UkrainianBackground';

interface HeroProps {
  onPageChange: (page: string) => void;
}

export function Hero({ onPageChange }: HeroProps) {
  const { t } = useLanguage();

  return (
    <UkrainianHeroBackground className="flex items-center justify-center overflow-hidden">
      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto py-20">
        {/* Logo */}
        <div className="mb-8">
          <LogoIcon size={80} variant="white" className="mx-auto mb-4" />
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold mb-6 text-white drop-shadow-2xl">
          {t('hero.slogan')}
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 text-blue-50 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
          {t('hero.description')}
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button
            size="lg"
            onClick={() => onPageChange('veteran-project')}
            className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white px-8 py-4 text-lg rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200 border border-yellow-400/30"
          >
            {t('hero.becomeHero')}
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
          
          <Button
            size="lg"
            variant="outline"
            onClick={() => onPageChange('youth-project')}
            className="border-2 border-blue-300 text-white hover:bg-blue-300 hover:text-blue-900 px-8 py-4 text-lg rounded-xl backdrop-blur-sm bg-blue-600/20 transform hover:scale-105 transition-all duration-200"
          >
            {t('hero.youthPrograms')}
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
          <div className="bg-blue-900/40 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-center mb-2">
              <Users className="w-8 h-8 text-yellow-300" />
            </div>
            <div className="text-2xl font-bold text-white">1,750+</div>
            <div className="text-blue-200">{t('hero.stats.veterans')}</div>
          </div>
          
          <div className="bg-blue-900/40 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-center mb-2">
              <Shield className="w-8 h-8 text-yellow-300" />
            </div>
            <div className="text-2xl font-bold text-white">50+</div>
            <div className="text-blue-200">{t('hero.stats.programs')}</div>
          </div>
          
          <div className="bg-blue-900/40 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <div className="flex items-center justify-center mb-2">
              <ArrowRight className="w-8 h-8 text-yellow-300" />
            </div>
            <div className="text-2xl font-bold text-white">24/7</div>
            <div className="text-blue-200">{t('hero.stats.support')}</div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full p-1">
            <div className="w-1 h-3 bg-white/70 rounded-full mx-auto animate-bounce"></div>
          </div>
        </div>
      </div>
    </UkrainianHeroBackground>
  );
}