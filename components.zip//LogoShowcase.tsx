import React from 'react';
import { Logo, LogoCompact, LogoIcon } from './Logo';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import urbanHeroesLogo from 'figma:asset/423625f3a2b4c69d6e08cc5e69ed67681896dd69.png';

export function LogoShowcase() {
  return (
    <section className="py-20 relative">
      {/* Light overlay for better readability with Ukrainian flag background */}
      <div className="absolute inset-0 bg-white/90 backdrop-blur-sm" />
      
      <div className="relative z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Логотип "Urban Heroes"</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Новий професійний логотип організації "Міські герої", що поєднує сучасний дизайн 
              з патріотичною символікою та героїчною тематикою.
            </p>
          </div>

          {/* Main Logo Display */}
          <div className="text-center mb-16">
            <Card className="shadow-2xl border-0 bg-gradient-to-br from-gray-50 to-white">
              <CardContent className="py-16 px-8">
                <img 
                  src={urbanHeroesLogo} 
                  alt="Urban Heroes Logo" 
                  className="h-32 w-auto object-contain drop-shadow-xl mx-auto mb-8"
                />
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Основний логотип</h3>
                <p className="text-gray-600">Професійний дизайн з чорним фоном та білими літерами</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {/* Full Logo with Text */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center">Логотип з текстом</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="bg-white p-6 rounded-lg mb-4 border">
                  <Logo size="lg" />
                </div>
                <p className="text-sm text-gray-600">З українським перекладом для локального використання</p>
              </CardContent>
            </Card>

            {/* Compact Logo */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center">Компактний варіант</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="bg-white p-6 rounded-lg mb-4 border">
                  <LogoCompact size="md" />
                </div>
                <p className="text-sm text-gray-600">Для навігації та обмежених просторів</p>
              </CardContent>
            </Card>

            {/* Icon Only */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center">Тільки іконка</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="bg-white p-6 rounded-lg mb-4 border">
                  <LogoIcon size={64} className="mx-auto" />
                </div>
                <p className="text-sm text-gray-600">Favicon та соціальні мережі</p>
              </CardContent>
            </Card>
          </div>

          {/* Size Variants */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center text-sm">Малий</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-6">
                <div className="bg-white p-4 rounded-lg border">
                  <Logo size="sm" />
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center text-sm">Середній</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-6">
                <div className="bg-white p-4 rounded-lg border">
                  <Logo size="md" />
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center text-sm">Великий</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-6">
                <div className="bg-white p-4 rounded-lg border">
                  <Logo size="lg" />
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center text-sm">Екстра великий</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-6">
                <div className="bg-white p-4 rounded-lg border">
                  <Logo size="xl" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Color Variants */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {/* Default */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center">Стандартний</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="bg-white p-6 rounded-lg mb-4 border">
                  <LogoIcon size={64} variant="default" className="mx-auto" />
                </div>
                <p className="text-sm text-gray-600">Темний текст для світлого фону</p>
              </CardContent>
            </Card>

            {/* White */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center">Білий варіант</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="bg-gray-800 p-6 rounded-lg mb-4">
                  <Logo variant="white" />
                </div>
                <p className="text-sm text-gray-600">Для темного фону</p>
              </CardContent>
            </Card>

            {/* Blue */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-center">Синій варіант</CardTitle>
              </CardHeader>
              <CardContent className="text-center py-8">
                <div className="bg-blue-50 p-6 rounded-lg mb-4 border border-blue-100">
                  <Logo variant="blue" />
                </div>
                <p className="text-sm text-gray-600">Синій акцент</p>
              </CardContent>
            </Card>
          </div>

          {/* Logo Features Description */}
          <div className="bg-gradient-to-br from-gray-50 to-white rounded-2xl shadow-xl p-8">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">Особливості нового логотипу</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-black rounded-xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-sm">UH</span>
                </div>
                <h4 className="font-semibold mb-2">Прапор-щит</h4>
                <p className="text-sm text-gray-600">Форма щита символізує захист та силу</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-gray-700 to-black rounded-xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-xs">URBAN</span>
                </div>
                <h4 className="font-semibold mb-2">Контрастність</h4>
                <p className="text-sm text-gray-600">Висока читабельність білого тексту</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-xs">HEROES</span>
                </div>
                <h4 className="font-semibold mb-2">Універсальність</h4>
                <p className="text-sm text-gray-600">Працює на різних фонах</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-black rounded-xl flex items-center justify-center mx-auto mb-4 border-2 border-gray-300">
                  <span className="text-white font-bold text-xs">🏙️</span>
                </div>
                <h4 className="font-semibold mb-2">Професійність</h4>
                <p className="text-sm text-gray-600">Сучасний корпоративний стиль</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}