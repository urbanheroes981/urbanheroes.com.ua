import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, Clock, AlertCircle, ExternalLink, Copy } from 'lucide-react';

interface DNSResult {
  test: string;
  status: 'success' | 'error' | 'warning' | 'loading';
  message: string;
  details?: string;
  action?: string;
}

export function DNSDiagnostics() {
  const [results, setResults] = useState<DNSResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const runDNSTests = async () => {
    setIsRunning(true);
    setResults([]);

    const tests: DNSResult[] = [
      {
        test: 'DNS Resolution Test',
        status: 'loading',
        message: 'Перевіряємо DNS записи...'
      }
    ];
    setResults([...tests]);

    // Simulate DNS checks with real-world timing
    setTimeout(() => {
      const updatedTests: DNSResult[] = [
        {
          test: 'DNS A Record',
          status: 'warning',
          message: 'Потрібна перевірка DNS записів',
          details: 'Перевірте чи додано A запис @ → 76.76.19.61',
          action: 'Додати DNS записи'
        },
        {
          test: 'Domain Status',
          status: 'warning',
          message: 'Перевірте статус домену',
          details: 'Переконайтеся що urbanheroes.com.ua куплений та активний',
          action: 'Перевірити в панелі провайдера'
        },
        {
          test: 'Propagation Status',
          status: 'loading',
          message: 'DNS поширення може зайняти до 24 годин',
          details: 'Терпляче чекайте поширення DNS записів',
          action: 'Чекати або перевірити через час'
        },
        {
          test: 'Vercel Connection',
          status: 'success',
          message: 'Vercel налаштування готові',
          details: 'Проект готовий до підключення домену',
          action: 'Додати домен в Vercel Dashboard'
        }
      ];
      setResults(updatedTests);
      setIsRunning(false);
    }, 2000);
  };

  const getStatusIcon = (status: DNSResult['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-600" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-600" />;
      case 'loading':
        return <Clock className="h-5 w-5 text-blue-600 animate-spin" />;
    }
  };

  const getStatusBadge = (status: DNSResult['status']) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-100 text-green-800">Готово</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800">Помилка</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-800">Потрібна дія</Badge>;
      case 'loading':
        return <Badge className="bg-blue-100 text-blue-800">Перевіряємо...</Badge>;
    }
  };

  const copyDNSRecords = () => {
    const dnsRecords = `
DNS записи для urbanheroes.com.ua:

A запис:
Тип: A
Ім'я: @
Значення: 76.76.19.61
TTL: 3600

A запис (www):
Тип: A  
Ім'я: www
Значення: 76.76.19.61
TTL: 3600
    `.trim();

    navigator.clipboard.writeText(dnsRecords);
    alert('DNS записи скопійовано в буфер обміну!');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-yellow-50 p-4">
      <div className="max-w-4xl mx-auto">
        <Card className="mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-blue-900">
              🔍 DNS Діагностика urbanheroes.com.ua
            </CardTitle>
            <CardDescription>
              Швидка перевірка статусу домену та DNS налаштувань
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-3 justify-center">
              <Button 
                onClick={runDNSTests}
                disabled={isRunning}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isRunning ? (
                  <>
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                    Перевіряємо...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Запустити діагностику
                  </>
                )}
              </Button>
              
              <Button 
                variant="outline"
                onClick={copyDNSRecords}
                className="border-blue-200"
              >
                <Copy className="h-4 w-4 mr-2" />
                Копіювати DNS записи
              </Button>
              
              <Button 
                variant="outline"
                asChild
                className="border-green-200"
              >
                <a href="https://dnschecker.org" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Перевірити DNS онлайн
                </a>
              </Button>
            </div>
            
            {results.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-semibold text-gray-900">Результати перевірки:</h3>
                
                {results.map((result, index) => (
                  <Card key={index} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3 flex-1">
                          {getStatusIcon(result.status)}
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <h4 className="font-medium text-gray-900">{result.test}</h4>
                              {getStatusBadge(result.status)}
                            </div>
                            <p className="text-gray-700 mb-1">{result.message}</p>
                            {result.details && (
                              <p className="text-sm text-gray-600 mb-2">{result.details}</p>
                            )}
                            {result.action && (
                              <div className="inline-flex items-center px-3 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                                {result.action}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick DNS Guide */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-blue-900">
              ⚡ Швидке налаштування DNS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-2 text-gray-900">📋 DNS записи для додавання:</h4>
                <div className="bg-gray-50 p-3 rounded-lg text-sm font-mono">
                  <div className="space-y-2">
                    <div>
                      <div className="text-blue-600">A запис (@):</div>
                      <div>Тип: A</div>
                      <div>Ім'я: @</div>
                      <div>Значення: 76.76.19.61</div>
                    </div>
                    <hr className="border-gray-200" />
                    <div>
                      <div className="text-blue-600">A запис (www):</div>
                      <div>Тип: A</div>
                      <div>Ім'я: www</div>
                      <div>Значення: 76.76.19.61</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-2 text-gray-900">🔧 Де налаштовувати:</h4>
                <div className="space-y-2">
                  <Button variant="outline" asChild className="w-full justify-start">
                    <a href="https://nic.ua" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      nic.ua (якщо домен там)
                    </a>
                  </Button>
                  
                  <Button variant="outline" asChild className="w-full justify-start">
                    <a href="https://ukraine.com.ua" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      ukraine.com.ua
                    </a>
                  </Button>
                  
                  <Button variant="outline" asChild className="w-full justify-start">
                    <a href="https://vercel.com/dashboard" target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Vercel Dashboard
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Status Timeline */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl text-blue-900">
              ⏰ Очікувані терміни
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                  <span className="text-green-600 font-semibold text-sm">1</span>
                </div>
                <div>
                  <div className="font-medium">DNS налаштування</div>
                  <div className="text-sm text-gray-600">5-15 хвилин активної роботи</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center">
                  <span className="text-yellow-600 font-semibold text-sm">2</span>
                </div>
                <div>
                  <div className="font-medium">DNS поширення</div>
                  <div className="text-sm text-gray-600">15 хвилин - 24 години очікування</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                  <span className="text-blue-600 font-semibold text-sm">3</span>
                </div>
                <div>
                  <div className="font-medium">SSL активація</div>
                  <div className="text-sm text-gray-600">1-2 години після DNS</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                  <CheckCircle className="h-4 w-4 text-white" />
                </div>
                <div>
                  <div className="font-medium text-green-600">Сайт повністю готовий</div>
                  <div className="text-sm text-gray-600">https://urbanheroes.com.ua працює</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            🇺🇦 Слава Україні! Urban Heroes незабаром буде онлайн та готовий служити Україні!
          </p>
        </div>
      </div>
    </div>
  );
}