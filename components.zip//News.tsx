import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Star,
  Trophy,
  Award,
  ArrowRight,
  Heart,
  Shield,
  Zap,
  Target,
  CheckCircle,
  Camera,
  Video,
  FileText
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import heroLogo from 'figma:asset/db70ba7fd23873889e37f7b0bf8a96eb8f12323a.png';

interface NewsProps {
  onPageChange?: (page: string) => void;
}

export function News({ onPageChange }: NewsProps) {
  const latestNews = [
    {
      id: 1,
      title: "Запуск нової платформи для ветеранів",
      summary: "Офіційно відкрито проект 'Герої повертаються' - комплексну програму підтримки ветеранів",
      date: "15 січня 2026",
      category: "Ветерани",
      image: "https://images.unsplash.com/photo-1640238490075-c239ad4cb081?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwbWFpbnRlbmFuY2UlMjB3b3JrZXJzJTIwZW1lcmdlbmN5fGVufDF8fHx8MTc1ODAzNTk0N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Shield,
      color: "from-blue-500 to-yellow-500"
    },
    {
      id: 2,
      title: "IT-хакатон 'Технології для добра' завершився успіхом",
      summary: "100 молодих програмістів створили 25 проектів для покращення міського життя",
      date: "26 січня 2026",
      category: "Молодь",
      image: "https://images.unsplash.com/photo-1745571479662-54a2ad1c747f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHx5b3VuZyUyMHBlb3BsZSUyMGNvZGluZyUyMHByb2dyYW1taW5nJTIwVWtyYWluZXxlbnwxfHx8fDE3NTgwMzYzMDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Zap,
      color: "from-purple-500 to-blue-500"
    },
    {
      id: 3,
      title: "Рекордне скорочення часу реагування на проблеми",
      summary: "Завдяки новій системі час реагування скоротився з 6 годин до 30 хвилин",
      date: "20 січня 2026", 
      category: "Досягнення",
      image: "https://images.unsplash.com/photo-1469510090920-fd33379d1f7c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwc3RyZWV0JTIwcHJvYmxlbXMlMjBwb3Rob2xlc3xlbnwxfHx8fDE3NTgwMzU5NDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      icon: Target,
      color: "from-green-500 to-teal-500"
    }
  ];

  const upcomingEvents = [
    {
      title: "Фестиваль молодіжного мистецтва",
      date: "15 лютого 2026",
      time: "10:00 - 18:00",
      location: "Парк Шевченка, Київ",
      description: "Відкрита виставка робіт учасників творчих майстерень та концерт молодих виконавців",
      participants: "Очікується 500+ відвідувачів",
      icon: Star,
      color: "bg-pink-100 text-pink-600"
    },
    {
      title: "Школа молодого лідера",
      date: "1 березня 2026",
      time: "09:00 - 17:00",
      location: "Центр розвитку, вул. Хрещатик, 25",
      description: "Інтенсивний тренінг з розвитку лідерських навичок для активної молоді",
      participants: "50 місць, реєстрація відкрита",
      icon: Trophy,
      color: "bg-blue-100 text-blue-600"
    },
    {
      title: "Зустріч ветеранських спільнот",
      date: "10 березня 2026",
      time: "14:00 - 16:00",
      location: "Ветеранський центр",
      description: "Обговорення нових ініціатив підтримки та обмін досвідом",
      participants: "Відкрито для всіх ветеранів",
      icon: Shield,
      color: "bg-yellow-100 text-yellow-600"
    }
  ];

  const mediaResources = [
    {
      type: "Відео",
      title: "Як працює платформа 'Міські герої'",
      duration: "3:45",
      views: "12K переглядів",
      icon: Video,
      color: "text-red-500"
    },
    {
      type: "Фотогалерея",
      title: "IT-хакатон 'Технології для добра'",
      count: "48 фото",
      views: "8.5K переглядів",
      icon: Camera,
      color: "text-blue-500"
    },
    {
      type: "Звіт",
      title: "Річний звіт діяльності 2025",
      pages: "32 сторінки",
      downloads: "1.2K завантажень",
      icon: FileText,
      color: "text-green-500"
    }
  ];

  const achievements2025 = [
    {
      title: "Найкращий соціальний проект року",
      description: "Проект 'Герої повертаються' отримав національну премію",
      date: "Грудень 2025",
      icon: Award
    },
    {
      title: "2000 активних героїв",
      description: "Досягнуто планову кількість учасників платформи",
      date: "Листопад 2025",
      icon: Users
    },
    {
      title: "95% задоволеності громадян",
      description: "Рекордний показник якості наданих послуг",
      date: "Жовтень 2025",
      icon: CheckCircle
    }
  ];

  return (
    <section className="py-20 relative">
      {/* Ukrainian flag wheat field background */}
      <div className="absolute inset-0 ukrainian-flag-wheat-bg" />
      {/* Patriotic overlay for better readability */}
      <div className="absolute inset-0 ukrainian-flag-wheat-overlay" />
      
      <div className="relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-blue-600 rounded-xl flex items-center justify-center p-2">
              <img src={heroLogo} alt="Міські герої" className="w-12 h-12 object-contain filter brightness-0 invert" />
            </div>
          </div>
          <div className="flex items-center justify-center space-x-3 mb-6">
            <Calendar className="w-10 h-10 text-blue-500" />
            <Star className="w-8 h-8 text-yellow-500" />
            <Trophy className="w-10 h-10 text-green-500" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Новини та події
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Слідкуйте за останніми новинами, подіями та досягненнями організації "Міські герої". 
            Будьте в курсі всіх важливих оновлень та можливостей для участі.
          </p>
        </div>

        {/* Latest News */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Останні новини
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {latestNews.map((news) => {
              const IconComponent = news.icon;
              return (
                <Card key={news.id} className="overflow-hidden hover:shadow-xl transition-shadow duration-300 group">
                  <div className="relative">
                    <ImageWithFallback
                      src={news.image}
                      alt={news.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className={`absolute top-4 left-4 bg-gradient-to-r ${news.color} p-2 rounded-lg`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="absolute top-4 right-4 bg-white/90 px-2 py-1 rounded text-xs font-medium text-gray-700">
                      {news.category}
                    </div>
                  </div>
                  
                  <CardHeader>
                    <div className="flex items-center text-gray-500 text-sm mb-2">
                      <Calendar className="w-4 h-4 mr-1" />
                      {news.date}
                    </div>
                    <CardTitle className="text-xl">{news.title}</CardTitle>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-gray-600 leading-relaxed mb-4">{news.summary}</p>
                    <button className="flex items-center text-blue-600 hover:text-blue-800 transition-colors">
                      Читати далі
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Найближчі події
          </h2>
          <div className="space-y-6">
            {upcomingEvents.map((event, index) => {
              const IconComponent = event.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow duration-300">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="flex items-start space-x-4 mb-4 md:mb-0">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${event.color}`}>
                        <IconComponent className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{event.title}</h3>
                        <p className="text-gray-600 mb-3">{event.description}</p>
                        
                        <div className="flex flex-col sm:flex-row sm:items-center gap-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {event.date}
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {event.time}
                          </div>
                          <div className="flex items-center">
                            <MapPin className="w-4 h-4 mr-1" />
                            {event.location}
                          </div>
                        </div>
                        
                        <div className="mt-2 text-sm font-medium text-blue-600">
                          {event.participants}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row gap-2">
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                        Зареєструватися
                      </button>
                      <button className="border border-blue-600 text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                        Дізнатися більше
                      </button>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Media Resources */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Медіаресурси
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {mediaResources.map((resource, index) => {
              const IconComponent = resource.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow duration-300 text-center">
                  <div className="flex items-center justify-center mb-4">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                      <IconComponent className={`w-8 h-8 ${resource.color}`} />
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 mb-2">{resource.type}</div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{resource.title}</h3>
                  <div className="text-sm text-gray-600 mb-4">
                    {resource.duration || resource.count || resource.pages}
                  </div>
                  <div className="text-xs text-gray-500 mb-4">
                    {resource.views || resource.downloads}
                  </div>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    Переглянути
                  </button>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Achievements 2025 */}
        <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">Досягнення 2025 року</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {achievements2025.map((achievement, index) => {
              const IconComponent = achievement.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-yellow-300" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{achievement.title}</h3>
                  <p className="text-blue-100 mb-2">{achievement.description}</p>
                  <div className="text-sm text-yellow-300">{achievement.date}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Newsletter Subscription */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">
            Будьте в курсі всіх новин!
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Підпишіться на нашу розсилку, щоб першими дізнаватися про нові проекти, події та можливості.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input 
              type="email" 
              placeholder="Введіть ваш email"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button className="bg-gradient-to-r from-blue-500 to-yellow-500 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-200">
              Підписатися
            </button>
          </div>
        </div>
      </div>
      </div>
    </section>
  );
}