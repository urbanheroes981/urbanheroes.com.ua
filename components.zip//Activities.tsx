import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  Activity, 
  Shield, 
  Users, 
  MapPin, 
  Smartphone, 
  Zap, 
  Eye, 
  Database,
  MessageSquare,
  Clock,
  Star,
  Heart,
  HandHeart,
  Building,
  GraduationCap,
  Briefcase,
  CheckCircle
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import heroLogo from 'figma:asset/db70ba7fd23873889e37f7b0bf8a96eb8f12323a.png';

interface ActivitiesProps {
  onPageChange?: (page: string) => void;
}

export function Activities({ onPageChange }: ActivitiesProps) {
  const mainActivities = [
    {
      icon: Shield,
      title: "Екстрене реагування",
      description: "Координація роботи з екстреними службами міста для швидкого реагування на критичні ситуації.",
      color: "from-red-500 to-orange-600",
      stats: "24/7 моніторинг"
    },
    {
      icon: Users,
      title: "Громадська участь",
      description: "Залучення громадян до вирішення міських проблем через платформи для звітування та волонтерства.",
      color: "from-blue-500 to-indigo-600",
      stats: "2000+ активних героїв"
    },
    {
      icon: HandHeart,
      title: "Соціальна підтримка",
      description: "Програми підтримки ветеранів, внутрішньо переміщених осіб та інших вразливих категорій населення.",
      color: "from-green-500 to-teal-600",
      stats: "1500+ сімей отримали допомогу"
    },
    {
      icon: GraduationCap,
      title: "Освітні ініціативи",
      description: "Навчальні програми для молоді, ветеранів та громадян з цифрової грамотності та підприємництва.",
      color: "from-purple-500 to-indigo-600",
      stats: "500+ випускників"
    }
  ];

  const cityServices = [
    {
      icon: Building,
      title: "Міське управління",
      description: "Координація з департаментами міської ради для ефективного вирішення проблем громадян.",
      departments: ["ЖКГ", "Транспорт", "Благоустрій", "Екологія"]
    },
    {
      icon: Eye,
      title: "Моніторинг інфраструктури",
      description: "Регулярна перевірка стану міської інфраструктури та оперативне реагування на порушення.",
      departments: ["Дороги", "Освітлення", "Водопостачання", "Теплопостачання"]
    },
    {
      icon: Smartphone,
      title: "Цифрові рішення",
      description: "Розробка та впровадження сучасних IT-рішень для покращення якості міських послуг.",
      departments: ["Мобільні додатки", "Веб-платформи", "Аналітика", "Автоматизація"]
    }
  ];

  const achievements = [
    {
      title: "Скорочення часу реагування",
      description: "З 6 годин до 30 хвилин",
      icon: Clock,
      color: "text-green-600"
    },
    {
      title: "Збільшення вирішених проблем",
      description: "З 60% до 95%",
      icon: CheckCircle,
      color: "text-blue-600"
    },
    {
      title: "Зростання громадської участі",
      description: "В 10 разів за рік",
      icon: Users,
      color: "text-purple-600"
    },
    {
      title: "Покращення задоволеності",
      description: "З 3.2 до 4.8 з 5",
      icon: Star,
      color: "text-yellow-600"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-blue-600 rounded-xl flex items-center justify-center p-2">
              <img src={heroLogo} alt="Міські герої" className="w-12 h-12 object-contain filter brightness-0 invert" />
            </div>
          </div>
          <div className="flex items-center justify-center space-x-3 mb-6">
            <Activity className="w-10 h-10 text-blue-500" />
            <Star className="w-8 h-8 text-yellow-500" />
            <Heart className="w-10 h-10 text-red-500" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Наша діяльність
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Ми працюємо у різних напрямках для створення безпечного, комфортного та розвинутого міського середовища. 
            Наша мета - об'єднати зусилля громадян, бізнесу та влади для досягнення спільних цілей.
          </p>
        </div>

        {/* Main Activities */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Основні напрямки роботи
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {mainActivities.map((activity, index) => {
              const IconComponent = activity.icon;
              return (
                <Card 
                  key={index} 
                  className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 shadow-lg h-full"
                >
                  <CardHeader className="text-center pb-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${activity.color} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl text-gray-900">{activity.title}</CardTitle>
                    <div className="text-sm font-medium text-blue-600">{activity.stats}</div>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 leading-relaxed">{activity.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* City Services Coordination */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Співпраця з міськими службами
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {cityServices.map((service, index) => {
              const IconComponent = service.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow duration-300">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{service.title}</h3>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {service.description}
                  </p>
                  
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Підрозділи:</h4>
                    <div className="flex flex-wrap gap-2">
                      {service.departments.map((dept, deptIndex) => (
                        <span 
                          key={deptIndex}
                          className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
                        >
                          {dept}
                        </span>
                      ))}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Key Achievements */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Ключові досягнення
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {achievements.map((achievement, index) => {
              const IconComponent = achievement.icon;
              return (
                <div key={index} className="text-center p-6 bg-white rounded-xl shadow-lg">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 ${achievement.color.replace('text-', 'bg-').replace('600', '100')}`}>
                    <IconComponent className={`w-6 h-6 ${achievement.color}`} />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">{achievement.title}</h3>
                  <p className="text-2xl font-bold text-blue-600 mb-2">{achievement.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Statistics */}
        <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white text-center mb-20">
          <h2 className="text-3xl font-bold mb-8">Наша діяльність у цифрах</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-blue-100">Партнерських організацій</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">10,000+</div>
              <div className="text-blue-100">Вирішених проблем</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">25</div>
              <div className="text-blue-100">Міських департаментів</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">365</div>
              <div className="text-blue-100">Днів на рік працюємо</div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">
            Готові приєднатися до нашої діяльності?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Станьте частиною змін у вашому місті. Долучайтеся до наших проектів та ініціатив.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => onPageChange?.('join')}
              className="bg-gradient-to-r from-blue-500 to-yellow-500 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <HandHeart className="w-5 h-5" />
              <span>Долучитися</span>
            </button>
            <button 
              onClick={() => onPageChange?.('projects')}
              className="border-2 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
            >
              <Star className="w-5 h-5" />
              <span>Переглянути проекти</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}