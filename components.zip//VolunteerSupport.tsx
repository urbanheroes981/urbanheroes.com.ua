import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useLanguage } from '../i18n/LanguageContext';
import { 
  Heart, 
  Users, 
  Phone, 
  MessageSquare, 
  Upload,
  HandHeart,
  BookOpen,
  Shield,
  Briefcase,
  Star,
  CheckCircle,
  Clock,
  MapPin,
  Calendar,
  Target
} from 'lucide-react';

export function VolunteerSupport() {
  const { language, translations } = useLanguage();
  const t = translations[language];
  const [formData, setFormData] = useState({
    supportType: '',
    urgency: '',
    description: '',
    location: '',
    availability: '',
    skills: '',
    contact: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const supportTypes = [
    { value: 'veterans', label: 'Підтримка ветеранів', icon: Shield },
    { value: 'youth', label: 'Молодіжні проекти', icon: Star },
    { value: 'education', label: 'Освітні програми', icon: BookOpen },
    { value: 'community', label: 'Громадські ініціативи', icon: Users },
    { value: 'business', label: 'Ветеранський бізнес', icon: Briefcase },
    { value: 'other', label: 'Інша підтримка', icon: HandHeart }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 2000);
  };

  if (isSubmitted) {
    return (
      <section className="py-20 bg-gradient-to-br from-blue-50 via-yellow-50 to-blue-100 relative">
        {/* Patriotic background overlay */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `url("https://images.unsplash.com/photo-1647472270676-fc9bc37a06ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBmbGFnJTIwYmFja2dyb3VuZCUyMHRleHR1cmV8ZW58MXx8fHwxNzU4MTIzMTMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral")`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat'
          }}
        />
        
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-green-200 bg-green-50 shadow-xl">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-yellow-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-green-800 mb-4">{t.volunteerSupport.submitted}</h2>
              <p className="text-green-700 text-lg mb-6">
                {t.volunteerSupport.successMessage}
              </p>
              <div className="bg-white rounded-lg p-6 mb-6">
                <div className="text-sm text-gray-600 mb-2">Номер запиту</div>
                <div className="text-lg font-mono text-gray-900">УГ-2024-001847</div>
              </div>
              <Button 
                onClick={() => setIsSubmitted(false)}
                className="bg-gradient-to-r from-blue-600 to-yellow-500 text-white hover:from-blue-700 hover:to-yellow-600"
              >
                {t.volunteerSupport.submitAnother}
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gradient-to-br from-blue-50 via-yellow-50 to-blue-100 relative">
      {/* Patriotic background overlay */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("https://images.unsplash.com/photo-1647472270676-fc9bc37a06ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBmbGFnJTIwYmFja2dyb3VuZCUyMHRleHR1cmV8ZW58MXx8fHwxNzU4MTIzMTMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            {t.volunteerSupport.title}
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            {t.volunteerSupport.description}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-xl border-blue-200">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-yellow-500 text-white rounded-t-lg">
                <CardTitle className="flex items-center text-2xl">
                  <HandHeart className="w-6 h-6 mr-2" />
                  {t.volunteerSupport.formTitle}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Support Type */}
                  <div>
                    <Label className="text-base font-semibold mb-3 block text-gray-800">Тип підтримки *</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {supportTypes.map((type) => {
                        const IconComponent = type.icon;
                        return (
                          <button
                            key={type.value}
                            type="button"
                            onClick={() => setFormData(prev => ({ ...prev, supportType: type.value }))}
                            className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                              formData.supportType === type.value
                                ? 'border-blue-500 bg-blue-50 text-blue-700'
                                : 'border-gray-200 hover:border-blue-300 text-gray-700 hover:bg-blue-50'
                            }`}
                          >
                            <IconComponent className="w-6 h-6 mx-auto mb-2" />
                            <div className="text-sm font-medium">{type.label}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Urgency */}
                  <div>
                    <Label htmlFor="urgency" className="text-base font-semibold text-gray-800">Пріоритет *</Label>
                    <Select value={formData.urgency} onValueChange={(value) => setFormData(prev => ({ ...prev, urgency: value }))}>
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="Оберіть пріоритет запиту" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-green-400 rounded-full mr-2"></div>
                            Низький - Планова підтримка
                          </div>
                        </SelectItem>
                        <SelectItem value="medium">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-yellow-400 rounded-full mr-2"></div>
                            Середній - Потрібна допомога
                          </div>
                        </SelectItem>
                        <SelectItem value="high">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-red-400 rounded-full mr-2"></div>
                            Високий - Термінова підтримка
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Location */}
                  <div>
                    <Label className="text-base font-semibold mb-2 block text-gray-800">Місцезнаходження</Label>
                    <div className="flex space-x-2">
                      <Input
                        value={formData.location}
                        onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                        placeholder="Місто, область або адреса"
                        className="flex-1"
                      />
                      <Button type="button" variant="outline" className="flex-shrink-0 border-blue-300 text-blue-600 hover:bg-blue-50">
                        <MapPin className="w-4 h-4 mr-2" />
                        GPS
                      </Button>
                    </div>
                  </div>

                  {/* Availability */}
                  <div>
                    <Label htmlFor="availability" className="text-base font-semibold text-gray-800">Коли потрібна підтримка</Label>
                    <Input
                      id="availability"
                      value={formData.availability}
                      onChange={(e) => setFormData(prev => ({ ...prev, availability: e.target.value }))}
                      placeholder="Наприклад: цього тижня, наступного місяця, 15-20 січня"
                      className="mt-2"
                    />
                  </div>

                  {/* Skills Needed */}
                  <div>
                    <Label htmlFor="skills" className="text-base font-semibold text-gray-800">Потрібні навички/допомога</Label>
                    <Input
                      id="skills"
                      value={formData.skills}
                      onChange={(e) => setFormData(prev => ({ ...prev, skills: e.target.value }))}
                      placeholder="Наприклад: IT-підтримка, організація заходів, юридична консультація"
                      className="mt-2"
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <Label htmlFor="description" className="text-base font-semibold text-gray-800">Опис проекту/потреби *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Детально опишіть ваш проект, цілі та як волонтери можуть допомогти"
                      className="mt-2 min-h-[120px]"
                      required
                    />
                  </div>

                  {/* Contact */}
                  <div>
                    <Label htmlFor="contact" className="text-base font-semibold text-gray-800">Контактна інформація *</Label>
                    <Input
                      id="contact"
                      value={formData.contact}
                      onChange={(e) => setFormData(prev => ({ ...prev, contact: e.target.value }))}
                      placeholder="Телефон або email для зв'язку"
                      className="mt-2"
                      required
                    />
                  </div>

                  {/* File Upload */}
                  <div>
                    <Label className="text-base font-semibold mb-2 block text-gray-800">Додаткові матеріали (необов'язково)</Label>
                    <div className="border-2 border-dashed border-blue-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors bg-blue-50">
                      <Upload className="w-8 h-8 text-blue-400 mx-auto mb-3" />
                      <p className="text-blue-600 mb-2">Натисніть для завантаження або перетягніть файли</p>
                      <p className="text-sm text-blue-500">Презентації, плани проектів, фото (PDF, DOC, JPG до 10MB)</p>
                      <Button type="button" variant="outline" className="mt-3 border-blue-300 text-blue-600 hover:bg-blue-100">
                        <Upload className="w-4 h-4 mr-2" />
                        Обрати файли
                      </Button>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-yellow-500 hover:from-blue-700 hover:to-yellow-600 text-white py-6 text-lg shadow-lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Clock className="w-5 h-5 mr-2 animate-spin" />
                        Надсилання запиту...
                      </>
                    ) : (
                      <>
                        <HandHeart className="w-5 h-5 mr-2" />
                        Надіслати запит на підтримку
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Success Stories */}
            <Card className="border-green-200 bg-green-50 shadow-lg">
              <CardHeader>
                <CardTitle className="text-green-800 flex items-center">
                  <Heart className="w-5 h-5 mr-2" />
                  Історії успіху
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-white rounded-lg p-4">
                    <p className="text-sm text-gray-700 mb-2">
                      "Завдяки волонтерам запустили IT-курси для 50 ветеранів"
                    </p>
                    <div className="text-xs text-gray-500">- Сергій, керівник проекту</div>
                  </div>
                  <div className="bg-white rounded-lg p-4">
                    <p className="text-sm text-gray-700 mb-2">
                      "Організували патріотичний табір для 120 підлітків"
                    </p>
                    <div className="text-xs text-gray-500">- Марія, координатор молоді</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card className="border-blue-200 bg-blue-50 shadow-lg">
              <CardHeader>
                <CardTitle className="text-blue-800 flex items-center">
                  <Phone className="w-5 h-5 mr-2" />
                  Контакти координаторів
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full border-blue-300 text-blue-700 hover:bg-blue-100"
                  onClick={() => window.open('tel:+380501234567')}
                >
                  <Phone className="w-4 h-4 mr-2" />
                  +38 (050) 123-45-67
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-blue-300 text-blue-700 hover:bg-blue-100"
                  onClick={() => window.open('mailto:volunteer@urbanheroes.com.ua')}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  volunteer@urbanheroes.com.ua
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-blue-300 text-blue-700 hover:bg-blue-100"
                >
                  <Calendar className="w-4 h-4 mr-2" />
                  Записатися на зустріч
                </Button>
              </CardContent>
            </Card>

            {/* Support Tips */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-gray-800 flex items-center">
                  <Target className="w-5 h-5 mr-2 text-blue-600" />
                  Поради для запиту
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Чітко опишіть цілі та очікувані результати проекту</p>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Вкажіть конкретні навички, які потрібні волонтерам</p>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Додайте терміни реалізації та графік роботи</p>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Прикріпіть план проекту або презентацію</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Volunteer Stats */}
            <Card className="shadow-lg">
              <CardContent className="p-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">247</div>
                  <div className="text-sm text-gray-600">Активних волонтерів</div>
                </div>
                <div className="mt-4 text-center">
                  <div className="text-lg font-semibold text-blue-600">92%</div>
                  <div className="text-xs text-gray-500">Проектів реалізовано успішно</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white">
            <h3 className="text-3xl font-bold mb-4">Разом ми сильніші!</h3>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Організація "Міські герої" об'єднує професіоналів, ветеранів та активну молодь 
              для реалізації проектів, що роблять нашу країну кращою.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="text-center">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1631039083528-c05cdf3329a6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2b2x1bnRlZXIlMjBVa3JhaW5lJTIwY29tbXVuaXR5JTIwcHJvamVjdCUyMHN1cHBvcnR8ZW58MXx8fHwxNzU4MjAxOTYzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Волонтери в дії"
                  className="w-20 h-20 rounded-full mx-auto mb-4 object-cover border-4 border-white"
                />
                <h4 className="font-semibold mb-2">Підтримка ветеранів</h4>
                <p className="text-blue-100 text-sm">Реабілітація, освіта, бізнес</p>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-yellow-400 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Star className="w-10 h-10 text-yellow-800" />
                </div>
                <h4 className="font-semibold mb-2">Молодіжні ініціативи</h4>
                <p className="text-blue-100 text-sm">Патріотичне виховання, лідерство</p>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-blue-400 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="w-10 h-10 text-blue-800" />
                </div>
                <h4 className="font-semibold mb-2">Громадські проекти</h4>
                <p className="text-blue-100 text-sm">Розвиток спільнот, культура</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}