import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { 
  Camera, 
  MapPin, 
  Phone, 
  MessageSquare, 
  Upload,
  Waves,
  Wind,
  AlertTriangle,
  Thermometer,
  Eye,
  Clock,
  CheckCircle
} from 'lucide-react';

export function CitizenReporting() {
  const [formData, setFormData] = useState({
    hazardType: '',
    severity: '',
    description: '',
    location: 'Detecting GPS location...',
    photos: []
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const hazardTypes = [
    { value: 'waves', label: 'High Waves', icon: Waves },
    { value: 'storm', label: 'Storm', icon: Wind },
    { value: 'flooding', label: 'Coastal Flooding', icon: AlertTriangle },
    { value: 'temperature', label: 'Temperature Anomaly', icon: Thermometer },
    { value: 'visibility', label: 'Poor Visibility', icon: Eye },
    { value: 'other', label: 'Other Hazard', icon: AlertTriangle }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 2000);
  };

  if (isSubmitted) {
    return (
      <section className="py-20 bg-gradient-to-b from-white to-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-12 text-center">
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-green-800 mb-4">Report Submitted Successfully!</h2>
              <p className="text-green-700 text-lg mb-6">
                Your hazard report has been received and is being verified by our AI system. 
                Emergency authorities will be notified if verification is successful.
              </p>
              <div className="bg-white rounded-lg p-6 mb-6">
                <div className="text-sm text-gray-600 mb-2">Report ID</div>
                <div className="text-lg font-mono text-gray-900">HR-2024-001847</div>
              </div>
              <Button 
                onClick={() => setIsSubmitted(false)}
                className="bg-green-600 hover:bg-green-700"
              >
                Submit Another Report
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Report Ocean Hazard
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
            Help protect your community by reporting ocean hazards you observe. 
            Your report will be verified and shared with emergency authorities.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                  <AlertTriangle className="w-6 h-6 mr-2 text-orange-500" />
                  Hazard Report Form
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Hazard Type */}
                  <div>
                    <Label className="text-base font-semibold mb-3 block">Type of Hazard *</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {hazardTypes.map((type) => {
                        const IconComponent = type.icon;
                        return (
                          <button
                            key={type.value}
                            type="button"
                            onClick={() => setFormData(prev => ({ ...prev, hazardType: type.value }))}
                            className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                              formData.hazardType === type.value
                                ? 'border-cyan-500 bg-cyan-50 text-cyan-700'
                                : 'border-gray-200 hover:border-gray-300 text-gray-700'
                            }`}
                          >
                            <IconComponent className="w-6 h-6 mx-auto mb-2" />
                            <div className="text-sm font-medium">{type.label}</div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Severity */}
                  <div>
                    <Label htmlFor="severity" className="text-base font-semibold">Severity Level *</Label>
                    <Select value={formData.severity} onValueChange={(value) => setFormData(prev => ({ ...prev, severity: value }))}>
                      <SelectTrigger className="mt-2">
                        <SelectValue placeholder="Select severity level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-yellow-400 rounded-full mr-2"></div>
                            Low - Minor concern
                          </div>
                        </SelectItem>
                        <SelectItem value="medium">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-orange-400 rounded-full mr-2"></div>
                            Medium - Potential danger
                          </div>
                        </SelectItem>
                        <SelectItem value="high">
                          <div className="flex items-center">
                            <div className="w-3 h-3 bg-red-400 rounded-full mr-2"></div>
                            High - Immediate danger
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Location */}
                  <div>
                    <Label className="text-base font-semibold mb-2 block">Location</Label>
                    <div className="flex space-x-2">
                      <Input
                        value={formData.location}
                        onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                        placeholder="Enter location or use GPS"
                        className="flex-1"
                      />
                      <Button type="button" variant="outline" className="flex-shrink-0">
                        <MapPin className="w-4 h-4 mr-2" />
                        GPS
                      </Button>
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <Label htmlFor="description" className="text-base font-semibold">Description *</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Describe what you're observing (e.g., wave height, water level, weather conditions)"
                      className="mt-2 min-h-[100px]"
                      required
                    />
                  </div>

                  {/* Photo/Video Upload */}
                  <div>
                    <Label className="text-base font-semibold mb-2 block">Photos/Videos (Optional)</Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-3" />
                      <p className="text-gray-600 mb-2">Click to upload or drag and drop</p>
                      <p className="text-sm text-gray-500">PNG, JPG, MP4 up to 10MB</p>
                      <Button type="button" variant="outline" className="mt-3">
                        <Camera className="w-4 h-4 mr-2" />
                        Choose Files
                      </Button>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white py-6 text-lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Clock className="w-5 h-5 mr-2 animate-spin" />
                        Submitting Report...
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-5 h-5 mr-2" />
                        Submit Hazard Report
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Emergency Actions */}
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="text-red-800 flex items-center">
                  <Phone className="w-5 h-5 mr-2" />
                  Emergency Actions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-red-600 hover:bg-red-700 text-white">
                  <Phone className="w-4 h-4 mr-2" />
                  Call 911
                </Button>
                <Button variant="outline" className="w-full border-red-300 text-red-700 hover:bg-red-50">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Text Emergency Services
                </Button>
                <Button variant="outline" className="w-full border-red-300 text-red-700 hover:bg-red-50">
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Alert Nearby Users
                </Button>
              </CardContent>
            </Card>

            {/* Reporting Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="text-cyan-800">Reporting Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Include specific details like wave height, water level, or weather conditions</p>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Photos and videos help authorities assess the situation quickly</p>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Your location is automatically detected for faster response</p>
                  </div>
                  <div className="flex items-start">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <p>Reports are verified by AI before alerting authorities</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Status Badge */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Your Reporter Status</span>
                  <Badge className="bg-green-100 text-green-800">Verified</Badge>
                </div>
                <div className="mt-2 text-xs text-gray-500">
                  Reputation Score: 4.8/5.0 (127 reports)
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}