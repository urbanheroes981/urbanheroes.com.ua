import { useState } from 'react';
import { Button } from './ui/button';
import { Menu, X, Globe } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { LogoCompact } from './Logo';

interface NavigationProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export function Navigation({ currentPage, onPageChange }: NavigationProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const navItems = [
    { id: 'home', label: t('nav.home') },
    { id: 'about', label: t('nav.about') },
    { id: 'features', label: t('nav.services') },
    { id: 'veteran-project', label: t('nav.veteranProject') },
    { id: 'youth-project', label: t('nav.youthProject') },
    { id: 'how-it-works', label: t('nav.howItWorks') },
    { id: 'news-events', label: t('nav.newsEvents') },
    { id: 'join', label: t('nav.join') },
    { id: 'support', label: t('nav.support') },
    { id: 'contact', label: t('nav.contact') }
  ];

  const toggleLanguage = () => {
    setLanguage(language === 'uk' ? 'en' : 'uk');
  };

  return (
    <nav className="bg-white/95 backdrop-blur-sm border-b border-blue-100/50 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => onPageChange('home')}>
            <LogoCompact className="scale-75" />
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {/* Logo in navigation */}
            <div className="flex items-center mr-4">
              <LogoCompact size="sm" />
            </div>
            
            {navItems.map((item) => (
              <Button
                key={item.id}
                variant={currentPage === item.id ? "default" : "ghost"}
                onClick={() => onPageChange(item.id)}
                className={`text-sm ${
                  currentPage === item.id 
                    ? 'bg-gradient-to-r from-blue-500 to-yellow-500 text-white' 
                    : 'text-gray-700 hover:text-blue-600'
                }`}
              >
                {item.label}
              </Button>
            ))}
            
            {/* Language Toggle Button */}
            <Button
              variant="ghost"
              onClick={toggleLanguage}
              className="text-gray-700 hover:text-blue-600 ml-2"
              title={language === 'uk' ? 'Switch to English' : 'Перейти на українську'}
            >
              <Globe className="w-4 h-4 mr-1" />
              {language === 'uk' ? 'EN' : 'УК'}
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-blue-100/50 py-2">
            <div className="flex flex-col space-y-1">
              {/* Logo in mobile navigation */}
              <div className="flex items-center justify-center py-4">
                <LogoCompact size="md" />
              </div>
              
              {navItems.map((item) => (
                <Button
                  key={item.id}
                  variant={currentPage === item.id ? "default" : "ghost"}
                  onClick={() => {
                    onPageChange(item.id);
                    setIsMenuOpen(false);
                  }}
                  className={`text-left justify-start ${
                    currentPage === item.id 
                      ? 'bg-gradient-to-r from-blue-500 to-yellow-500 text-white' 
                      : 'text-gray-700'
                  }`}
                >
                  {item.label}
                </Button>
              ))}              
              
              {/* Mobile Language Toggle */}
              <Button
                variant="ghost"
                onClick={toggleLanguage}
                className="text-gray-700 justify-start mt-2"
              >
                <Globe className="w-4 h-4 mr-2" />
                {language === 'uk' ? 'Switch to English' : 'Перейти на українську'}
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}