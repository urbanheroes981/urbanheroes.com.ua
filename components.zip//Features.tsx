import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { 
  Shield, 
  Users, 
  Target,
  BookOpen,
  Heart,
  Sword,
  Star,
  GraduationCap,
  Building,
  Handshake
} from 'lucide-react';
import ukrainianSunsetFieldImage from 'figma:asset/a4255f299c9b37d54112ddfeac28a4ba0a6a0894.png';

interface FeaturesProps {
  onPageChange?: (page: string) => void;
}

export function Features({ onPageChange }: FeaturesProps) {
  const features = [
    {
      icon: Shield,
      title: "Спільноти ветеранів",
      description: "Створюємо потужні спільноти ветеранів та платформи для взаємодії з молоддю, яка готується до служби Україні.",
      color: "from-blue-600 to-yellow-500"
    },
    {
      icon: Target,
      title: "Військова підготовка",
      description: "Проводимо військові вишколи, тактичну медицину, стрілецьку та фізичну підготовку для захисників України.",
      color: "from-blue-500 to-indigo-600"
    },
    {
      icon: BookOpen,
      title: "Патріотичне виховання",
      description: "Виховуємо патріотичну молодь на базі воєнного досвіду, національної історії та сучасної кльтури України.",
      color: "from-indigo-500 to-purple-600"
    },
    {
      icon: Heart,
      title: "Підтримка ветеранів",
      description: "Захищаємо права ветеранів, підтримуємо їхнє повернення до цивільного життя, сприяємо створенню ветеранського бізнесу.",
      color: "from-purple-500 to-pink-600"
    },
    {
      icon: Sword,
      title: "Бойові мистецтва",
      description: "Пропагуємо здоровий спосіб життя, спорт та українські бойові мистецтва для фізичного та духовного розвитку.",
      color: "from-pink-500 to-red-600"
    },
    {
      icon: Star,
      title: "Українська культура",
      description: "Відроджуємо українську культуру: підтримуємо родинні свята, вивчаємо традиції та зберігаємо національну спадщину.",
      color: "from-red-500 to-orange-600"
    },
    {
      icon: GraduationCap,
      title: "Освітні програми",
      description: "Розробляємо комплексні освітні програми для військової підготовки, лідерського розвитку та професійного зростання.",
      color: "from-orange-500 to-yellow-600"
    },
    {
      icon: Building,
      title: "Ветеранський бізнес",
      description: "Підтримуємо створення та розвиток ветеранського бізнесу, надаємо консультації та сприяємо економічній інтеграції.",
      color: "from-yellow-500 to-green-600"
    },
    {
      icon: Users,
      title: "Молодіжні ініціативи",
      description: "Залучаємо молодь до національно-патріотичних проектів, розвиваємо лідерські якості та громадянську відповідальність.",
      color: "from-green-500 to-teal-600"
    },
    {
      icon: Handshake,
      title: "Соціальна інтеграція",
      description: "Сприяємо успішній інтеграції ветеранів у громадське життя через ментерство, психологічну підтримку та соціальні програми.",
      color: "from-teal-500 to-cyan-600"
    }
  ];

  return (
    <section className="py-20 relative">
      {/* Ukrainian sunset field background */}
      <div className="absolute inset-0 z-0">
        <img
          src={ukrainianSunsetFieldImage}
          alt="Ukrainian flag in sunset wheat field"
          className="w-full h-full object-cover"
        />
        
        {/* Sunset overlay for better readability */}
        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm" />
        
        {/* Warm sunset gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-orange-400/15 via-transparent to-blue-500/10" />
      </div>
      
      <div className="relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <div className="flex items-center justify-center space-x-2 mb-6">
              <Shield className="w-8 h-8 text-blue-600" />
              <Heart className="w-6 h-6 text-yellow-500" />
              <Star className="w-8 h-8 text-blue-500" />
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Наші програми та послуги
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Ми створюємо комплексні програми для підтримки ветеранів, підготовки молоді до служби та відродження 
              українських традицій через сучасні підходи та технології.
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card 
                  key={index} 
                  className="group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 shadow-lg"
                >
                  <CardHeader className="text-center pb-4">
                    <div className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                      <IconComponent className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl text-gray-900">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Bottom CTA Section */}
          <div className="mt-20 text-center">
            <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white">
              <div className="flex items-center justify-center space-x-3 mb-4">
                <Shield className="w-8 h-8 text-blue-200" />
                <h3 className="text-3xl font-bold">Готові стати герєм України?</h3>
                <Star className="w-8 h-8 text-yellow-300" />
              </div>
              <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
                Приєднуйтесь до нашої спільноти героїв України. Разом ми будуємо сильну, незалежну та процвітаючу державу 
                через підтримку ветеранів та виховання патріотичної молоді.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => onPageChange?.('veteran-project')}
                  className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
                >
                  <Shield className="w-5 h-5" />
                  <span>Ветеранський проект</span>
                </button>
                <button 
                  onClick={() => onPageChange?.('youth-project')}
                  className="border-2 border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3 rounded-lg font-semibold transition-colors duration-200 flex items-center justify-center space-x-2"
                >
                  <Users className="w-5 h-5" />
                  <span>Молодіжні програми</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}