import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Heart, 
  CreditCard, 
  Building, 
  Users, 
  Award,
  Star,
  HandHeart,
  Shield,
  Copy,
  ExternalLink
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface SupportProps {
  onPageChange: (page: string) => void;
}

export function Support({ onPageChange }: SupportProps) {
  const paymentMethods = [
    {
      type: "Банківський переказ",
      icon: Building,
      details: {
        name: "ГО 'Міські герої'",
        bank: "АТ КБ 'ПриватБанк'",
        account: "UA353052990000026007006718944",
        edrpou: "43161234",
        purpose: "Благодійний внесок на статутну діяльність"
      },
      color: "from-blue-600 to-blue-700"
    },
    {
      type: "Monobank",
      icon: CreditCard,
      details: {
        jar: "https://send.monobank.ua/jar/8N7KqZ2bMj",
        description: "Банка для підтримки ветеранів"
      },
      color: "from-purple-600 to-purple-700"
    },
    {
      type: "PayPal",
      icon: CreditCard,
      details: {
        email: "support@urbanheroes.com.ua",
        link: "https://paypal.me/urbanheroes"
      },
      color: "from-blue-500 to-blue-600"
    }
  ];

  const sponsors = [
    {
      name: "ТОВ 'Укртехсистеми'",
      amount: "50,000 грн",
      type: "Генеральний партнер",
      logo: "💼",
      description: "Підтримка програм військової підготовки"
    },
    {
      name: "Фонд 'Патріот України'",
      amount: "25,000 грн",
      type: "Стратегічний партнер",
      logo: "🏆",
      description: "Фінансування молодіжних програм"
    },
    {
      name: "Анонімний донор",
      amount: "15,000 грн",
      type: "Благодійник",
      logo: "❤️",
      description: "Підтримка реабілітації ветеранів"
    }
  ];

  const grants = [
    {
      name: "Грант Європейського Союза",
      amount: "€15,000",
      period: "2024-2025",
      purpose: "Програма соціальної адаптації ветеранів",
      status: "Активний"
    },
    {
      name: "Фонд розвитку громадських ініціатив",
      amount: "200,000 грн",
      period: "2024",
      purpose: "Молодіжні патріотичні табори",
      status: "Завершений"
    },
    {
      name: "Міжнародний фонд 'Відродження'",
      amount: "$8,000",
      period: "2024-2025",
      purpose: "Психологічна підтримка ветеранів",
      status: "В процесі"
    }
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Можна додати toast notification
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-yellow-50 to-blue-100 relative">
      {/* Patriotic background overlay */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: `url("https://images.unsplash.com/photo-1647472270676-fc9bc37a06ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxVa3JhaW5pYW4lMjBmbGFnJTIwYmFja2dyb3VuZCUyMHRleHR1cmV8ZW58MXx8fHwxNzU4MTIzMTMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />
      
      <div className="relative z-10">
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Header */}
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
                Підтримати організацію
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Ваша підтримка допомагає нам розвивати програми для ветеранів, навчати патріотичну молодь 
                та відроджувати українські традиції. Кожен внесок наближає нас до перемоги.
              </p>
            </div>

            {/* Why Support Section */}
            <div className="mb-20">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Чому варто підтримати "Міські герої"
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <Card className="text-center hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-xl flex items-center justify-center mx-auto mb-6">
                      <Shield className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Підтримка захисників</h3>
                    <p className="text-gray-600">
                      Допомагаємо ветеранам АТО/ООС адаптуватися до мирного життя, 
                      забезпечуємо психологічну підтримку та сприяємо створенню ветеранського бізнесу.
                    </p>
                  </CardContent>
                </Card>

                <Card className="text-center hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-xl flex items-center justify-center mx-auto mb-6">
                      <Users className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Виховання молоді</h3>
                    <p className="text-gray-600">
                      Готуємо нове покоління захисників України через патріотичне виховання, 
                      військову підготовку та вивчення національних традицій.
                    </p>
                  </CardContent>
                </Card>

                <Card className="text-center hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-yellow-500 rounded-xl flex items-center justify-center mx-auto mb-6">
                      <Heart className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Культурна спадщина</h3>
                    <p className="text-gray-600">
                      Відроджуємо українські традиції, пропагуємо національні бойові мистецтва 
                      та зберігаємо культурну спадщину для майбутніх поколінь.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Payment Methods */}
            <div className="mb-20">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Способи фінансової допомоги
              </h2>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {paymentMethods.map((method, index) => {
                  const IconComponent = method.icon;
                  return (
                    <Card key={index} className="hover:shadow-xl transition-shadow duration-300">
                      <CardHeader>
                        <div className={`w-12 h-12 bg-gradient-to-br ${method.color} rounded-lg flex items-center justify-center mb-4`}>
                          <IconComponent className="w-6 h-6 text-white" />
                        </div>
                        <CardTitle>{method.type}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {method.type === "Банківський переказ" && (
                          <div className="space-y-3 text-sm">
                            <div>
                              <span className="font-medium">Отримувач:</span> {method.details.name}
                            </div>
                            <div>
                              <span className="font-medium">Банк:</span> {method.details.bank}
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="font-medium">IBAN:</span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(method.details.account)}
                                className="p-1 h-auto"
                              >
                                <Copy className="w-4 h-4" />
                              </Button>
                            </div>
                            <div className="bg-gray-100 p-2 rounded text-xs font-mono break-all">
                              {method.details.account}
                            </div>
                            <div>
                              <span className="font-medium">ЄДРПОУ:</span> {method.details.edrpou}
                            </div>
                            <div className="text-xs text-gray-600">
                              <span className="font-medium">Призначення:</span> {method.details.purpose}
                            </div>
                          </div>
                        )}
                        
                        {method.type === "Monobank" && (
                          <div className="space-y-3">
                            <p className="text-sm text-gray-600">{method.details.description}</p>
                            <Button 
                              className="w-full bg-gradient-to-r from-purple-600 to-purple-700 text-white"
                              onClick={() => window.open(method.details.jar, '_blank')}
                            >
                              Відкрити банку
                              <ExternalLink className="ml-2 w-4 h-4" />
                            </Button>
                          </div>
                        )}
                        
                        {method.type === "PayPal" && (
                          <div className="space-y-3">
                            <div className="text-sm">
                              <span className="font-medium">Email:</span> {method.details.email}
                            </div>
                            <Button 
                              className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white"
                              onClick={() => window.open(method.details.link, '_blank')}
                            >
                              Перейти до PayPal
                              <ExternalLink className="ml-2 w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>

            {/* Grants Section */}
            <div className="mb-20">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Гранти та фонди
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {grants.map((grant, index) => (
                  <Card key={index} className="hover:shadow-xl transition-shadow duration-300">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-2">
                        <Badge 
                          variant={grant.status === 'Активний' ? 'default' : 
                                  grant.status === 'Завершений' ? 'secondary' : 'outline'}
                        >
                          {grant.status}
                        </Badge>
                        <div className="text-lg font-bold text-blue-600">{grant.amount}</div>
                      </div>
                      <CardTitle className="text-lg">{grant.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2 text-sm text-gray-600">
                        <div><span className="font-medium">Період:</span> {grant.period}</div>
                        <div><span className="font-medium">Мета:</span> {grant.purpose}</div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Sponsors and Donors */}
            <div className="mb-20">
              <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
                Дякуємо нашим меценатам та спонсорам
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sponsors.map((sponsor, index) => (
                  <Card key={index} className="hover:shadow-xl transition-shadow duration-300">
                    <CardContent className="p-6 text-center">
                      <div className="text-4xl mb-4">{sponsor.logo}</div>
                      <Badge className="mb-3 bg-gradient-to-r from-blue-600 to-yellow-500 text-white">
                        {sponsor.type}
                      </Badge>
                      <h3 className="font-bold text-gray-900 mb-2">{sponsor.name}</h3>
                      <div className="text-2xl font-bold text-blue-600 mb-3">{sponsor.amount}</div>
                      <p className="text-sm text-gray-600">{sponsor.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* CTA Section */}
            <div className="text-center">
              <div className="bg-gradient-to-r from-blue-600 to-yellow-500 rounded-2xl p-12 text-white">
                <HandHeart className="w-16 h-16 mx-auto mb-6 text-blue-100" />
                <h3 className="text-3xl font-bold mb-4">Станьте частиною нашої місії</h3>
                <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
                  Кожна гривня, долар чи євро, які ви жертвуєте, допомагають нам будувати сильну, 
                  незалежну Україну через підтримку героїв та виховання нових поколінь патріотів.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    onClick={() => onPageChange('join')}
                    className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3"
                  >
                    Стати волонтером
                  </Button>
                  <Button 
                    onClick={() => onPageChange('contact')}
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-3"
                  >
                    Зв'язатися з нами
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}