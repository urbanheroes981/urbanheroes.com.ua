# Netlify redirects file
/*    /index.html   200