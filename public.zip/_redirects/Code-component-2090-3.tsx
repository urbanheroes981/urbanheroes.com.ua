# Redirects for Netlify
/*    /index.html   200

# Force HTTPS
http://urbanheroes.com.ua/*  https://urbanheroes.com.ua/:splat  301!
http://www.urbanheroes.com.ua/*  https://urbanheroes.com.ua/:splat  301!
https://www.urbanheroes.com.ua/*  https://urbanheroes.com.ua/:splat  301!

# Ukrainian language default
/en/*  /en/:splat  200
/uk/*  /:splat  200

# SEO redirects for common URLs
/home  /  301
/index  /  301
/main  /  301